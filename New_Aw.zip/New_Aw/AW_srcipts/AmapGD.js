﻿// 百度地图API功能
var mp = new BMap.Map("allmap", { minZoom: 12 });//设置缩的最小为12
mp.centerAndZoom(new BMap.Point(109.3328, 18.3234), 12);
mp.enableScrollWheelZoom();
mp.setMapStyle({
    styleJson: [
            {
                "featureType": "water",
                "elementType": "geometry.fill",
                "stylers": {
                    "color": "#7e9fcc",
                    "visibility": "on"
                }
            },
            {
                "featureType": "label",
                "elementType": "all",
                "stylers": {
                    "visibility": "off"
                }
            },
            {
                "featureType": "green",
                "elementType": "all",
                "stylers": {
                    "color": "#000000",
                    "visibility": "off"
                }
            }
    ]
});
mp.addEventListener("zoomend", function () {
    alert("地图缩放至：" + this.getZoom() + "级");
});
var opts = { type: BMAP_NAVIGATION_CONTROL_SMALL }
mp.addControl(new BMap.NavigationControl(opts));

mp.addEventListener("click", function (e) {
    console.log("{lng:\"" + e.point.lng + "\",lat:\"" + e.point.lat + "\"}");
});

var _mapFn = {
    Overs: [],
    Init: function () {
        _mapFn.clearOverlays();//清除
        var ply1 = new BMap.Polygon(Area[0].path, { strokeWeight: 6, strokeOpacity: 1, strokeColor: "#F0CCC3", fillColor: "#EAE0D6", fillOpacity: 0.6 }); //建立多边形覆盖物
        mp.addOverlay(ply1);  //添加覆盖物

        var point = new BMap.Point(109.13158, 18.392575);
        var opts = {
            position: point,    // 指定文本标注所在的地理位置
            offset: new BMap.Size(0, -30)    //设置文本偏移量
        }
        var label = new BMap.Label("崖州区", opts);  // 创建文本标注对象
        label.setStyle({
            color: "black",
            fontSize: "32px",
            fontWeight: "bold",
            fontFamily: "微软雅黑",
            background: "none",
            border: "none",
            textShadow: "6px -2px 5px rgba(0, 0, 0, 0.3)"

        });

        mp.addOverlay(label);

        point = new BMap.Point(109.372182, 18.461447);
        opts = {
            position: point,    // 指定文本标注所在的地理位置
            offset: new BMap.Size(0, -30)    //设置文本偏移量
        }
        var label2 = new BMap.Label("天崖区", opts);  // 创建文本标注对象
        label2.setStyle({
            color: "black",
            fontSize: "32px",
            fontWeight: "bold",
            fontFamily: "微软雅黑",
            background: "none",
            border: "none",
            textShadow: "6px -2px 5px rgba(0, 0, 0, 0.3)"

        });

        mp.addOverlay(label2);

        point = new BMap.Point(109.5872, 18.297315);
        opts = {
            position: point,    // 指定文本标注所在的地理位置
            offset: new BMap.Size(0, -30)    //设置文本偏移量
        }
        var label3 = new BMap.Label("吉阳区", opts);  // 创建文本标注对象
        label3.setStyle({
            color: "black",
            fontSize: "32px",
            fontWeight: "bold",
            fontFamily: "微软雅黑",
            background: "none",
            border: "none",
            textShadow: "6px -2px 5px rgba(0, 0, 0, 0.3)"

        });
        mp.addOverlay(label3);

        point = new BMap.Point(109.707357, 18.404376);
        opts = {
            position: point,    // 指定文本标注所在的地理位置
            offset: new BMap.Size(0, -30)    //设置文本偏移量
        }
        var label4 = new BMap.Label("海棠区", opts);  // 创建文本标注对象
        label4.setStyle({
            color: "black",
            fontSize: "32px",
            fontWeight: "bold",
            fontFamily: "微软雅黑",
            background: "none",
            border: "none",
            textShadow: "6px -2px 5px rgba(0, 0, 0, 0.3)"

        });
        mp.addOverlay(label4);

        var ply2 = new BMap.Polygon(Area[1].path, { strokeWeight: 6, strokeColor: "#d7e3c2", fillColor: "#e9ebdd", fillOpacity: 0.6 }); //建立多边形覆盖物
        mp.addOverlay(ply2);  //添加覆盖物

        var ply3 = new BMap.Polygon(Area[2].path, { strokeWeight: 6, strokeColor: "#c7d9e5", fillColor: "#e0ebe5", fillOpacity: 0.6 }); //建立多边形覆盖物
        mp.addOverlay(ply3);  //添加覆盖物

        var ply4 = new BMap.Polygon(Area[3].path, { strokeWeight: 6, strokeColor: "#e2c8e5", fillColor: "#eadfe5", fillOpacity: 0.6 }); //建立多边形覆盖物
        mp.addOverlay(ply4);  //添加覆盖物
        _mapFn.setBounds();
    },
    setBounds: function () {
        var bdary = new BMap.Boundary();
        bdary.get("三亚", function (rs) {
            var count = rs.boundaries.length;
            if (count === 0) {
                return;
            }
            var pointArray = [];
            for (var i = 0; i < count; i++) {
                var ply = new BMap.Polygon(rs.boundaries[i], { strokeWeight: 2, strokeColor: "#ff0000" });
                pointArray = pointArray.concat(ply.getPath());
            }
            //限定显示区域，需要引用api库
            var boundply = new BMap.Polygon(pointArray);
            //BMapLib.AreaRestriction.setBounds(mp, boundply.getBounds());
            BMapLib.AreaRestriction.setBounds(mp, new BMap.Point("108.903626", "18.063059"), new BMap.Point("109.85741", "18.670773"));
            mp.setViewport(pointArray);
        });
        //var boundply = new BMap.Polygon([{lng:"109.387992",lat:"18.573065"},{lng:"109.009123",lat:"18.388184"},{lng:"109.762837",lat:"18.323949"},{lng:"109.780659",lat:"18.502318"}]);
        //BMapLib.AreaRestriction.setBounds(mp, boundply.getBounds());
        //mp.setViewport([{ lng: "109.387992", lat: "18.573065" }, { lng: "109.009123", lat: "18.388184" }, { lng: "109.762837", lat: "18.323949" }, { lng: "109.780659", lat: "18.502318" }]);
    },
    clearOverlays: function () {
        mp.clearOverlays();
    },
    AddOverlay: function (options) {
        // 复杂的自定义覆盖物
        function ComplexCustomOverlay(point, text, css, mouseoverText) {
            this._point = point;
            this._text = text;
            this._icon = css;
            this._overText = mouseoverText;
        }
        ComplexCustomOverlay.prototype = new BMap.Overlay();
        ComplexCustomOverlay.prototype.initialize = function (map) {
            this._map = map;
            var div = this._div = document.createElement("div");
            div.style.position = "absolute";
            div.style.zIndex = BMap.Overlay.getZIndex(this._point.lat);
            div.style.position = "absolute";
            div.style.color = "white";
            div.style.height = "30px";
            div.style.width = "30px";
            div.style.lineHeight = "30px";
            div.style.textAlign = "center"

            var div1 = document.createElement("div");
            div1.style.position = "absolute";
            div1.className = this._icon + " Icon";
            div1.style.backgroundSize = "contain";
            div1.style.backgroundColor = "#0d9cfc";
            div1.style.border = "2px solid #fff";
            div1.style.borderRadius = "50%";
            div1.style.height = "22px";
            div1.style.width = "22px";
            div1.style.lineHeight = "30px";
            div1.style.padding = "2px";

            div1.style.whiteSpace = "nowrap";
            div1.style.MozUserSelect = "none";

            div.appendChild(div1);

            div.appendChild($('<span class="MSha"></span>')[0]);

            var span = this._span = document.createElement("span");

            span.style.display = "block";
            span.style.position = "absolute";
            span.style.top = "28px";
            span.style.left = "0";
            span.style.marginLeft = "-46px";
            span.style.width = "120px";
            span.style.fontSize = "12px";
            span.style.textAlign = "center";
            span.style.color = "#d322a1";

            div.appendChild(span);
            span.appendChild(document.createTextNode(this._text));
            var that = this;

            mp.getPanes().labelPane.appendChild(div);

            return div;
        }
        ComplexCustomOverlay.prototype.draw = function () {
            var map = this._map;
            var pixel = map.pointToOverlayPixel(this._point);
            this._div.style.left = pixel.x + "px";
            this._div.style.top = pixel.y + "px";
        }

        function addMarker(point, icon) {
            var name = point.name;
            var point = new BMap.Point(point.lng, point.lat);
            var myCompOverlay = new ComplexCustomOverlay(point, name, icon, "");
            mp.addOverlay(myCompOverlay);
            myCompOverlay.hide();
            return myCompOverlay;
        }
        this.Overs = [];
        var lablePanel = $(".lablePanel").empty();
        for (var i = 0; i < options.length; i++) {
            var d = options[i].data;
            var css = this.loadImage(options[i].name);
            $('<div class="item"> <div class="' + css + ' lable"></div><div class="num">' + d.length + '</div> <div class="Name">' + options[i].name + '</div></div>').appendTo(lablePanel)
            var oo = [];
            for (var y = 0; y < d.length; y++) {
                var myCompOverlay = addMarker(d[y], css);
                oo.push(myCompOverlay);
            }
            this.Overs.push({ data: oo });
        }

    },
    RemoveOverlay: function () {
        if (this.Overs && this.Overs.length > 0) {
            for (var i = 0; i < this.Overs.length; i++) {
                mp.removeOverlay(this.Overs[i]);
            }
        }
    },
    LoadOverlay: function (options) {
        if ($.isArray(options)) {
            $(".lablePanel .item").find(".lable").addClass("hide");
            for (var i = 0; i < this.Overs.length; i++) {
                var overs = this.Overs[i].data;
                for (var y = 0; y < overs.length; y++) {
                    overs[y].hide();
                }
            }
            for (var x = 0; x < options.length; x++) {
                var overs = this.Overs[options[x]].data;
                for (var e = 0; e < overs.length; e++) {
                    overs[e].show();
                }
                $(".lablePanel .item").eq(options[x]).find(".lable").removeClass("hide");
            }
        }

    },
    loadImage: function (name) {
        switch (name) {
            case "公共厕所": return "chengshi1"; break;
            case "银行ATM": return "chengshi2"; break;
            case "停车场": return "chengshi3"; break;
            case "游客服务中心": return "chengshi4"; break;
            case "便民服务": return "chengshi5"; break;
            case "无线三亚WiFi": return "chengshi6"; break;
            case "海鲜排档": return "chi1"; break;
            case "中式餐厅": return "chi2"; break;
            case "酒吧": return "chi3"; break;
            case "西式餐厅": return "chi4"; break;
            case "风味餐厅": return "chi5"; break;
            case "茶室": return "chi6"; break;
            case "咖啡厅": return "chi7"; break;
            case "快餐厅": return "chi8"; break;
            case "特色餐厅": return "chi9"; break;
            case "宴会餐厅": return "chi10"; break;
            case "出租车": return "xing1"; break;
            case "公交车": return "xing2"; break;
            case "滴滴专车": return "xing3"; break;
            case "神州专车": return "xing4"; break;
            case "视频监控": return "you1"; break;
            case "风景区": return "you2"; break;
            case "休闲场所": return "yu1"; break;
            case "KTV": return "yu2"; break;
            case "俱乐部": return "yu3"; break;
            case "水下运动": return "yu4"; break;
            case "户外场所": return "yu5"; break;
            case "社会旅馆": return "zhu1"; break;
            case "五星": return "zhu2"; break;
            case "四星": return "zhu3"; break;
            case "三星": return "zhu4"; break;
            case "二星": return "zhu5"; break;
            case "豪华": return "zhu6"; break;
            case "高档": return "zhu7"; break;
            case "舒适": return "zhu8"; break;
            case "其他非星级": return "zhu9"; break;
            case "购物广场": return "gou1"; break;
            case "特产店": return "gou2"; break;
            case "免税店": return "gou3"; break;
        }
        return "";
    },
    move_up: function (num) {
        if (IsMove) {
            if (!num)
                num = 0.1;
            var pt = mp.getBounds().getCenter();
            pt.lat += num;
            mp.panTo(pt);
        }
    }, move_down: function (num) {
        if (IsMove) {
            if (!num)
                num = 0.1;
            var pt = mp.getBounds().getCenter();
            pt.lat -= num;
            mp.panTo(pt);
        }
    }, move_left: function (num) {
        if (IsMove) {
            if (!num)
                num = 0.1;
            var pt = mp.getBounds().getCenter();
            pt.lng -= num;
            mp.panTo(pt);
        }
    }, move_right: function (num) {
        if (IsMove) {
            if (!num)
                num = 0.1;
            var pt = mp.getBounds().getCenter();
            pt.lng += num;
            mp.panTo(pt);
        }
    }, move_big: function () {
        $(".BMap_stdMpZoomIn").click();
    }, move_small: function () {
        $(".BMap_stdMpZoomOut").click();
    }, IsMove: function (ty) {
        var bs = mp.getBounds();
        var bssw = bs.getSouthWest();
        var bsne = bs.getNorthEast();

        if (ty == 1 && bsne.lat >= 18.629000)
            return false;
        else if (ty == 2 && bssw.lat <= 18.1000)
            return false;
        else if (ty == 3 && bssw.lng <= 108.938228)
            return false;
        else if (ty == 4 && bsne.lng >= 109.784458)
            return false;
        return true;
    }
}