'use strict';
if (!String.prototype.format) {
    String.prototype.format = function () {
        var args = arguments;
        return this.replace(/{(\d+)}/g, function (match, number) {
            return typeof args[number] != 'undefined' ? args[number] : match;
        });
    };
}
var app = function () {
    var $svgLine = document.querySelector('svg .line');
    var $svgLineShadow = document.querySelector('svg .line-shadow');
    var sliderThumbSize = 0;
    var sliderHeight = 180;
    var svgViewBoxHeight = 100;
    var svgViewBoxThumbLimit = sliderThumbSize / 2 * (svgViewBoxHeight / sliderHeight);
    var svgViewBoxGraphMax = svgViewBoxHeight - svgViewBoxThumbLimit;
    var svgViewBoxGraphMin = svgViewBoxThumbLimit;
    var ranges = {
        range1: null,
        range2: null,
        range3: null
    };
    var points = {
        begin: {
            x: 5,
            y: 0
        },
        point1: {
            x: 5,
            y: 0
        },
        control1: {
            x: 10,
            y: 10
        },
        control2: {
            x: 10,
            y: 0
        },
        point2: {
            x: 16,
            y: 0
        },
        control3: {
            x: 22,
            y: 0
        },
        point3: {
            x: 28,
            y: 0
        },
    };

    function mapDataRange(value) {
        return (value - 0) * (svgViewBoxGraphMax - svgViewBoxGraphMin) / (svgViewBoxHeight - 0) + svgViewBoxGraphMin;
    }

    function updateSlider($element) {
        if ($element) {
            var rangeIndex = $element.getAttribute('data-slider-index'),
                range = ranges[rangeIndex],
                value = $element.value;
            if (range === value) {
                return;
            }
            ranges[rangeIndex] = value;
            var parent = $element.parentElement,
                $thumb = parent.querySelector('.range-slider__thumb'),
                $bar = parent.querySelector('.range-slider__bar'),
                pct = (value / 15.4);
            $thumb.style.bottom = pct + '%';
            $bar.style.height = 'calc(' + pct + '% + ' + sliderThumbSize / 2 + 'px)';
            renderSliderGraph();
        }
    }

    function updatePoints() {
        points.point1.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range1 / 1540 | 0;
        points.point2.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range2 / 1540 | 0;
        points.point3.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range3 / 1540 | 0;

        var max = svgViewBoxGraphMax;
        var min = svgViewBoxGraphMin;
        points.point1.y = mapDataRange(points.point1.y);
        points.point2.y = mapDataRange(points.point2.y);
        points.point3.y = mapDataRange(points.point3.y);
    }

    function getInterpolatedLine(type) {
        return 'M {0},{1} L {2},{3} C {4},{5} {6},{7} {8},{9} S {10} {11}'
            .format(points.begin.x, points.begin.y,
                points.point1.x, points.point1.y, points.control1.x, points.control1.y,
                points.control2.x, points.control2.y, points.point2.x, points.point2.y,
                points.control3.x, points.control3.y);
    }

    function reset() {
        var inputs = app.inputs;
        inputs.forEach(function (input) {
            return app.updateSlider(input);
        });
    }

    function renderSliderGraph(c) {
        updatePoints();
        $svgLine.setAttribute('d', getInterpolatedLine(c));
        //$svgLineShadow.setAttribute('d', getInterpolatedLine('shadow'));
    }

    function selectPreset(type) {
        var inputs = app.inputs;
        inputs.forEach(function (input) {
            return app.updateSlider(input);
        });
    }
    return {
        inputs: [].slice.call(document.querySelectorAll('.sliders input')),
        updateSlider: updateSlider,
        reset: reset,
        selectPreset: selectPreset
    };
}();

function Getinteger(MaxNum, aver) {
    MaxNum = (MaxNum*1).toFixed(0);
    var gNum = Math.pow(10, MaxNum.toString().length - 2) * 2;
    var CNum = Math.pow(10, MaxNum.toString().length - 1);
    while (CNum < MaxNum)
        CNum += CNum;
    CNum -= CNum;
    while (CNum < MaxNum)
        CNum += gNum;
    var aNum = (CNum / aver).toFixed(0);
    if (CNum > 10)
        while (aNum.toString().substring(aNum.toString().length - 1) != "0") {
            aNum = (aNum * 1) + 1;
        }
    return aNum * aver;
}

(function ($, window, document) {
    'use strict';
    $.fn.Eat_Arc = function (options) {
        options = $.extend({
            'chartdata1': {
                data: [{
                    name: "吉阳区",
                    A: 176,
                    B: 87,
                    C: 569
                },
                    {
                        name: "崖州区",
                        A: 176,
                        B: 87,
                        C: 569
                    },
                    {
                        name: "天涯区",
                        A: 176,
                        B: 87,
                        C: 569
                    },
                    {
                        name: "海棠区",
                        A: 176,
                        B: 87,
                        C: 569
                    }],
                Title: "全市行政区域食品安全量化评估等级企业统计"
            },
            'chartdata2': {
                data: [{
                    name: "A级",
                    value: 165,
                },
                    {
                        name: "B级",
                        value: 265,
                    },
                    {
                        name: "C级",
                        value: 465,
                    },
                    {
                        name: "其他",
                        value: 365,
                    }],
                Title: "全市餐饮企业数量"
            },
            'chartdata3': {
                data: [
                    {
                        name: "海南菜",
                        num: 41
                    },
                    {
                        name: "海鲜",
                        num: 150
                    },
                    {
                        name: "粤菜",
                        num: 130
                    },
                    {
                        name: "湘菜",
                        num: 23
                    },
                    {
                        name: "川菜",
                        num: 180
                    },
                    {
                        name: "东北菜",
                        num: 213
                    },
                    {
                        name: "淮扬菜",
                        num: 23
                    },
                    {
                        name: "火锅",
                        num: 23
                    },
                    {
                        name: "烧烤",
                        num: 23
                    }
                ],
                Title: "全市各类经营项目餐饮企业数"
            },
            'chartdata4': {
                data: [{
                    name: "2014",
                    A: 20,
                    B: 45,
                    C: 65
                },
                    {
                        name: "2015",
                        A: 25,
                        B: 60,
                        C: 70
                    },
                    {
                        name: "2016",
                        A: 18,
                        B: 40,
                        C: 60
                    }],
                Title: "全市食品安全量化评估等级企业年度发展状况"
            },
            'chartdata5': {
                data: [
                    {
                        name: "崖州区",
                        num: 41
                    },
                    {
                        name: "天涯区",
                        num: 150
                    },
                    {
                        name: "吉阳区",
                        num: 130
                    },
                    {
                        name: "海棠区",
                        num: 23
                    }
                ],
                Title: "全市餐厅菜系分类统计图"
            },
            'chartdata6': {
                data: [
                    {
                        name: "海南菜",
                        num: 41
                    },
                    {
                        name: "海鲜",
                        num: 150
                    },
                    {
                        name: "粤菜",
                        num: 130
                    },
                    {
                        name: "湘菜",
                        num: 23
                    },
                    {
                        name: "川菜",
                        num: 180
                    },
                    {
                        name: "东北菜",
                        num: 213
                    },
                    {
                        name: "淮扬菜",
                        num: 23
                    },
                    {
                        name: "火锅",
                        num: 23
                    },
                    {
                        name: "烧烤",
                        num: 23
                    },
                    {
                        name: "自助",
                        num: 23
                    },
                    {
                        name: "云贵菜",
                        num: 23
                    },
                    {
                        name: "西北菜",
                        num: 23
                    },
                    {
                        name: "清真菜",
                        num: 23
                    },
                    {
                        name: "其他",
                        num: 23
                    }
                ],
                Title: "全市餐厅菜系分类统计图"
            }
        }, options);

        function Chart1(data) {
            if (data) {
                var d = data.data;
                var MaxNum = 0;
                var chartContent1 = $(".chartContent1");
                $(".chartContent1 .title").text(data.Title);
                chartContent1.find(".bar").css({
                    "height": 0
                });
                setTimeout(function () {
                    for (var i = 0; i < d.length; i++) {
                        if (MaxNum < d[i].A)
                            MaxNum = d[i].A;
                        if (MaxNum < d[i].B)
                            MaxNum = d[i].B;
                        if (MaxNum < d[i].C)
                            MaxNum = d[i].C;
                    }
                    MaxNum = Getinteger(MaxNum,5);
                    if (MaxNum > 80)
                        for (var f = 0; f < 6; f++) {
                            chartContent1.find(".footer>div").eq(f).find("span").text(((MaxNum / 5) * (5 - f)).toFixed(0));
                        }
                    else
                        MaxNum = 80;
                    chartContent1.find(".bar").css("height", 0);
                    for (var y = 0; y < d.length; y++) {
                        var _d = d[y];
                        var itme = chartContent1.find(".colpanel").eq(y);
                        itme.find(".column").eq(0).find(".bar").animate({
                            "height": (150 * (_d.A / MaxNum))
                        });
                        itme.find(".column").eq(1).find(".bar").animate({
                            "height": (150 * (_d.B / MaxNum))
                        });
                        itme.find(".column").eq(2).find(".bar").animate({
                            "height": (150 * (_d.C / MaxNum))
                        });
                        itme.find(".lableName").text(_d.name);
                    }
                }, 300);
            }
        }

        function Chart2(data) {
            var myChart = echarts.init(document.getElementById('chat'));
            var count = 0;
            for (var i = 0; i < data.data.length; i++) {
                data.data[i].name += "：" + data.data[i].value + "家";
                count += data.data[i].value;
            }
            $(".chartContent2 .title").text(data.Title);
            $(".chartContent2 .labNum").hide().text(count).show(500);
            var option = {
                title: {
                    text: '',
                    subtext: '',
                    x: 'center'
                },
                tooltip: {
                    trigger: 'item',
                    formatter: "{a} <br/>{b} : {c} ({d}%)"
                },
                legend: {
                    show: false
                },
                toolbox: {
                    show: false
                },
                calculable: true,
                series: [
                    {
                        name: '面积模式',
                        type: 'pie',
                        radius: [40, 80],
                        center: ['50%', '50%'],
                        roseType: 'area',
                        color: ["#1a7c31", "#1ea29f", "#601986", "#00479d"],
                        data: data.data,
                        label: {
                            normal: {
                                textStyle: {
                                    color: "#fff",
                                    fontSize: 12
                                }
                            }
                        },
                        labelLine: {
                            normal: {
                                length: 10,
                                length2: 40,
                                lineStyle: {
                                    color: "#556FB5",
                                    type: "dashed"
                                }
                            }
                        }
                    }
                ]
            };
            myChart.setOption(option);

        }

        function Chart3(data) {
            if (data) {
                var d = data.data;
                var MaxNum = d[0].num;
                for (var i = 1; i < d.length; i++) {
                    if (MaxNum < d[i].num)
                        MaxNum = d[i].num;
                }
                var column = '<div class="column"><div class="Num"></div><div class="bar"></div> <div class="labName"></div></div>';
                var chartContent3 = $(".chartContent3");
                chartContent3.find(".title").text(data.Title);
                chartContent3.find(".bar").css("height", 0);
                setTimeout(function () {
                    chartContent3.find(".column").remove();
                    for (var i = 0; i < d.length; i++) {
                        var _d = d[i];
                        var newItem = $(column);
                        newItem.css("left", (46 + 10) * i);
                        newItem.find(".bar").css("width", "30");
                        newItem.find(".Num").text(_d.num).end().find(".labName").text(_d.name).end();
                        newItem.insertBefore(chartContent3.find(".footer"));
                        newItem.find(".bar").animate({
                            "height": (150 * (_d.num / MaxNum))
                        });
                    }
                }, 300)

            }
        }

        function Chart4(data) {
            if (data) {
                var chartContent4 = $(".chartContent4");
                chartContent4.find(".title").text(data.Title);
                var xdata = [];
                var ydata = [];
                var MaxNum = 0;
                var lineColors = ["#83AE27", "#2384AF", "#5F52A0"]
                for (var i = 0; i < data.data.length; i++) {
                    var _d = data.data[i];
                    xdata.push({
                        value: _d.name + " 年",
                        textStyle: {
                            color: "#01B5B5"
                        }
                    });
                    ydata.push({
                        type: 'line',
                        data: (i == 0 ? [data.data[0].A, data.data[1].A, data.data[2].A] : i == 1 ? [data.data[0].B, data.data[1].B, data.data[2].B] : [data.data[0].C, data.data[1].C, data.data[2].C]),
                        symbol: "circle",
                        max: 80,
                        symbolSize: 10,
                        lineStyle: {
                            normal: {
                                color: lineColors[i]
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: lineColors[i]
                            }
                        }
                    });
                    if (MaxNum < _d.A)
                        MaxNum = _d.A;
                    if (MaxNum < _d.B)
                        MaxNum = _d.B;
                    if (MaxNum < _d.C)
                        MaxNum = _d.C;
                }
                MaxNum = Getinteger(MaxNum,5);
                if (MaxNum > 80)
                    for (var f = 0; f < 6; f++) {
                        chartContent4.find(".chart_tick>div").eq(f).find("span").text(((MaxNum / 5) * (5 - f)).toFixed(0));
                    }
                else
                    MaxNum = 80;
                var option = {
                    title: {
                        show: false,
                        text: '对数轴示例',
                        left: 'center'
                    },
                    tooltip: {
                        show: false,
                        trigger: 'item',
                        formatter: '{a} <br/>{b} : {c}'
                    },
                    legend: {
                        show: false
                    },

                    xAxis: {
                        type: 'category',
                        name: '',
                        boundaryGap: false,
                        offset: 6,
                        splitLine: {
                            show: true,
                            lineStyle: {
                                type: "dashed",
                                color: "rgba(0, 160, 233, 0.3)"
                            }
                        },
                        axisTick: {
                            show: false,
                            alignWithLabel: false
                        },
                        axisLine: {
                            show: false
                        },
                        data: xdata
                    },
                    grid: {
                        show: false,
                        top: 20,
                        width: 330,
                        left: "20%",
                        height: 170,
                        containLabel: true
                    },
                    yAxis: {
                        type: 'value',
                        splitNumber: 5,
                        max: MaxNum,
                        splitLine: {
                            lineStyle: {
                                type: "dashed",
                                color: "rgba(0, 160, 233, 0)"
                            }
                        },
                        axisLine: {
                            show: false
                        },
                        axisTick: {
                            show: false,
                            alignWithLabel: false
                        },
                        axisLabel: {
                            textStyle: {
                                color: "rgba(0, 160, 233, 0)"
                            }
                        }
                    },
                    series: ydata
                };
                var myChart = echarts.init(document.getElementById('Echart2'));
                myChart.setOption(option);
            }
        }

        function Chart5(data) {
            if (data) {
                var d = data.data;
                var chartContent5 = $(".chartContent5");
                var MaxNum = d[0].num;
                for (var i = 1; i < d.length; i++) {
                    if (MaxNum < d[i].num)
                        MaxNum = d[i].num;
                }
                MaxNum = Getinteger(MaxNum,8);
                if (MaxNum > 80)
                    for (var f = 0; f < 9; f++) {
                        chartContent5.find(".chart_tick>div").eq(f).find("span").text(((MaxNum / 8) * (8 - f)).toFixed(0));
                    }
                else
                    MaxNum = 80;
                chartContent5.find(".bar").css("height", 0);
                chartContent5.find(".title").text(data.Title);
                setTimeout(function () {
                    for (var y = 0; y < d.length; y++) {
                        var _d = d[y];
                        var itme = chartContent5.find(".colpanel").eq(y);
                        itme.find(".Num").text(_d.num);
                        itme.find(".bar").animate({
                            "height": (194 * (_d.num / MaxNum))
                        });
                        itme.find(".lableName").text(_d.name);
                    }
                }, 300)
            }
        }

        function Chart6(data) {
            if (data) {
                var d = data.data;
                var MaxNum = d[0].num;
                for (var i = 1; i < d.length; i++) {
                    if (MaxNum < d[i].num)
                        MaxNum = d[i].num;
                }
                var column = '<div class="column"><div class="Num"></div><div class="bar"></div> <div class="labName"></div></div>';
                var chartContent6 = $(".chartContent6");
                chartContent6.find(".bar").css("height", 0);
                chartContent6.find(".title").text(data.Title);
                setTimeout(function () {
                    chartContent6.find(".column").remove();
                    for (var i = 0; i < d.length; i++) {
                        var _d = d[i];
                        var newItem = $(column);
                        newItem.css("left", (((580/d.length)) * i)+10);
                        newItem.find(".Num").text(_d.num).end().find(".labName").text(_d.name).end();
                        newItem.insertBefore(chartContent6.find(".footer"));
                        newItem.find(".bar").animate({
                            "height": (170 * (_d.num / MaxNum))
                        });
                    }
                }, 300);
            }
        }

        function Updata(time) {
            $(".updateTime").stop().slideUp(function () {
                $(".updateTime").text(tiem).stop().slideDown();
            });
        }
        Chart1(options.chartdata1);
        Chart2(options.chartdata2);
        Chart4(options.chartdata4);
        Chart6(options.chartdata6);
        Chart3(options.chartdata3);
        Chart5(options.chartdata5);
        return {
            loadChart1: Chart1,
            loadChart2: Chart2,
            loadChart3: Chart3,
            loadChart4: Chart4,
            loadChart5: Chart5,
            loadChart6: Chart6,
            Updata: Updata
        }
    }
})(jQuery, window, document)
