'use strict';
if (!String.prototype.format) {
    String.prototype.format = function () {
        var args = arguments;
        return this.replace(/{(\d+)}/g, function (match, number) {
            return typeof args[number] != 'undefined' ? args[number] : match;
        });
    };
}
var app = function () {
    var $svgLine = document.querySelector('svg .line');
    var $svgLineShadow = document.querySelector('svg .line-shadow');
    var sliderThumbSize = 0;
    var sliderHeight = 180;
    var svgViewBoxHeight = 100;
    var svgViewBoxThumbLimit = sliderThumbSize / 2 * (svgViewBoxHeight / sliderHeight);
    var svgViewBoxGraphMax = svgViewBoxHeight - svgViewBoxThumbLimit;
    var svgViewBoxGraphMin = svgViewBoxThumbLimit;
    var ranges = {
        range1: null,
        range2: null,
        range3: null,
        range4: null,
        range5: null,
        range6: null,
        range7: null,
        range8: null,
        range9: null,
        range10: null,
        range11: null,
        range12: null
    };
    var points = {
        begin: {
            x: 5,
            y: 0
        },
        point1: {
            x: 5,
            y: 0
        },
        control1: {
            x: 5,
            y: 10
        },
        control2: {
            x: 16,
            y: 0
        },
        point2: {
            x: 16,
            y: 0
        },
        control3: {
            x: 28,
            y: 0
        },
        point3: {
            x: 28,
            y: 0
        },
        control4: {
            x: 39.5,
            y: 0
        },
        point4: {
            x: 39.5,
            y: 0
        },
        control5: {
            x: 51,
            y: 0
        },
        point5: {
            x: 51,
            y: 0
        },
        control6: {
            x: 63,
            y: 0
        },
        point6: {
            x: 63,
            y: 0
        },
        control7: {
            x: 75,
            y: 0
        },
        point7: {
            x: 75,
            y: 0
        },
        control8: {
            x: 87,
            y: 0
        },
        point8: {
            x: 87,
            y: 0
        },
        control9: {
            x: 98,
            y: 0
        },
        point9: {
            x: 98,
            y: 0
        },
        control10: {
            x: 110,
            y: 0
        },
        point10: {
            x: 110,
            y: 0
        },
        control11: {
            x: 121.5,
            y: 0
        },
        point11: {
            x: 121.5,
            y: 0
        },
        control12: {
            x: 133,
            y: 0
        },
        point12: {
            x: 133,
            y: 0
        }

    };

    function mapDataRange(value) {
        return (value - 0) * (svgViewBoxGraphMax - svgViewBoxGraphMin) / (svgViewBoxHeight - 0) + svgViewBoxGraphMin;
    }

    function updateSlider($element, c) {
        if ($element) {
            var rangeIndex = $element.getAttribute('data-slider-index'),
                range = ranges[rangeIndex],
                value = $element.value;
            if (range === value) {
                return;
            }
            ranges[rangeIndex] = value;
            var parent = $element.parentElement,
                $thumb = parent.querySelector('.range-slider__thumb'),
                $bar = parent.querySelector('.range-slider__bar'),
                pct = (value / 200);
            $thumb.style.bottom = pct + '%';
            $bar.style.height = 'calc(' + pct + '% + ' + sliderThumbSize / 2 + 'px)';
            renderSliderGraph(c);
        }
    }

    function updatePoints() {
        points.point1.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range1 / 20000 | 0;
        points.point2.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range2 / 20000 | 0;
        points.point3.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range3 / 20000 | 0;
        points.point4.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range4 / 20000 | 0;
        points.point5.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range5 / 20000 | 0;
        points.point6.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range6 / 20000 | 0;
        points.point7.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range7 / 20000 | 0;


        points.point8.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range8 / 20000 | 0;
        points.point9.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range9 / 20000 | 0;
        points.point10.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range10 / 20000 | 0;
        points.point11.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range11 / 20000 | 0;
        points.point12.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range12 / 20000 | 0;

        var max = svgViewBoxGraphMax;
        var min = svgViewBoxGraphMin;
        points.point1.y = mapDataRange(points.point1.y);
        points.point2.y = mapDataRange(points.point2.y);
        points.point3.y = mapDataRange(points.point3.y);
        points.point4.y = mapDataRange(points.point4.y);
        points.point5.y = mapDataRange(points.point5.y);
        points.point6.y = mapDataRange(points.point6.y);
        points.point7.y = mapDataRange(points.point7.y);

        points.point8.y = mapDataRange(points.point8.y);
        points.point9.y = mapDataRange(points.point9.y);
        points.point10.y = mapDataRange(points.point10.y);
        points.point11.y = mapDataRange(points.point11.y);
        points.point12.y = mapDataRange(points.point12.y);

        points.begin.y = points.point1.y;
        points.control1.y = points.point1.y;
        points.control2.y = points.point2.y;
        points.control3.y = points.point3.y;
        points.control4.y = points.point4.y;
        points.control5.y = points.point5.y;
        points.control6.y = points.point6.y;
        points.control7.y = points.point7.y;

        points.control8.y = points.point8.y;
        points.control9.y = points.point9.y;
        points.control10.y = points.point10.y;
        points.control11.y = points.point11.y;
        points.control12.y = points.point12.y;
    }

    function getInterpolatedLine(index) {
        if (index == undefined)
            index = 12;
        var p = "M {0},{1}"
        for (var i = 1; i < index; i++) {
            p += `L{${(i - 1) * 4 + 2}},{${(i - 1) * 4 + 3}}`;
        }
        return p
            .format(points.begin.x, points.begin.y,
                points.control2.x, points.control2.y, points.point2.x, points.point2.y,
                points.control3.x, points.control3.y, points.point3.x, points.point3.y,
                points.control4.x, points.control4.y, points.point4.x, points.point4.y,
                points.control5.x, points.control5.y, points.point5.x, points.point5.y,
                points.control6.x, points.control6.y, points.point6.x, points.point6.y,
                points.control7.x, points.control7.y, points.point7.x, points.point7.y,
                points.control8.x, points.control8.y, points.point8.x, points.point8.y,
                points.control9.x, points.control9.y, points.point9.x, points.point9.y,
                points.control10.x, points.control10.y, points.point10.x, points.point10.y,
                points.control11.x, points.control11.y, points.point11.x, points.point11.y,
                points.control12.x, points.control12.y, points.point12.x, points.point12.y);
    }

    function reset() {
        var inputs = app.inputs;
        inputs.forEach(function (input) {
            return app.updateSlider(input);
        });
    }

    function renderSliderGraph(c) {
        updatePoints();
        $svgLine.setAttribute('d', getInterpolatedLine(c));
    }

    function selectPreset(type) {
        var inputs = app.inputs;
        //inputs.forEach(function (input) {
        //  return input.value = Math.random() * 100 | 0;
        //});
        inputs.forEach(function (input) {
            return app.updateSlider(input);
        });
    }
    return {
        inputs: [].slice.call(document.querySelectorAll('.sliders input')),
        updateSlider: updateSlider,
        reset: reset,
        selectPreset: selectPreset
    };
}();

function Getinteger(MaxNum, aver) {
    MaxNum = (MaxNum * 1).toFixed(0);
    var gNum = Math.pow(10, MaxNum.toString().length - 2) * 2;
    var CNum = Math.pow(10, MaxNum.toString().length - 1);
    while (CNum < MaxNum)
        CNum += CNum;
    CNum -= CNum;
    while (CNum < MaxNum)
        CNum += gNum;
    var aNum = (CNum / aver).toFixed(0);
    if (CNum > 10)
        while (aNum.toString().substring(aNum.toString().length - 1) != "0") {
            aNum = (aNum * 1) + 1;
        }
    return aNum * aver;
}

(function ($, window, document) {
    'use strict';
    $.fn.Eat_Arc2 = function (options) {
        options = $.extend({
            'chartdata1': {
                data: [7081, 6511, 5621, 4871, 2579, 2578, 876, 567, 343, 553, 464, 200],
                Title: '2016年全市每月海鲜销量排挡销售总额'
            },
            'chartdata2': {
                data: [{
                    name: "崖州区",
                    value: 165,
                },
                    {
                        name: "天涯区",
                        value: 265,
                    },
                    {
                        name: "吉阳区",
                        value: 465,
                    },
                    {
                        name: "海棠区",
                        value: 365,
                    }],
                Title: "全市餐饮企业数量"
            },
            'chartdata3': {
                data: [{
                    name: "益龙海景渔村",
                    num: 800
                }, {
                    name: "益龙海景渔村",
                    num: 800
                }, {
                    name: "益龙海景渔村",
                    num: 800
                }, {
                    name: "四海鱼港餐饮有限公司",
                    num: 2390
                }, {
                    name: "益龙海景渔村",
                    num: 800
                }, {
                    name: "益龙海景渔村",
                    num: 700
                }, {
                    name: "益龙海景渔村",
                    num: 460
                }, {
                    name: "益龙海景渔村",
                    num: 800
                }, {
                    name: "益龙海景渔村",
                    num: 800
                }, {
                    name: "益龙海景渔村",
                    num: 680
                }],
                Title: "本月海鲜排挡消费排名TOP10"
            },
            'chartdata4': {
                data: [{
                    name: "中国龙虾（青龙虾/小）",
                    ty: "虾类",
                    money: "256元/斤"
                }, {
                    name: "中国龙虾（青龙虾/小）",
                    ty: "虾类",
                    money: "256元/斤"
                }, {
                    name: "中国龙虾（青龙虾/小）",
                    ty: "虾类",
                    money: "256元/斤"
                }, {
                    name: "中国龙虾（青龙虾/小）",
                    ty: "虾类",
                    money: "256元/斤"
                }, {
                    name: "中国龙虾（青龙虾/小）",
                    ty: "虾类",
                    money: "256元/斤"
                }, {
                    name: "中国龙虾（青龙虾/小）",
                    ty: "虾类",
                    money: "256元/斤"
                }, {
                    name: "中国龙虾（青龙虾/小）",
                    ty: "虾类",
                    money: "256元/斤"
                }, {
                    name: "中国龙虾（青龙虾/小）",
                    ty: "虾类",
                    money: "256元/斤"
                }, {
                    name: "中国龙虾（青龙虾/小）",
                    ty: "虾类",
                    money: "256元/斤"
                }, {
                    name: "中国龙虾（青龙虾/小）",
                    ty: "虾类",
                    money: "256元/斤"
                }, {
                    name: "中国龙虾（青龙虾/小）",
                    ty: "虾类",
                    money: "256元/斤"
                }, {
                    name: "中国龙虾（青龙虾/小）",
                    ty: "虾类",
                    money: "256元/斤"
                }, {
                    name: "中国龙虾（青龙虾/小）",
                    ty: "虾类",
                    money: "256元/斤"
                }],
                Title: '今日海鲜排挡菜品调控价'
            },
            'chartdata5': {
                data: [
                    {
                        name: "崖州区",
                        num: 41
                    },
                    {
                        name: "天涯区",
                        num: 150
                    },
                    {
                        name: "吉阳区",
                        num: 130
                    },
                    {
                        name: "海棠区",
                        num: 23
                    }
                ],
                Title: "昨日各行政区海鲜排档销售金额"
            },
            'chartdata6': {
                data: [{
                    name: "南美白对虾",
                    num: 2300
                }, {
                    name: "紫蛤",
                    num: 2000
                }, {
                    name: "波纹把非哈",
                    num: 1500
                }, {
                    name: "波纹把非哈",
                    num: 1390
                }, {
                    name: "青石斑鱼",
                    num: 1800
                }, {
                    name: "鞍带石斑鱼",
                    num: 1590
                }, {
                    name: "益龙海景渔村",
                    num: 460
                }, {
                    name: "红花蟹",
                    num: 800
                }, {
                    name: "方斑东风螺",
                    num: 780
                }, {
                    name: "褐点石斑鱼",
                    num: 680
                }],
                Title: '本月最热菜品TOP10'
            }
        }, options);

        function Chart3(data) {
            var c1 = $(".chart_top .panel_right");
            var chartContent2 = $(".chartContent2");
            chartContent2.find(".item").remove();
            if (data) {
                /*data.data = data.data.sort(function (a, b) {
                    return a.num < b.num;
                });*/
                c1.find(">p.title").text(data.Title);
                var d = data.data;
                var MaxNum = d[0].num;
                for (var i = 0; i < d.length; i++) {
                    var _d = d[i];
                    var newItem = $('<div class="item"></div>');
                    $('<div class="name">' + _d.name + '</div>').appendTo(newItem);
                    var Wi = 360;
                    Wi = Wi * (_d.num / MaxNum);
                    $('<div class="probar"><span class="hexagon">' + (i + 1) + '</span><span class="bar"></span></div>').appendTo(newItem);
                    newItem.appendTo(chartContent2);
                    newItem.find(".bar").animate({
                        "width": Wi
                    });
                }
            }

        }

        function Chart1(data) {
            $("path.line").attr("class", "line");
            var inputs = app.inputs;
            var index = 1;
            if (data) {
                var sliders = $(".chart_top .panel_left");
                $(sliders).find(".title").text(data.Title);
                for (var i = 0; i < 12; i++) {
                    var d = data.data[i];
                    var ranger = sliders.find(".range-slider").eq(i);
                    ranger.find("input").val(d);
                }
            }
            $(".range-slider").css("opacity", 1);
            if (data.lens)
                $(".range-slider:gt(" + (data.lens - 1) + ")").css("opacity", 0);

            inputs.forEach(function (input) {
                return input.setAttribute('data-slider-index', 'range' + index++);
            });
            inputs.forEach(function (input) {
                return app.updateSlider(input, (data.lens ? data.lens : 12));
            });
            app.selectPreset('custom');
            setTimeout(function () {
                $("path.line").attr("class", "line path ");
            }, 300);
        }

        function Chart4(data) {
            $(".chart_bottom .panel_left .title").text(data.Title);
            var dd = data.data;
            $(".chartContent3").slideUp(function () {
                $(".chartContent3").empty();
                if (dd) {
                    for (var i = 0; i < dd.length; i++) {
                        var d = dd[i];
                        var fo = $('<div class="fooditem"><div class="name">' + d.name + '</div><div class="foodtype">' + d.ty + '</div><div class="money">' + d.money + '</div></div>').appendTo($(".chartContent3"));
                    }
                }
                $(".chartContent3").slideDown(500);
            });
        }


        function Chart2(data) {
            var myChart = echarts.init(document.getElementById('chat'));
            var count = 0;
            for (var i = 0; i < data.data.length; i++) {
                data.data[i].name += "：" + data.data[i].value;
                count += data.data[i].value;
            }
            $(".chart_top .panel_middle .title").text(data.Title);
            $(".chart_top .panel_middle .labNum").text(count);
            var option = {
                title: {
                    text: '',
                    subtext: '',
                    x: 'center'
                },
                tooltip: {
                    trigger: 'item',
                    formatter: "{a} <br/>{b} : {c} ({d}%)"
                },
                legend: {
                    show: false
                },
                toolbox: {
                    show: false
                },
                calculable: true,
                series: [
                    {
                        name: '面积模式',
                        type: 'pie',
                        radius: [38, 70],
                        center: ['50%', '50%'],
                        roseType: 'area',
                        color: ["#1a7c31", "#1ea29f", "#601986", "#00479d"],
                        data: data.data,
                        label: {
                            normal: {
                                textStyle: {
                                    color: "#fff",
                                    fontSize: 12
                                }
                            }
                        },
                        labelLine: {
                            normal: {
                                length: 8,
                                length2: 20,
                                lineStyle: {
                                    color: "#556FB5",
                                    type: "dashed"
                                }
                            }
                        }
                    }
                ]
            };
            myChart.setOption(option);

        }

        function Chart6(data) {
            var c2 = $(".chart_bottom .panel_right");
            var chartContent4 = $(".chartContent4");
            chartContent4.find(".item").remove();
            if (data) {
                data.data = data.data.sort(function (a, b) {
                    return a.num < b.num;
                });
                c2.find(">p.title").text(data.Title);
                var d = data.data;
                var MaxNum = d[0].num;
                for (var i = 0; i < d.length; i++) {
                    var _d = d[i];
                    var newItem = $('<div class="item"></div>');
                    $('<div class="name">' + _d.name + '</div>').appendTo(newItem);
                    var Wi = 200;
                    Wi = Wi * (_d.num / MaxNum);
                    $('<div class="probar"><span class="hexagon">' + (i + 1) + '</span><span class="bar"></span></div>').appendTo(newItem);
                    $('<div>' + _d.num + ' 份</div>').appendTo(newItem);
                    newItem.appendTo(chartContent4);

                    newItem.find(".bar").animate({
                        "width": Wi
                    });
                }
            }
        }

        function Chart5(data) {
            if (data) {
                var d = data.data;
                var chartContent5 = $(".chart_bottom .panel_middle");
                var MaxNum = d[0].num;
                for (var i = 1; i < d.length; i++) {
                    if (MaxNum < d[i].num)
                        MaxNum = d[i].num;
                }
                MaxNum = Getinteger(MaxNum, 8);
                if (MaxNum > 80)
                    for (var f = 0; f < 9; f++) {
                        chartContent5.find(".chart_tick>div").eq(f).find("span").text(((MaxNum / 8) * (8 - f)).toFixed(0));
                    }
                else
                    MaxNum = 80;
                chartContent5.find(".bar").css("height", 0);
                chartContent5.find(".title").text(data.Title);
                setTimeout(function () {
                    for (var y = 0; y < d.length; y++) {
                        var _d = d[y];
                        var itme = chartContent5.find(".colpanel").eq(y);
                        itme.find(".bar").animate({
                            "height": (194 * (_d.num / MaxNum))
                        });
                        itme.find(".lableName").text(_d.name);
                    }
                }, 300)
            }
        }

        function Updata(time) {
            $(".updateTime").stop().slideUp(function () {
                $(".updateTime").text(tiem).stop().slideDown();
            });
        }
        Chart1(options.chartdata1);
        Chart3(options.chartdata3);
        Chart4(options.chartdata4);
        Chart2(options.chartdata2);
        Chart5(options.chartdata5);
        Chart6(options.chartdata6);
        return {
            loadChart1: Chart1,
            loadChart2: Chart2,
            loadChart3: Chart3,
            loadChart4: Chart4,
            loadChart5: Chart5,
            loadChart6: Chart6,
            Updata: Updata
        }
    }
})(jQuery, window, document)
