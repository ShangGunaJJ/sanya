'use strict';
if (!String.prototype.format) {
    String.prototype.format = function () {
        var args = arguments;
        return this.replace(/{(\d+)}/g, function (match, number) {
            return typeof args[number] != 'undefined' ? args[number] : match;
        });
    };
}
var app = function () {
    var $svgLine = document.querySelector('svg .line');
    var $svgLineShadow = document.querySelector('svg .line-shadow');
    var sliderThumbSize = 0;
    var sliderHeight = 180;
    var svgViewBoxHeight = 100;
    var svgViewBoxThumbLimit = sliderThumbSize / 2 * (svgViewBoxHeight / sliderHeight);
    var svgViewBoxGraphMax = svgViewBoxHeight - svgViewBoxThumbLimit;
    var svgViewBoxGraphMin = svgViewBoxThumbLimit;
    var ranges = {
        range1: null,
        range2: null,
        range3: null,
        range4: null,
        range5: null,
        range6: null,
        range7: null,
        range8:null,
        range9:null,
        range10:null,
        range11:null,
        range12:null
    };
    var points = {
        begin: {
            x: 5,
            y: 0
        },
        point1: {
            x: 5,
            y: 0
        },
        control1: {
            x: 10,
            y: 10
        },
        control2: {
            x: 10,
            y: 0
        },
        point2: {
            x: 16,
            y: 0
        },
        control3: {
            x: 22,
            y: 0
        },
        point3: {
            x: 28,
            y: 0
        },
        control4: {
            x: 34,
            y: 0
        },
        point4: {
            x: 40,
            y: 0
        },
        control5: {
            x: 44,
            y: 0
        },
        point5: {
            x: 50,
            y: 0
        },
        control6: {
            x: 56,
            y: 0
        },
        point6: {
            x: 62,
            y: 0
        },
        control7: {
            x: 68,
            y: 0
        },
        point7: {
            x: 74,
            y: 0
        },
        control8: {
            x: 79,
            y: 0
        },
        point8: {
            x: 86,
            y: 0
        },
        control9: {
            x: 91,
            y: 0
        },
        point9: {
            x: 97,
            y: 0
        },
        control10: {
            x: 102,
            y: 0
        },
        point10: {
            x: 109,
            y: 0
        },
        control11: {
            x: 114,
            y: 0
        },
        point11: {
            x: 121,
            y: 0
        },
        control12: {
            x: 125,
            y: 0
        },
        point12: {
            x: 133,
            y: 0
        }
    
    };
    function mapDataRange(value) {
        return (value - 0) * (svgViewBoxGraphMax - svgViewBoxGraphMin) / (svgViewBoxHeight - 0) + svgViewBoxGraphMin;
    }
    function updateSlider($element) {
        if ($element) {
            var rangeIndex = $element.getAttribute('data-slider-index'), range = ranges[rangeIndex], value = $element.value;
            if (range === value) {
                return;
            }
            ranges[rangeIndex] = value;
            var parent = $element.parentElement, $thumb = parent.querySelector('.range-slider__thumb'), $bar = parent.querySelector('.range-slider__bar'),
            pct = (value/15.4);
            $thumb.style.bottom = pct + '%';
            $bar.style.height = 'calc(' + pct + '% + ' + sliderThumbSize / 2 + 'px)';
            renderSliderGraph();
        }
    }
    function updatePoints() {
        points.point1.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range1 / 1540 | 0;
        points.point2.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range2 / 1540 | 0;
        points.point3.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range3 / 1540 | 0;
        points.point4.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range4 / 1540 | 0;
        points.point5.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range5 / 1540 | 0;
        points.point6.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range6 / 1540 | 0;
        points.point7.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range7 / 1540 | 0;
        
        
        points.point8.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range8 / 1540 | 0;
        points.point9.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range9 / 1540 | 0;
        points.point10.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range10 / 1540 | 0;
        points.point11.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range11 / 1540 | 0;
        points.point12.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range12/ 1540 | 0;
        
        var max = svgViewBoxGraphMax;
        var min = svgViewBoxGraphMin;
        points.point1.y = mapDataRange(points.point1.y);
        points.point2.y = mapDataRange(points.point2.y);
        points.point3.y = mapDataRange(points.point3.y);
        points.point4.y = mapDataRange(points.point4.y);
        points.point5.y = mapDataRange(points.point5.y);
        points.point6.y = mapDataRange(points.point6.y);
        points.point7.y = mapDataRange(points.point7.y);
        
        points.point8.y = mapDataRange(points.point8.y);
        points.point9.y = mapDataRange(points.point9.y);
        points.point10.y = mapDataRange(points.point10.y);
        points.point11.y = mapDataRange(points.point11.y);
        points.point12.y = mapDataRange(points.point12.y);
        
        points.begin.y = points.point1.y;
        points.control1.y = points.point1.y;
        points.control2.y = points.point2.y;
        points.control3.y = points.point3.y;
        points.control4.y = points.point4.y;
        points.control5.y = points.point5.y;
        points.control6.y = points.point6.y;
        points.control7.y = points.point7.y;
        
          points.control8.y = points.point8.y;
        points.control9.y = points.point9.y;
        points.control10.y = points.point10.y;
        points.control11.y = points.point11.y;
        points.control12.y = points.point12.y;
    }
    function getInterpolatedLine(type) {
        return 'M {0},{1} L {2},{3} C {4},{5} {6},{7} {8},{9} S {10} {11}, {12} {13} S {14} {15}, {16} {17} S {18} {19}, {20} {21} S {22} {23}, {24} {25} S {26} {27}, {28} {29} S {30} {31},{32} {33} S {34} {35}, {36} {37} S {38} {39}, {40} {41} S {42} {43}, {44} {45} S {46} {47}, {48} {49}'
        .format(points.begin.x, points.begin.y,
        points.point1.x, points.point1.y, points.control1.x, points.control1.y,
        points.control2.x, points.control2.y, points.point2.x, points.point2.y,
        points.control3.x, points.control3.y, points.point3.x, points.point3.y,
        points.control4.x, points.control4.y , points.point4.x, points.point4.y ,
        points.control5.x, points.control5.y, points.point5.x, points.point5.y,
        points.control6.x, points.control6.y, points.point6.x, points.point6.y,
        points.control7.x, points.control7.y, points.point7.x, points.point7.y,
        points.control8.x, points.control8.y, points.point8.x, points.point8.y,
               points.control9.x, points.control9.y, points.point9.x, points.point9.y,
               points.control10.x, points.control10.y, points.point10.x, points.point10.y,
               points.control11.x, points.control11.y, points.point11.x, points.point11.y,
               points.control12.x, points.control12.y, points.point12.x, points.point12.y);
    }
    function reset() {
        var inputs = app.inputs;
        inputs.forEach(function (input) {
            return app.updateSlider(input);
        });
    }
    function renderSliderGraph(c) {
        updatePoints();
        $svgLine.setAttribute('d', getInterpolatedLine(c));
        //$svgLineShadow.setAttribute('d', getInterpolatedLine('shadow'));
    }
    function selectPreset(type) {
        var inputs = app.inputs;
        //inputs.forEach(function (input) {
          //  return input.value = Math.random() * 100 | 0;
        //});
        inputs.forEach(function (input) {
            return app.updateSlider(input);
        });
    }
    return {
        inputs: [].slice.call(document.querySelectorAll('.sliders input')),
        updateSlider: updateSlider,
        reset: reset,
        selectPreset: selectPreset
    };
}();

(function($,window,document){
    'use strict';
    $.fn.Eat_Arc2=function(options){
        options=$.extend({},options);
        function Init(){
            var chartContent3=$(".chartContent3");
            chartContent3.find(".item").remove();
            if(options.consumption&&options.consumption.data){
                 options.consumption.data=options.consumption.data.sort(function(a,b){return a.num<b.num;});
  chartContent3.find(">p.title").text(options.consumption.Title);
                var d=options.consumption.data;
                var MaxNum=d[0].num;
                for(var i=0;i<d.length;i++){
                    var _d=d[i];
                    var newItem=$('<div class="item"></div>');
                    $('<div class="name">'+_d.name+'</div>').appendTo(newItem);
                    var Wi=330;
                    Wi=Wi*(_d.num/MaxNum);
                    $('<div class="probar"><span class="hexagon">'+(i+1)+'</span><span class="bar"></span></div>').appendTo(newItem);
                    newItem.appendTo(chartContent3.find(".panel"));
                    newItem.find(".bar").animate({"width":Wi});
                }
            }

            var chartContent4=$(".chartContent4");
            chartContent4.find(".item").remove();
            if(options.HotDishes&&options.HotDishes.data){
                 options.HotDishes.data=options.HotDishes.data.sort(function(a,b){return a.num<b.num;});
            chartContent4.find(">p.title").text(options.HotDishes.Title);
                var d=options.HotDishes.data;
                var MaxNum=d[0].num;
                for(var i=0;i<d.length;i++){
                    var _d=d[i];
                    var newItem=$('<div class="item"></div>');
                    $('<div class="name">'+_d.name+'</div>').appendTo(newItem);
                    var Wi=330;
                    Wi=Wi*(_d.num/MaxNum);
                    $('<div class="probar"><span class="hexagon">'+(i+1)+'</span><span class="bar"></span></div>').appendTo(newItem);
                    $('<div>'+_d.num+' 人</div>').appendTo(newItem);
                    newItem.appendTo(chartContent4.find(".panel"));
                    
                    newItem.find(".bar").animate({"width":Wi});
                }
            }
            
            var chartContent1=$(".chartContent1");
            chartContent1.find(".item").remove();
            if(options.BeyondMoth&&options.BeyondMoth.data){
                 options.BeyondMoth.data=options.BeyondMoth.data.sort(function(a,b){return a.num<b.num;});
                   var d=options.BeyondMoth.data;
        chartContent1.find(">p.title").text(options.BeyondMoth.Title);
             
                var MaxNum=d[0].num;
                for(var i=0;i<d.length;i++){
                    var _d=d[i];
                    var newItem=$('<div class="item"></div>');
                    $('<div class="name"><div>'+_d.name+'</div><div>('+_d.Adder+')</div></div>').appendTo(newItem);
                    var Wi=330;
                    Wi=Wi*(_d.num/MaxNum);
                    $('<div class="probar"><span class="hexagon">'+(i+1)+'</span><span class="bar"></span></div>').appendTo(newItem);
                     $('<div>'+_d.num+'('+_d.per+')</div>').appendTo(newItem);
                    newItem.appendTo(chartContent1.find(".panel"));
                    newItem.find(".bar").animate({"width":Wi});
                }
            }
            
            
              var chartContent2=$(".chartContent2");
            chartContent2.find(".item").remove();
            if(options.BeyondYear&&options.BeyondYear.data){
                 options.BeyondYear.data=options.BeyondYear.data.sort(function(a,b){return a.num<b.num;});
                 var d=options.BeyondYear.data;
        chartContent2.find(">p.title").text(options.BeyondYear.Title);
                var MaxNum=d[0].num;
                for(var i=0;i<d.length;i++){
                    var _d=d[i];
                    var newItem=$('<div class="item"></div>');
                    $('<div class="name"><div>'+_d.name+'</div><div>('+_d.Adder+')</div></div>').appendTo(newItem);
                    var Wi=300;
                    Wi=Wi*(_d.num/MaxNum);
                    $('<div class="probar"><span class="hexagon">'+(i+1)+'</span><span class="bar"></span></div>').appendTo(newItem);
                     $('<div>'+_d.num+'('+_d.per+')</div>').appendTo(newItem);
                    newItem.appendTo(chartContent2.find(".panel"));
                    newItem.find(".bar").animate({"width":Wi});
                }
            }
        }
        function initAndSetupTheSliders() {
            var inputs = app.inputs;
           var index = 1;
            if(options.gear){
                var sliders=$(".chart_bottom .panel_right");
                $(sliders).find(".title").text(options.gear.Title);
                for(var i=0;i<12;i++){
                    var d=options.gear.data[i];
                    var ranger=sliders.find(".range-slider").eq(i);
                    ranger.find("input").val(d);
                }
            }
           inputs.forEach(function (input) {
              return input.setAttribute('data-slider-index', 'range' + index++);
            });
           inputs.forEach(function (input) {
             return app.updateSlider(input);
           });  
          app.selectPreset('custom');
          $("path.line").addClass("path");
        }
        function initfood(data){
            $(".chartContent5").slideUp(function(){
                $(".chartContent5").empty();
                 if(data){
                 for(var i=0;i<data.length;i++){
                    var d=data[i];
                    var fo=$('<div class="fooditem"><div class="name">'+d.name+'</div><div class="foodtype">'+d.ty+'</div><div class="money">'+d.money+'</div></div>').appendTo($(".chartContent5"));
                }
            }
            $(".chartContent5").slideDown(500);
            });
        }
        var food=$(".chart_bottom .panel_left");
       Init();
        initfood(options.TheVery.data);
        initAndSetupTheSliders();
        return  {initfood:initfood}
    }
})(jQuery,window,document)