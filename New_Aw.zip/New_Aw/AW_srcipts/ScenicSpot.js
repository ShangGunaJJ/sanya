'use strict';
if (!String.prototype.format) {
    String.prototype.format = function () {
        var args = arguments;
        return this.replace(/{(\d+)}/g, function (match, number) {
            return typeof args[number] != 'undefined' ? args[number] : match;
        });
    };
}
var app = function () {
    var $svgLine = document.querySelector('.chartContent6 svg .line');
    var sliderThumbSize = 0;
    var sliderHeight = 120;
    var svgViewBoxHeight = 100;
    var svgViewBoxThumbLimit = sliderThumbSize / 2 * (svgViewBoxHeight / sliderHeight);
    var svgViewBoxGraphMax = svgViewBoxHeight - svgViewBoxThumbLimit;
    var svgViewBoxGraphMin = svgViewBoxThumbLimit;
    var ranges = {
        range1: null,
        range2: null,
        range3: null,
        range4: null,
        range5: null,
        range6: null,
        range7: null,
        range8: null,
        range9: null,
        range10: null,
        range11: null,
        range12: null
    };
    var points = {
        begin: {
            x: 5,
            y: 0
        },
        point1: {
            x: 5,
            y: 0
        },
        control1: {
            x: 5,
            y: 0
        },
        control2: {
            x: 16.5,
            y: 0
        },
        point2: {
            x: 16.5,
            y: 0
        },
        control3: {
            x: 28,
            y: 0
        },
        point3: {
            x: 28,
            y: 0
        },
        control4: {
            x: 39.5,
            y: 0
        },
        point4: {
            x: 39.5,
            y: 0
        },
        control5: {
            x: 51.5,
            y: 0
        },
        point5: {
            x: 51.5,
            y: 0
        },
        control6: {
            x: 63.5,
            y: 0
        },
        point6: {
            x: 63.5,
            y: 0
        },
        control7: {
            x: 75.5,
            y: 0
        },
        point7: {
            x: 75.5,
            y: 0
        },
        control8: {
            x: 87,
            y: 0
        },
        point8: {
            x: 87,
            y: 0
        },
        control9: {
            x: 98.2,
            y: 0
        },
        point9: {
            x: 98.5,
            y: 0
        },
        control10: {
            x: 110.5,
            y: 0
        },
        point10: {
            x: 110.5,
            y: 0
        },
        control11: {
            x: 122,
            y: 0
        },
        point11: {
            x: 122,
            y: 0
        },
        control12: {
            x: 133,
            y: 0
        },
        point12: {
            x: 133,
            y: 0
        }

    };

    function mapDataRange(value) {
        return (value - 0) * (svgViewBoxGraphMax - svgViewBoxGraphMin) / (svgViewBoxHeight - 0) + svgViewBoxGraphMin;
    }

    function updateSlider($element, keyS, line, count) {
        $svgLine = line;
        if ($element) {
            var rangeIndex = $element.getAttribute('data-slider-index'),
                range = ranges[rangeIndex],
                value = $element.value;

            ranges[rangeIndex] = value;
            var parent = $element.parentElement,
                $thumb = parent.querySelector('.range-slider__thumb'),
                $bar = parent.querySelector('.range-slider__bar'),
                pct = (value / keyS) * 100;
            $thumb.style.bottom = pct + '%';
            $bar.style.height = 'calc(' + pct + '% + ' + sliderThumbSize / 2 + 'px)';
            renderSliderGraph(keyS);
        }
    }

    function updatePoints(key) {
        points.point1.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range1 / key | 0;
        points.point2.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range2 / key | 0;
        points.point3.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range3 / key | 0;
        points.point4.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range4 / key | 0;
        points.point5.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range5 / key | 0;
        points.point6.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range6 / key | 0;
        points.point7.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range7 / key | 0;


        points.point8.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range8 / key | 0;
        points.point9.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range9 / key | 0;
        points.point10.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range10 / key | 0;
        points.point11.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range11 / key | 0;
        points.point12.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range12 / key | 0;

        var max = svgViewBoxGraphMax;
        var min = svgViewBoxGraphMin;
        points.point1.y = mapDataRange(points.point1.y);
        points.point2.y = mapDataRange(points.point2.y);
        points.point3.y = mapDataRange(points.point3.y);
        points.point4.y = mapDataRange(points.point4.y);
        points.point5.y = mapDataRange(points.point5.y);
        points.point6.y = mapDataRange(points.point6.y);
        points.point7.y = mapDataRange(points.point7.y);

        points.point8.y = mapDataRange(points.point8.y);
        points.point9.y = mapDataRange(points.point9.y);
        points.point10.y = mapDataRange(points.point10.y);
        points.point11.y = mapDataRange(points.point11.y);
        points.point12.y = mapDataRange(points.point12.y);

        points.begin.y = points.point1.y;
        points.control1.y = points.point1.y;
        points.control2.y = points.point2.y;
        points.control3.y = points.point3.y;
        points.control4.y = points.point4.y;
        points.control5.y = points.point5.y;
        points.control6.y = points.point6.y;
        points.control7.y = points.point7.y;

        points.control8.y = points.point8.y;
        points.control9.y = points.point9.y;
        points.control10.y = points.point10.y;
        points.control11.y = points.point11.y;
        points.control12.y = points.point12.y;
    }

    function getInterpolatedLine(type) {
        return 'M {0},{1} L {2},{3}L {6},{7}L {10} {11}L {14} {15}L {18} {19}L {22} {23}L {26} {27}L{30} {31}L{34} {35}L {38} {39}L {42} {43}L {46} {47}'
            .format(points.begin.x,
                points.begin.y,
                points.point1.x,
                points.point1.y,
                points.control1.x,
                points.control1.y,
                points.control2.x,
                points.control2.y,
                points.point2.x,
                points.point2.y,
                points.control3.x,
                points.control3.y,
                points.point3.x,
                points.point3.y,
                points.control4.x,
                points.control4.y,
                points.point4.x,
                points.point4.y,
                points.control5.x,
                points.control5.y,
                points.point5.x,
                points.point5.y,
                points.control6.x,
                points.control6.y,
                points.point6.x,
                points.point6.y,
                points.control7.x, points.control7.y, points.point7.x, points.point7.y,
                points.control8.x, points.control8.y, points.point8.x, points.point8.y,
                points.control9.x, points.control9.y, points.point9.x, points.point9.y,
                points.control10.x, points.control10.y, points.point10.x, points.point10.y,
                points.control11.x, points.control11.y, points.point11.x, points.point11.y,
                points.control12.x, points.control12.y, points.point12.x, points.point12.y);
    }

    function reset() {
        var inputs = app.inputs;
        inputs.forEach(function (input) {
            return app.updateSlider(input);
        });
    }

   function renderSliderGraph(k,c) {
        updatePoints(k);
        $svgLine.setAttribute('d', getInterpolatedLine(c));
    }

    function selectPreset(key, el) {
        var inputs = app.inputs;
        $svgLine = el;
        inputs.forEach(function (input) {
            return app.updateSlider(input, key);
        });
    }
    return {
        // inputs: [].slice.call(document.querySelectorAll('.sliders input')),
        updateSlider: updateSlider,
        reset: reset,
        selectPreset: selectPreset,
        $svgLine: null,

    };
}();
function Getinteger(MaxNum, aver) {
    MaxNum = (MaxNum * 1).toFixed(0);
    var gNum = Math.pow(10, MaxNum.toString().length - 2) * 2;
    var CNum = Math.pow(10, MaxNum.toString().length - 1);
    while (CNum < MaxNum)
        CNum += CNum;
    CNum -= CNum;
    while (CNum < MaxNum)
        CNum += gNum;
    var aNum = (CNum / aver).toFixed(0);
    if (CNum > 10)
        while (aNum.toString().substring(aNum.toString().length - 1) != "0") {
            aNum = (aNum * 1) + 1;
        }
    return aNum * aver;
}

(function ($, window, document) {
    'use strict';
    $.fn.ScenicSpot = function (options) {
        options = $.extend({
            "WeatherInfo": {
                AdderName: { name: "AILIFANG" },
                "weather": "多云",
                "PM": "10",
                "minLowTemp": "27",
                "maxHighTemp": "33",
                "airQuality": "轻度污染",
                "negativeIonLevel ": "7",
                "windDirection": "西南转东南风3级",
                "forestryCoverage": "50%",
                "tomorrowDayWeather": {
                    "minLowTemp": "21",
                    "weather": "小雨",
                    "maxHighTemp": "29"
                },
                "toDayTimeWeather": {
                    "minLowTemp": "27",
                    "weather": "多云",
                    "maxHighTemp": "33"
                },
                "toDayNightWeather": {
                    "minLowTemp": "25",
                    "weather": "多云",
                    "maxHighTemp": "31"
                },
                "tomorrowNightWeather": {
                    "minLowTemp": "20",
                    "weather": "中雨",
                    "maxHighTemp": "27"
                },
                "DateTime": "2016/10/28"
            },
            "ScenicInfo": {
                updateTime: "2016-10-10 12:32",
                dengji: "AAAAA",
                zhuti: "道教文化风景区",
                mianji: "22.5平方公里",
                jiudian: "五星1家，四星1家",
                fanjiannum: "300间",
                cangguan: "5家",
                tingche: "240个",
                ceshi: "男厕位50，女厕位100",
                jijie: "11月到翌年5月",
                kaifangtiem: "7:30-18:30",
                youwangtiem: "3-4小时",
                weizhi: "三亚市区以西40公里的海滨",
                kefuzhongxin: "54公里",//距离游客中心
                dadi: "约60元",//打的费用
                gongjiao: "25路、7路、9路、34路",//公交线路
                menpiao: "75元",//门票价格
                zaiyuanrenshu: "308",//实时在园人数
                ruyuanrenshu: "9089",//今日累计入园人数
                leijiruyuanrenshu: "34562",//本月累计入园人数
                bili: { n: 93, r: 7 },//当前在园国内与入境游客比例
            },
            "chartdata1": {
                data: [{
                    name: "江西", value: 50
                },
                {
                    name: "江西", value: 50
                }, {
                    name: "江西", value: 50
                }, {
                    name: "江西", value: 50
                }, {
                    name: "江西", value: 50
                }, {
                    name: "江西", value: 50
                }, {
                    name: "江西", value: 50
                }, {
                    name: "江西", value: 50
                }, {
                    name: "江西", value: 50
                }, {
                    name: "江西", value: 50
                }]
            },
            'chartdata2': {
                data: [
                    { name: '2点', value: 5 },
                    { name: '4点', value: 5 },
                    { name: '6点', value: 2 },
                    { name: '8点', value: 4 },
                    { name: '10点', value: 15 },
                    { name: '12点', value: 17 },
                    { name: '14点', value: 20 },
                    { name: '16点', value: 20 },
                    { name: '18点', value: 21 },
                    { name: '20点', value: 25 },
                    { name: '22点', value: 10 },
                    { name: '0点', value: 15 },
                ],
                Title: "最近30天各时段日均受理量分布"
            },
            'chartdata2_1': {
                level: { index: 1, num: 1000 },
                MaxNum: 3000,
                day_Num: 5000,
                Title: "当前景区拥挤指数"
            },
            'chartdata3': {
                data: [{ m: "十月", value: 60 },
                    { m: "十月", value: 20 },
                    { m: "十月", value: 30 },
                    { m: "十月", value: 33 },
                    { m: "十月", value: 10 },
                    { m: "十月", value: 50 },
                    { m: "十月", value: 10 },
                    { m: "十月", value: 60 },
                    { m: "十月", value: 10 },
                    { m: "十月", value: 60 },
                    { m: "十月", value: 10 },
                    { m: "十月", value: 60 }
                ],
                Title: '最近十二个月接待游客人数'
            },
            "chartdata5": { "data": [{ "A": 5430, "B": 0, "name": "天涯海角" }, { "A": 58733, "B": 265, "name": "南山" }, { "A": 79431, "B": 261, "name": "大小洞天" }, { "A": 37653, "B": 49, "name": "蜈支洲岛" }, { "A": 3846, "B": 2, "name": "千古情" }, { "A": 46088, "B": 72, "name": "热带森林公园" }, { "A": 77484, "B": 147, "name": "爱立方" }], "Title": "八大景区当前实时游客数量" },
            'chartdata5_a': {
                // 今日全市累计接待游客数量
                data: [{
                    name: "人数",
                    value: 65033
                }],
                Title: "今日全市累计接待游客数量"
            },
            'chartdata5_b': {
                data: [{
                    name: "国内游客",
                    value: 72654,
                },
                    {
                        name: "国内游客",
                        value: 40005
                    }
                ],
                Title: "全市当前实时游客数量"
            },
            'chartdata5_c': {
                //value也可是百分比
                data: [{
                    name: "散客",
                    value: 72654
                },
                    {
                        name: "团客",
                        value: 40005
                    }],
                Title: "全市游客实时团散比"
            }
        }, options);
        function SetScenicInfo(data) {
            if (data) {
                $(".bili .left").text(data.bili.n + "%").css("width", data.bili.n + "%");
                if(data.bili.n==100)
                {
                  $(".bili .right").hide();
                  $(".bili .left").css("border-radius","16px 16px 16px 16px");
                }else{
                    $(".bili .right").show();
                     $(".bili .left").css("border-radius","16px 0 0 16px");
                }
                $(".bili .right").text(data.bili.r + "%").css("width", data.bili.r + "%");
                
                if(data.bili.r<14)
                    {
                        $(".bili .left").css("width","84%");
                         $(".bili .right").css("width","16%");
                    }
                $(".zaiyuanrenshu").text(data.zaiyuanrenshu);
                $(".ruyuanrenshu").text(data.ruyuanrenshu);
                $(".leijiruyuanrenshu").text(data.leijiruyuanrenshu);

                $(".jijiedata").text(data.jijie);
                $(".kaifangtiemdata").text(data.kaifangtiem);
                $(".youwangdata").text(data.youwangtiem);
                $(".weizhidata").text(data.weizhi);
                $(".kefuzhongxindata").text(data.kefuzhongxin);
                $(".dadidata").text(data.dadi);
                $(".gongjiaodata").text(data.gongjiao);
                $(".menpiaodata").text(data.menpiao);


                $(".cheshidata").text(data.ceshi);
                $(".tingchedata").text(data.tingche);
                $(".cangguandata").text(data.cangguan);
                $(".fangjiandata").text(data.fanjiannum);
                $(".jiudiandata").text(data.jiudian);
                $(".mianjidata").text(data.mianji);
                $(".zhutidata").text(data.zhuti);
                $(".updataTime").text(data.updateTime);
                $(".dengji_abcd").text(data.dengji);

            }
        }
        function SetInfo(data) {
            if (data) {
                var color = "";
                switch (data.AdderName.name) {
                    case "AILIFANG": color = "#e101e1"; break;
                    case "DAXIAODONGTIAN": color = "#dd4712"; break;
                    case "LUHUITOU": color = "#d2c600"; break;
                    case "NANSHAN": color = "#7dd939"; break;
                    case "QIANGU": color = "#eb7a00"; break;
                    case "REDAISUNLING": color = "#00ca00"; break;
                    case "TIANYAHAIJIAO": color = "#3b3b9b"; break;
                    case "WUZHIZHOU": color = "#00b7ee"; break;
                }
                
                $(".Section_weather .Address").find("div:eq(0)").attr("background-image", "url(../Aw_images/scenic/"+data.AdderName.name+".png)");
                $(".Section_weather>div:not(.Address)").css("background", color);

                $(".WeatherInfo_right").find(".TimeDate").text(data.DateTime).end().
                find(".PM").text("PM2.5:" + data.PM).end().
                find(".Wind").text(data.windDirection).end().
                find(".Air_quality").text(data.airQuality).end().
                find(".Timber").text("森林覆盖率 " + data.forestryCoverage).end();

                $(".Tomorrow_night").find(".weathername").text(data.tomorrowNightWeather.weather).end().
                find(".weatherNum").text(data.tomorrowNightWeather.maxHighTemp + "℃/" + data.tomorrowNightWeather.minLowTemp + "℃").end()
               .find(".Weather_ico").css("background", "url(/systatic/Aw_images/scenic/Weater_small/" + returnImgUrl(data.tomorrowNightWeather.weather) + ".png) no-repeat center")

                $(".Tomorrow_Day").find(".weathername").text(data.tomorrowDayWeather.weather).end().
                find(".weatherNum").text(data.tomorrowDayWeather.maxHighTemp + "℃/" + data.tomorrowDayWeather.minLowTemp + "℃").end()
               .find(".Weather_ico").css("background", "url(/systatic/Aw_images/scenic/Weater_small/" + returnImgUrl(data.tomorrowDayWeather.weather) + ".png) no-repeat center")

                $(".Weather_night").find(".weathername").text(data.toDayNightWeather.weather).end().
                find(".weatherNum").text(data.toDayNightWeather.maxHighTemp + "℃/" + data.toDayNightWeather.minLowTemp + "℃").end();
                $(".Weather_night").find(".Weather_ico").css("background", "url(/systatic/Aw_images/scenic/Weater_small/" + returnImgUrl(data.toDayNightWeather.weather) + ".png) no-repeat center")

                $(".Weather_Day").find(".weathername").text(data.toDayTimeWeather.weather).end().
                find(".weatherNum").text(data.toDayTimeWeather.maxHighTemp + "℃/" + data.toDayTimeWeather.minLowTemp + "℃").end()
               .find(".Weather_ico").css("background", "url(/systatic/Aw_images/scenic/Weater_small/" + returnImgUrl(data.toDayTimeWeather.weather) + ".png) no-repeat center")

                $(".Todaytemper").text(data.maxHighTemp + "℃/" + data.minLowTemp + "℃");
                $(".TodayWeather_ico").css("background", "url(/systatic/Aw_images/scenic/Weater_Big/" + returnImgUrl(data.weather) + ".png) no-repeat center")
            }
        }


        function returnImgUrl(name) {
            switch (name) {
                case "暴雪": return "w1"; break;
                case "暴雨": return "w2"; break;
                case "冰雹": return "w3"; break;
                case "大雪": return "w4"; break;
                case "大雨": return "w5"; break;
                case "多云": return "w6"; break;
                case "多云2": return "w7"; break;
                case "浮尘": return "w8"; break;
                case "雷电": return "w9"; break;
                case "雷阵雨": return "w10"; break;
                case "霾": return "w11"; break;
                case "晴天": return "w12"; break;
                case "沙尘暴": return "w13"; break;
                case "霜冻": return "w14"; break;
                case "台风": return "w15"; break;
                case "特大暴雨": return "w16"; break;
                case "雾": return "w17"; break;
                case "小雪": return "w18"; break;
                case "小雨": return "w19"; break;
                case "扬沙": return "w20"; break;
                case "阴天": return "w21"; break;
                case "雨夹雪": return "w22"; break;
                case "阵雨": return "w23"; break;
                case "中雪": return "w24"; break;
                case "中雨": return "w25"; break;
            }
        }
        function Chart2(data) {

            var d = data.data;
            var _data = [];
            var option = {
                title: {
                    text: ''
                },
                tooltip: {},
                legend: {

                },
                radar: {
                    name: {
                        textStyle: {
                            color: "#272727"
                        }
                    },
                    axisLine: {
                        lineStyle: {
                            color: "#0D1422"
                        }
                    }
                    ,
                    splitLine: {
                        lineStyle: {
                            color: "#0D1422"
                        }
                    },
                    splitArea: {
                        areaStyle: {
                            color: ['rgba(250,250,250,0)', 'rgba(200,200,200,0)', 'rgba(200,200,200,0)']
                        }
                    }
                },
                series: [{
                    name: '',
                    type: 'radar',
                    itemStyle: {
                        normal: {
                            color: "#e71931",
                            borderWidth: 3,
                            areaStyle: {
                                color: "#01B5B5",
                                opacity: ".3"
                            }
                        }
                    },

                    lineStyle: {
                        normal: {
                            color: "#EA68A2"
                        }
                    },
                    data: [
                        {
                            value: [],
                            name: ''
                        }
                    ]
                }]
            };
            for (var i = (d.length - 1) ; i >= 0; i--) {
                _data.push(d[i].value);
            }
            option.series[0].data[0].value = _data;

            var concat = Math.max.apply(null, _data);
            var indicator = [];
            for (var j = (d.length - 1) ; j >= 0; j--) {
                var obj = {};
                obj.name = d[j].name;
                obj.max = concat;
                indicator.push(obj);
            }
            option.radar.indicator = indicator;
            var myChart = echarts.init(document.getElementById('chat3'));
            myChart.setOption(option);
        }
        function Chart2_1(data) {
            if (data) {
                $(".chart1 .label").removeClass().addClass("label  active" + data.level.index + "");
                $(".chart1 .label .num").text(data.level.num + "人");
                $(".chart1_maxpeople").text(data.MaxNum + "人");
                $(".chart1_daypeople").text(data.day_Num + "人");
            }
        }
        function Chart1(data) {
            if (data) {
                var chartContent3 = $(".chart3");
                chartContent3.parent().find(".title").text(data.Title);
                var MaxData = data.data.sort(function (a, b) {
                    return a.value < b.value
                });

                var MaxHtml = '<div class="item bar"><div class="name"></div><div class="probar"><span class="hexagon"><span></span></span><span class="barline"><span></span> </span> </div></div>';
                var MaxMan = chartContent3.find(".content");
                MaxMan.find(".item").hide().remove();
                for (var i = 0; i < MaxData.length; i++) {
                    var _d = MaxData[i];
                    var newItem = $(MaxHtml).appendTo(MaxMan);
                    newItem.find(".name").text(_d.name);
                    newItem.find(".hexagon").find("span").text(i + 1);
                    newItem.find(".barline span").text(_d.value);
                    var Wi = 0;
                    Wi = 260 * (_d.value / MaxData[0].value);
                    newItem.find(".barline").animate({
                        "width": Wi
                    });
                }
            }
        }
        function chart3(data) {
            if (data) {
                if (data) {
                    var chartContent3 = $(".chart4");
                    chartContent3.find(".title").text(data.Title);

                    var MaxNum = 0;
                    var d = data.data;
                    for (var i = 0; i < d.length; i++) {
                        var _d = d[i];
                        chartContent3.find(".range-slider").eq(i).find("input").val(_d.value);
                        if (MaxNum < _d.value)
                            MaxNum = _d.value;
                        chartContent3.find(".range-slider").eq(i).find(".range-slider_lab").text(_d.m);
                    }
                    MaxNum = Getinteger(MaxNum, 9);
                    chartContent3.find(".range-slider").attr("max", MaxNum);
                    for (var f = 0; f < 9; f++) {
                        chartContent3.find(".tickline>div").eq(f).find("span").text(((MaxNum / 9) * (9 - f)).toFixed(0));
                    }

                    app.inputs = [].slice.call(document.querySelectorAll('.chart4 input'));
                    var inputs = app.inputs;
                    var index = 1;
                    var p = document.querySelector('.chart4  svg .line');
                    inputs.forEach(function (input) {
                        return input.setAttribute('data-slider-index', 'range' + index++);
                    });
                    inputs.forEach(function (input) {
                         return app.updateSlider(input, MaxNum, p);
                    })
                }
            }
        }
        function Chart5(data) {
            if (data) {
                var d = data.data;
                var MaxNum = 0;
                var chartContent1 = $(".chartContent");
                $(".chartContent1 .title").text(data.Title);
                chartContent1.find(".bar").css({
                    "height": 0
                });
                setTimeout(function () {
                    for (var i = 0; i < d.length; i++) {
                        if (MaxNum < d[i].A)
                            MaxNum = d[i].A;
                        if (MaxNum < d[i].B)
                            MaxNum = d[i].B;
                    }
                    MaxNum = Getinteger(MaxNum, 5);
                    if (MaxNum > 80)
                        for (var f = 0; f < 6; f++) {
                            chartContent1.find(".footer>div").eq(f).find("span").text(((MaxNum / 5) * (5 - f)).toFixed(0));
                        }
                    else
                        MaxNum = 80;
                    chartContent1.find(".bar").css("height", 0);
                    for (var y = 0; y < d.length; y++) {
                        var _d = d[y];
                        var itme = chartContent1.find(".colpanel").eq(y);
                        itme.find(".column").eq(0).find(".bar").animate({
                            "height": (150 * (_d.A / MaxNum))
                        });
                        itme.find(".column").eq(1).find(".bar").animate({
                            "height": (150 * (_d.B / MaxNum))
                        });
                        itme.find(".lableName").text(_d.name);
                    }
                }, 300);
            }
        }
        function Chart5_a(data) {
            if (data) {
                var d = data.data;
                var MaxNum = Math.round(d[0].value / 50000);
                if (MaxNum > 1) MaxNum = 1;
                var chartContent1 = $(".Section5>.left");

                chartContent1.find(".content>p").text(d[0].value + "人");
                chartContent1.find(".Column").css("height", MaxNum * 100 + "%");
            }
        }

        function Chart5_b(data) {
            if (data) {
                var d = data.data;
                var Total = d[0].value + d[1].value;
                var domestic = d[0];
                var abroad = d[1];
                var domestic_pr = domestic.value > abroad.value ? 240 : Math.round(domestic.value / abroad.value * 260);
                var abroad_pr = abroad.value > domestic.value ? 240 : Math.round(abroad.value / domestic.value * 260);
                var chartContent1 = $(".chartContent_b .left");
if(abroad_pr<46)
    abroad_pr=46;

                chartContent1.find(".total > span").text(Total + "人");
                chartContent1.find(".domestic .people_num").text(domestic.value + "人");
                chartContent1.find(".domestic .graphical").css("width", domestic_pr);
                chartContent1.find(".abroad .graphical").css("width", abroad_pr);
                chartContent1.find(".abroad .people_num").text(abroad.value + "人");

                chartContent1.find(".domestic .name").text(domestic.name);
                chartContent1.find(".abroad .name").text(domestic.name);

            }
        }

        function Chart5_c(data) {
            if (data) {
                var d = data.data;
                var chartContent1 = $(".chartContent_b .right");
                var domestic_pr, abroad_pr;

                if (d.indexOf("%") < 0) {
                    var Total = d[0].value + d[1].value;
                    domestic_pr = Math.round(d[0].value / Total * 100) + "%";
                    abroad_pr = Math.round(d[1].value / Total * 100) + "%";
                } else {
                    domestic_pr = d[0].value;
                    abroad_pr = d[1].value;
                }

                chartContent1.find(".graphical_b").css("width", domestic_pr);
                chartContent1.find(".graphical_b>span").text(domestic_pr);
                chartContent1.find(".abroad_b").css("width", abroad_pr);
                chartContent1.find(".abroad_b>span").text(abroad_pr);




            }
        }

        Chart5(options.chartdata5);
        Chart5_a(options.chartdata5_a);
        Chart5_b(options.chartdata5_b);
        Chart5_c(options.chartdata5_c);
        Chart1(options.chartdata1)
        Chart2(options.chartdata2);
        Chart2_1(options.chartdata2_1);
        chart3(options.chartdata3);
        SetInfo(options.WeatherInfo);
        SetScenicInfo(options.ScenicInfo);
    }
})(jQuery, window, document)