'use strict';
if (!String.prototype.format) {
    String.prototype.format = function () {
        var args = arguments;
        return this.replace(/{(\d+)}/g, function (match, number) {
            return typeof args[number] != 'undefined' ? args[number] : match;
        });
    };
}
var app = function () {
    var $svgLine = document.querySelector('.chartContent6 svg .line');
    var sliderThumbSize = 0;
    var sliderHeight = 90;
    var svgViewBoxHeight = 100;
    var svgViewBoxThumbLimit = sliderThumbSize / 2 * (svgViewBoxHeight / sliderHeight);
    var svgViewBoxGraphMax = svgViewBoxHeight - svgViewBoxThumbLimit;
    var svgViewBoxGraphMin = svgViewBoxThumbLimit;
    var ranges = {
        range1: null,
        range2: null,
        range3: null,
        range4: null,
        range5: null
    };
    var points = {
        begin: {
            x: 15,
            y: 0
        },
        control1: {
            x: 30,
            y: 10
        },
        point1: {
            x: 15,
            y: 0
        },
        control2: {
            x: 30,
            y: 0
        },
        point2: {
            x: 45,
            y: 0
        },
        control3: {
            x: 45,
            y: 0
        },
        point3: {
            x: 78,
            y: 0
        },
        control4: {
            x: 80,
            y: 0
        },
        point4: {
            x: 96,
            y: 0
        },
        control5: {
            x: 96,
            y: 0
        },
        point5: {
            x: 125,
            y: 0
        },
    };
    function mapDataRange(value) {
        return (value - 0) * (svgViewBoxGraphMax - svgViewBoxGraphMin) / (svgViewBoxHeight - 0) + svgViewBoxGraphMin;
    }
    function updateSlider($element, keyS, line, count) {
        $svgLine = line;
        if ($element) {
            var rangeIndex = $element.getAttribute('data-slider-index'), range = ranges[rangeIndex], value = $element.value;
            ranges[rangeIndex] = value;
            var parent = $element.parentElement, $thumb = parent.querySelector('.range-slider__thumb'), $bar = parent.querySelector('.range-slider__bar'),
            pct = (value / keyS) * 100;
            $thumb.style.bottom = pct + '%';
            $bar.style.height = 'calc(' + pct + '% + ' + sliderThumbSize / 2 + 'px)';
            renderSliderGraph(keyS);
        }
    }
    function updatePoints(key) {
        points.point1.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range1 / key | 0;
        points.point2.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range2 / key | 0;
        points.point3.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range3 / key | 0;
        points.point4.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range4 / key | 0;
        points.point5.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range5 / key | 0;


        var max = svgViewBoxGraphMax;
        var min = svgViewBoxGraphMin;
        points.point1.y = mapDataRange(points.point1.y);
        points.point2.y = mapDataRange(points.point2.y);
        points.point3.y = mapDataRange(points.point3.y);
        points.point4.y = mapDataRange(points.point4.y);
        points.point5.y = mapDataRange(points.point5.y);

        points.begin.y = points.point1.y;
        points.control1.y = points.point1.y;
        points.control2.y = points.point2.y;
        points.control3.y = points.point3.y;
        points.control4.y = points.point4.y;
        points.control5.y = points.point5.y;
    }
    function getInterpolatedLine(type) {
        return 'M {0},{1} L {2},{3} C {4},{5} {6},{7} {8},{9} S {10} {11}, {12} {13} S {14} {15}, {16} {17} S {18} {19}, {20} {21}'
        .format(points.begin.x, points.begin.y,
        points.point1.x, points.point1.y, points.control1.x, points.control1.y,
        points.control2.x, points.control2.y, points.point2.x, points.point2.y,
        points.control3.x, points.control3.y, points.point3.x, points.point3.y,
        points.control4.x, points.control4.y, points.point4.x, points.point4.y,
        points.control5.x, points.control5.y, points.point5.x, points.point5.y);
    }
    function reset() {
        var inputs = app.inputs;
        inputs.forEach(function (input) {
            return app.updateSlider(input);
        });
    }
    function renderSliderGraph(k, c) {
        updatePoints(k);
        $svgLine.setAttribute('d', getInterpolatedLine(c));
    }
    function selectPreset(key, el) {
        var inputs = app.inputs;
        $svgLine = el;
        inputs.forEach(function (input) {
            return app.updateSlider(input, key);
        });
    }
    return {
        inputs: [].slice.call(document.querySelectorAll('.sliders input')),
        updateSlider: updateSlider,
        reset: reset,
        selectPreset: selectPreset,
        $svgLine: null,

    };
}();
function Getinteger(MaxNum, aver) {
    MaxNum = (MaxNum * 1).toFixed(0);
    var gNum = Math.pow(10, MaxNum.toString().length - 2) * 2;
    var CNum = Math.pow(10, MaxNum.toString().length - 1);
    while (CNum < MaxNum)
        CNum += CNum;
    CNum -= CNum;
    while (CNum < MaxNum)
        CNum += gNum;
    var aNum = (CNum / aver).toFixed(0);
    if (CNum > 10)
        while (aNum.toString().substring(aNum.toString().length - 1) != "0") {
            aNum = (aNum * 1) + 1;
        }
    return aNum * aver;
}


(function ($, window, document) {
    'use strict';
    $.fn.Dan_Arc = function (options) {
        options = $.extend({
            'panelleft': { title: "三亚市党组织信息统计数据", count: 12174 },
            'panelMiddel': { title: "三亚市党员信息统计数据", count: 12714 },
            panelright: { title: "三亚党建红云应用信息统计数据" },
            'chartdata1': {
                data: [{ name: "党 委", num: 89 },
                { name: "工 委", num: 8 },
                { name: "党 总 支", num: 228 },
                { name: "党 支 部", num: 1028 }
                ],
                Title: "全市党组织类别分布"
            },
            'chartdata2': {
                data: [{ name: "党政机关", num: 89 },
                { name: "党政机关", num: 8 },
                { name: "党 总 支", num: 228 },
                { name: "党 支 部", num: 1028 },
                 { name: "党 支 部", num: 500 },
                  { name: "党 支 部", num: 600 },
                   { name: "党 支 部", num: 700 }
                ],
                Title: "全市党组织类别分布"
            },
            'chartdata3': {
                data: { wman: 6348, man: 19044 },
                Title: "全市党员性别分布"
            },
            'chartdata4': {
                data: { han: 7774, li: 2539, miao: 2285, hui: 2013, o: 120 },
                Title: "全市党员民族分布"
            },
            'chartdata5': {
                data: [
                    { name: "研究生", num: 1000 },
                   { name: "研究生", num: 1000 },
                    { name: "研究生", num: 1000 },
                     { name: "研究生", num: 1000 },
                   { name: "研究生", num: 10000 },
                    { name: "研究生", num: 1000 },
                     { name: "研究生", num: 1000 },
                   { name: "研究生", num: 10000 }
                ],
                Title: "全市党员学历分布"
            },
            'chartdata6': {
                data: [
                    { name: "20-30岁", num: 1000 },
                   { name: "30-40岁", num: 1000 },
                    { name: "40-50岁", num: 1000 },
                     { name: "50-60岁", num: 1000 },
                   { name: "70-80岁", num: 10000 },
                    { name: "80岁以上", num: 1000 }
                ],
                Title: "全市党员年龄分布"
            },
            'chartdata7': {
                data: [{ name: "党政机关党员", num: 8000 },
                { name: "事业单位党员", num: 608 },
                { name: "国有企业党员", num: 2000 },
                { name: "非公企业党员", num: 1028 },
                 { name: "社会组织党员", num: 500 },
                  { name: "农村党员", num: 1600 },
                   { name: "党 支 部", num: 700 }
                ],
                Title: "全市党员类型分布"
            },
            'chartdata8': {
                data: [
                    { name: "新闻动态", up: 2, click: 50 },
                   { name: "关注三亚", up: 2, click: 50 },
                    { name: "组工要闻", up: 2, click: 50 },
                      { name: "通知公告", up: 2, click: 50 },
                        { name: "党员课堂", up: 2, click: 50 },
                          { name: "政策法规", up: 2, click: 50 }
                ],
                Title: "全市党员学历分布"
            },
            'chartdata9': {
                data: [
                  { name: "10月17日", dati: 166, login: 500 },
                   { name: "10月17日", dati: 500, login: 500 },
                    { name: "10月17日", dati: 100, login: 400 },
                     { name: "10月18日", dati: 200, login: 300 },
                      { name: "10月17日", dati: 500, login: 100 }
                ],
                Title: "党员学习问答统计数据"
            },
            "chartdata9": {
                "data": [{ "name": "2016-10-31", "login": 166, "dati": 42 },
                    { "name": "2016-10-28", "login": 185, "dati": 38 },
                    { "name": "2016-10-27", "login": 185, "dati": 42 },
                    { "name": "2016-10-26", "login": 154, "dati": 37 },
                    { "name": "2016-10-25", "login": 158, "dati": 35 }], "Title": "党员学习问答统计数据"
            },
            'chartdata10': {
                data: {
                    Arealist: ['10月22日-28日', '10月22日-28日', '10月22日-28日', '10月22日-28日'], Caldata: [
                        { data: [6, 1, 1, 0] },//水下运动
                        { data: [1, 0, 1, 0] },//户外运动
                        { data: [5, 8, 1, 1] },//KTV
                        { data: [0, 1, 5, 1] },//俱乐部
                        { data: [2, 8, 5, 10] }//休闲场所
                    ]
                }, Title: "三亚市各区域娱乐场所统计"
            },
            'upDatatime': { time: "2016-10-10 12:35" }
        }, options);

        function setTitle() {
            $(".panel_left_title>div:eq(0)").text(options.panelleft.title);
            $(".panelleftNum").text(options.panelleft.count);
            $(".panel_middle_title>div:eq(0)").text(options.panelMiddel.title);
            $(".panelMiddleNum").html(options.panelMiddel.count);
            $(".panel_right_title").text(options.panelright.title);
        }
        function Chart1(data) {
            if (data) {
                var d = data.data;
                var MaxNum = 0;
                var cccc = $(".panel_left .content_top");
                $(cccc).find(".content_title").text(data.Title);
                cccc.find(".bar").css({
                    "height": 0
                });
                setTimeout(function () {
                    for (var i = 0; i < d.length; i++) {
                        if (MaxNum < d[i].num)
                            MaxNum = d[i].num;
                    }
                    MaxNum = Getinteger(MaxNum, 4);
                    for (var f = 0; f < 5; f++) {
                        cccc.find(".chart_tick>div").eq(f).find("span").text(((MaxNum / 4) * (4 - f)).toFixed(0));
                    }
                    cccc.find(".bar").css("height", 0);
                    for (var y = 0; y < d.length; y++) {
                        var _d = d[y];
                        var itme = cccc.find(".colpanel").eq(y);
                        itme.find(".column").eq(0).find(".bar").animate({
                            "height": (180 * (_d.num / MaxNum))
                        });
                        itme.find(".Num").text(_d.num);
                        itme.find(".lableName").text(_d.name);
                    }
                }, 300);
            }
        }
        function Chart2(data) {
            if (data) {
                var d = data.data;
                var MaxNum = 0;
                var cccc = $(".panel_left .content_bottom");
                $(cccc).find(".content_title").text(data.Title);
                cccc.find(".bar").css({
                    "height": 0
                });
                setTimeout(function () {
                    d = d.sort(function (a, b) { return a.num < b.num; });
                    MaxNum = d[0].num;
                    MaxNum = Getinteger(MaxNum, 3);
                    for (var f = 3; f > 0; f--) {
                        cccc.find(".vertical_tick>div").eq(f).find("span").text(((MaxNum / 3) * (f)).toFixed(0));
                    }
                    var html = '<div class="vertical_col">' +
                        '<div class="lableName"></div>' +
                           '<div class="bar"><div class="Num"></div></div>' +
                        '</div>';
                    cccc.find(".vertical_col").remove();
                    for (var y = 0; y < d.length; y++) {
                        var _d = d[y];
                        var itme = $(html).insertBefore(cccc.find(".vertical_tick"));
                        itme.find(".bar").animate({
                            "width": (246 * (_d.num / MaxNum))
                        });
                        itme.find(".Num").text(_d.num);
                        itme.find(".lableName").text(_d.name);
                    }
                }, 300);
            }
        }
        function Chart3(data) {
            if (data) {
                var Mcontent1 = $(".Mcontent1 .contentleft");
                Mcontent1.find(".content_title").text(data.Title);
                var sum = data.data.wman + data.data.man;
                var wss = (data.data.wman / sum).toFixed(2) * 100;
                var mansss = 100 - wss;
                Mcontent1.find(".left,.right").css("width", 0);
                setTimeout(function () {
                    Mcontent1.find(".left").animate({ "width": wss + "%" }).text(data.data.wman).end()
                    .find(".right").animate({ "width": mansss + "%" }).text(data.data.man);
                }, 500);
            }
        }
        function Chart4(data) {
            if (data) {
                var Mcontent1 = $(".Mcontent1 .contentright");
                Mcontent1.find(".content_title").text(data.Title);
                var ddd = data.data;
                var sum = ddd.han + ddd.li + ddd.miao + ddd.hui + ddd.o;
                var fn = function (a) {
                    var w = (a / sum).toFixed(2) * 296;
                    if (a < 100 && w < 16)
                        w = 16;
                    else if (a < 1000 && w < 26)
                        w = 26;
                    else if (a < 10000 && w < 34)
                        w = 34
                    else if (a < 100000 && w < 45)
                        w = 45;
                    return w;
                }
                var h = fn(ddd.han);
                var l = fn(ddd.li);
                var m = fn(ddd.miao);
                var hui = fn(ddd.hui);
                var o = fn(ddd.o);
                var sums = h + l + m + hui + o;
                if (sums > 296) {
                    h = 296 - l - m - hui - o;
                }
                Mcontent1.find(".bilipanel").css("width", "296px");
                Mcontent1.find(".bilipanel>div").css("width", 0);
                setTimeout(function () {
                    Mcontent1
                    .find(".han").animate({ "width": h + "px" }).text(ddd.han).end()
                    .find(".li").animate({ "width": l + "px" }).text(ddd.li).end()
                     .find(".miao").animate({ "width": m + "px" }).text(ddd.miao).end()
                      .find(".hui").animate({ "width": hui + "px" }).text(ddd.hui).end()
                       .find(".other").animate({ "width": o + "px" }).text(ddd.o).end();
                }, 500);
            }
        }
        function Chart5(data) {
            if (data) {
                var d = data.data;
                var MaxNum = 0;
                var cccc = $(".Mcontent2 .contentleft");
                $(cccc).find(".content_title").text(data.Title);

                setTimeout(function () {
                    for (var i = 0; i < d.length; i++) {
                        if (MaxNum < d[i].num)
                            MaxNum = d[i].num;
                    }
                    MaxNum = Getinteger(MaxNum, 2);
                    for (var f = 0; f < 3; f++) {
                        cccc.find(".chart_tick>div").eq(f).find("span").text(((MaxNum / 2) * (2 - f)).toFixed(0));
                    }
                    cccc.find(".colpanel").remove();
                    var html = '<div class="colpanel"><div class="column"><div class="Num"></div><div class="bar"></div></div><div class="lableName"></div></div>';
                    for (var y = 0; y < d.length; y++) {
                        var _d = d[y];
                        var itme = $(html).insertBefore(cccc.find(".chart_tick"));
                        itme.css("left", (((340 / d.length)) * y) + 5);
                        itme.find(".column").eq(0).find(".bar").animate({
                            "height": (112 * (_d.num / MaxNum))
                        });
                        itme.find(".Num").text(_d.num);
                        itme.find(".lableName").text(_d.name);
                    }
                }, 300);
            }
        }
        function Chart6(data) {
            if (data) {
                var d = data.data;
                var MaxNum = 0;
                var cccc = $(".Mcontent2 .contentright");
                $(cccc).find(".content_title").text(data.Title);

                setTimeout(function () {
                    for (var i = 0; i < d.length; i++) {
                        if (MaxNum < d[i].num)
                            MaxNum = d[i].num;
                    }
                    MaxNum = Getinteger(MaxNum, 2);
                    for (var f = 0; f < 3; f++) {
                        cccc.find(".chart_tick>div").eq(f).find("span").text(((MaxNum / 2) * (2 - f)).toFixed(0));
                    }
                    cccc.find(".colpanel").remove();
                    var html = '<div class="colpanel"><div class="column"><div class="Num"></div><div class="bar"></div></div><div class="lableName"></div></div>';
                    for (var y = 0; y < d.length; y++) {
                        var _d = d[y];
                        var itme = $(html).insertBefore(cccc.find(".chart_tick"));
                        itme.css("left", (((300 / d.length)) * y));
                        itme.find(".column").eq(0).find(".bar").animate({
                            "height": (112 * (_d.num / MaxNum))
                        });
                        itme.find(".Num").text(_d.num);
                        itme.find(".lableName").text(_d.name);
                    }
                }, 300);
            }
        }
        function Chart7(data) {
            if (data) {
                var d = data.data;
                var MaxNum = 0;
                var cccc = $(".Mcontent3");
                $(cccc).find(".content_title").text(data.Title);
                cccc.find(".bar").css({
                    "height": 0
                });
                setTimeout(function () {
                    d = d.sort(function (a, b) { return a.num < b.num; });
                    MaxNum = d[0].num;
                    for (var f = 5; f > 0; f--) {
                        cccc.find(".vertical_tick>div").eq(f).find("span").text(((MaxNum / 5) * (f)).toFixed(0));
                    }
                    var html = '<div class="vertical_col">' +
                        '<div class="lableName"></div>' +
                           '<div class="bar"><div class="Num"></div></div>' +
                        '</div>';
                    cccc.find(".vertical_col").remove();
                    for (var y = 0; y < d.length; y++) {
                        var _d = d[y];
                        var itme = $(html).insertBefore(cccc.find(".vertical_tick"));
                        itme.find(".bar").animate({
                            "width": (325 * (_d.num / MaxNum))
                        });
                        itme.find(".Num").text(_d.num);
                        itme.find(".lableName").text(_d.name);
                    }
                }, 300);
            }
        }
        function Chart8(data) {
            if (data) {
                var d = data.data;
                var MaxNum = 0;
                var cccc = $(".Rcontent1");
                $(cccc).find(".content_title").text(data.Title);

                setTimeout(function () {
                    for (var i = 0; i < d.length; i++) {
                        if (MaxNum < d[i].up)
                            MaxNum = d[i].up;
                        if (MaxNum < d[i].click)
                            MaxNum = d[i].click;
                    }
                    MaxNum = (MaxNum * 1) + 10;
                    for (var f = 0; f < 3; f++) {
                        cccc.find(".chart_tick>div").eq(f).find("span").text(((MaxNum / 3) * (3 - f)).toFixed(0));
                    }
                    cccc.find(".colpanel").remove();
                    var html = '<div class="colpanel"><div class="column"><div class="Num"></div><div class="bar"></div>' +
                       '</div><div class="column"><div class="Num"></div><div class="bar"></div> </div><div class="lableName"></div></div>';
                    for (var y = 0; y < d.length; y++) {
                        var _d = d[y];
                        var itme = $(html).insertBefore(cccc.find(".chart_tick"));
                        itme.css("left", (((280 / d.length) + 10) * y) + 20);
                        itme.find(".column").eq(0).find(".Num").text(_d.up).end().find(".bar").animate({
                            "height": (90 * (_d.up / MaxNum))
                        });
                        itme.find(".column").eq(1).find(".Num").text(_d.click).end().find(".bar").animate({
                            "height": (90 * (_d.click / MaxNum))
                        });
                        itme.find(".lableName").text(_d.name);
                    }
                }, 300);
            }
        }
        function Chart9(data) {
            if (data) {
                var Rcontent2 = $(".Rcontent2");
                Rcontent2.find(".title").text(data.Title);
                var xdata = [];
                var ydata = [];
                var MaxNum = 0;
                var d = data.data;
                for (var i = 0; i < d.length; i++) {
                    var _d = d[i];
                    if (MaxNum < _d.dati)
                        MaxNum = _d.dati;
                    if (MaxNum < _d.login)
                        MaxNum = _d.login;
                    xdata.push({
                        value: "",
                        textStyle: {
                            color: "rgba(0, 160, 233,1)"
                        }
                    });
                    $(".Period>div").eq(i).find("span").text(_d.name);
                }
                MaxNum = Getinteger(MaxNum, 3);
                ydata.push({
                    type: 'line',
                    data: [data.data[0].dati, data.data[1].dati, data.data[2].dati, data.data[3].dati, data.data[4].dati],
                    symbol: "circle",
                    max: 80,
                    symbolSize: 10,
                    lineStyle: {
                        normal: {
                            color: "#00A0E9"
                        }
                    }, label: {
                        normal: {
                            show: true,
                            fontFamily: "Microsoft YaHei"
                        }
                    },
                    itemStyle: {
                        normal: {
                            color: "#00A0E9"
                        }
                    }
                });
                ydata.push({
                    type: 'line',
                    data: [data.data[0].login, data.data[1].login, data.data[2].login, data.data[3].login, data.data[4].login],
                    symbol: "circle",
                    max: 1000,
                    symbolSize: 10,
                    label: {
                        normal: {
                            show: true,
                            fontFamily: "Microsoft YaHei"
                        }
                    },
                    lineStyle: {
                        normal: {
                            color: "#B9540F"
                        }
                    },
                    itemStyle: {
                        normal: {
                            color: "#B9540F"
                        }
                    }
                });

                for (var f = 0; f < 4; f++) {
                    Rcontent2.find(".tickline>div").eq(f).find("span").text(((MaxNum / 3) * (3 - f)).toFixed(0));
                }


                var option = {
                    title: {
                        show: false,
                        text: '对数轴示例',
                        left: 'center'
                    },
                    tooltip: {
                        show: false,
                        trigger: 'item',
                        formatter: '{a} <br/>{b} : {c}'
                    },
                    legend: {
                        show: false
                    },
                    xAxis: {
                        type: 'category',
                        name: '',
                        boundaryGap: false,
                        offset: 6,
                        splitLine: {
                            show: true,
                            lineStyle: {
                                type: "dashed",
                                color: "rgba(0, 160, 233, 0.3)"
                            }
                        },
                        axisTick: {
                            show: false,
                            alignWithLabel: false
                        },
                        axisLine: {
                            show: false
                        },
                        data: xdata
                    },
                    grid: {
                        show: false,
                        top: 20,
                        width: 320,
                        left: 0,
                        right: "0",
                        height: 90,
                        containLabel: true
                    },
                    yAxis: {
                        type: 'value',
                        splitNumber: 5,
                        max: MaxNum,
                        splitLine: {
                            lineStyle: {
                                type: "dashed",
                                color: "rgba(0, 160, 233,0)"
                            }
                        },
                        axisLine: {
                            show: false
                        },
                        axisTick: {
                            show: false,
                            alignWithLabel: false
                        },
                        axisLabel: {
                            textStyle: {
                                color: "rgba(0, 160, 233,0)"
                            }
                        }
                    },
                    series: ydata
                };
                var myChart = echarts.init(document.getElementById('Echart2'));
                myChart.setOption(option);
            }
        }
        function Chart10(data) {
            if (data) {
                $('#chart10').highcharts({
                    chart: {
                        type: 'bar',
                        backgroundColor: "transparent",
                        plotBackgroundColor: null,
                        plotBorderWidth: null,
                        plotShadow: false,
                        marginTop: 0,
                    },
                    title: {
                        text: ''
                    },
                    credits: {
                        enabled: false,
                    },
                    legend: {
                        enabled: false,
                    },
                    tooltip: {
                        pointFormat: ' <b>{point.y}</b><br/>',
                    },
                    xAxis: {
                        categories: data.data.Arealist,
                        tickWidth: 0,
                        gridLineWidth: 0,
                        gridLineColor: "rgba(1, 181, 181, 0)",
                        labels: {
                            style: {
                                color: '#01B5B5'
                            }
                        }
                    },
                    yAxis: {
                        enabled: false,
                        min: 0,
                        title: {
                            text: ''
                        },
                        gridLineColor: "rgba(1, 181, 181, 0.41)",
                        gridLineDashStyle: "ShortDot",
                        lineWidth: 0,
                        labels: {
                            style: {
                                color: '#fff',
                            }
                        }
                    },
                    plotOptions: {
                        series: {
                            borderColor: 'transparent',
                            stacking: 'normal',
                            dataLabels: {
                                enabled: true,
                                format: '{y}',
                                verticalAlign: "middle",
                                style: {
                                    "color": "#fff",
                                    "fontWeight": 500
                                },
                            },

                        },

                    },
                    colors: ['#83AE27', '#B9540F', '#2384AF', '#5F52A0'],
                    series: data.data.Caldata
                });
                $(".highcharts-label.highcharts-data-label tspan").each(function () {
                    if ($(this).text() == 0)
                        $(this).text("");
                });
                $(".highcharts-label.highcharts-data-label text").each(function () {
                    $(this).attr("y", 17);
                });
                $(".highcharts-axis.highcharts-xaxis ").hide();
            }
        }
        function Updata(time) {
            $(".TimeDate").text(time).stop().slideDown();
        }
        Chart1(options.chartdata1);
        Chart2(options.chartdata2);
        Chart3(options.chartdata3);
        Chart4(options.chartdata4);
        Chart5(options.chartdata5);
        Chart6(options.chartdata6);
        Chart7(options.chartdata7);
        Chart8(options.chartdata8);
        Chart9(options.chartdata9);
        Chart10(options.chartdata10);
        setTitle();
        Updata(options.upDatatime.time);
        return {
            loadChart1: Chart1,
            loadChart2: Chart2,

            Updata: Updata
        }
    }
})(jQuery, window, document)
