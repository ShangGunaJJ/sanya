'use strict';
if (!String.prototype.format) {
    String.prototype.format = function () {
        var args = arguments;
        return this.replace(/{(\d+)}/g, function (match, number) {
            return typeof args[number] != 'undefined' ? args[number] : match;
        });
    };
}
var app = function () {
    var $svgLine = document.querySelector('.chartContent6 svg .line');
    var sliderThumbSize = 0;
    var sliderHeight = 200;
    var svgViewBoxHeight = 100;
    var svgViewBoxThumbLimit = sliderThumbSize / 2 * (svgViewBoxHeight / sliderHeight);
    var svgViewBoxGraphMax = svgViewBoxHeight - svgViewBoxThumbLimit;
    var svgViewBoxGraphMin = svgViewBoxThumbLimit;
    var ranges = {
        range1: null,
        range2: null,
        range3: null,
        range4: null,
        range5: null,
        range6: null,
        range7: null,
        range8: null,
        range9: null,
        range10: null,
        range11: null,
        range12: null
    };
    var points = {
        begin: {
            x: 5,
            y: 0
        },
        point1: {
            x: 5,
            y: 0
        },
        control1: {
            x: 5,
            y: 0
        },
        control2: {
            x: 16.5,
            y: 0
        },
        point2: {
            x: 16.5,
            y: 0
        },
        control3: {
            x: 28,
            y: 0
        },
        point3: {
            x: 28,
            y: 0
        },
        control4: {
            x: 39.5,
            y: 0
        },
        point4: {
            x: 39.5,
            y: 0
        },
        control5: {
            x: 51.5,
            y: 0
        },
        point5: {
            x: 51.5,
            y: 0
        },
        control6: {
            x: 63.5,
            y: 0
        },
        point6: {
            x: 63.5,
            y: 0
        },
        control7: {
            x: 75.5,
            y: 0
        },
        point7: {
            x: 75.5,
            y: 0
        },
        control8: {
            x: 87,
            y: 0
        },
        point8: {
            x: 87,
            y: 0
        },
        control9: {
            x: 98.2,
            y: 0
        },
        point9: {
            x: 98.5,
            y: 0
        },
        control10: {
            x: 110.5,
            y: 0
        },
        point10: {
            x: 110.5,
            y: 0
        },
        control11: {
            x: 122,
            y: 0
        },
        point11: {
            x: 122,
            y: 0
        },
        control12: {
            x: 133,
            y: 0
        },
        point12: {
            x: 133,
            y: 0
        }

    };
    function mapDataRange(value) {
        return (value - 0) * (svgViewBoxGraphMax - svgViewBoxGraphMin) / (svgViewBoxHeight - 0) + svgViewBoxGraphMin;
    }
    function updateSlider($element, keyS, line, count) {
        $svgLine = line;
        if ($element) {
            var rangeIndex = $element.getAttribute('data-slider-index'), range = ranges[rangeIndex], value = $element.value;
            ranges[rangeIndex] = value;
            var parent = $element.parentElement, $thumb = parent.querySelector('.range-slider__thumb'), $bar = parent.querySelector('.range-slider__bar'),
            pct = (value / keyS) * 100;
            $thumb.style.bottom = pct + '%';
            $bar.style.height = 'calc(' + pct + '% + ' + sliderThumbSize / 2 + 'px)';
            renderSliderGraph(keyS, count);
        }
    }
    function updatePoints(key) {
        points.point1.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range1 / key | 0;
        points.point2.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range2 / key | 0;
        points.point3.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range3 / key | 0;
        points.point4.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range4 / key | 0;
        points.point5.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range5 / key | 0;
        points.point6.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range6 / key | 0;
        points.point7.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range7 / key | 0;


        points.point8.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range8 / key | 0;
        points.point9.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range9 / key | 0;
        points.point10.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range10 / key | 0;
        points.point11.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range11 / key | 0;
        points.point12.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range12 / key | 0;

        var max = svgViewBoxGraphMax;
        var min = svgViewBoxGraphMin;
        points.point1.y = mapDataRange(points.point1.y);
        points.point2.y = mapDataRange(points.point2.y);
        points.point3.y = mapDataRange(points.point3.y);
        points.point4.y = mapDataRange(points.point4.y);
        points.point5.y = mapDataRange(points.point5.y);
        points.point6.y = mapDataRange(points.point6.y);
        points.point7.y = mapDataRange(points.point7.y);

        points.point8.y = mapDataRange(points.point8.y);
        points.point9.y = mapDataRange(points.point9.y);
        points.point10.y = mapDataRange(points.point10.y);
        points.point11.y = mapDataRange(points.point11.y);
        points.point12.y = mapDataRange(points.point12.y);

        points.begin.y = points.point1.y;
        points.control1.y = points.point1.y;
        points.control2.y = points.point2.y;
        points.control3.y = points.point3.y;
        points.control4.y = points.point4.y;
        points.control5.y = points.point5.y;
        points.control6.y = points.point6.y;
        points.control7.y = points.point7.y;

        points.control8.y = points.point8.y;
        points.control9.y = points.point9.y;
        points.control10.y = points.point10.y;
        points.control11.y = points.point11.y;
        points.control12.y = points.point12.y;
    }
    function getInterpolatedLine(index) {
        if (index == undefined)
            index = 12;
        var p = "M {0},{1}"
        for (var i = 1; i <= index; i++) {
            p += `L{${(i - 1) * 4 + 2}},{${(i - 1) * 4 + 3}}`;
        }
        return p
        .format(points.begin.x, points.begin.y,
        points.point1.x, points.point1.y, points.control1.x, points.control1.y,
        points.control2.x, points.control2.y, points.point2.x, points.point2.y,
        points.control3.x, points.control3.y, points.point3.x, points.point3.y,
        points.control4.x, points.control4.y, points.point4.x, points.point4.y,
        points.control5.x, points.control5.y, points.point5.x, points.point5.y,
        points.control6.x, points.control6.y, points.point6.x, points.point6.y,
        points.control7.x, points.control7.y, points.point7.x, points.point7.y,
        points.control8.x, points.control8.y, points.point8.x, points.point8.y,
               points.control9.x, points.control9.y, points.point9.x, points.point9.y,
               points.control10.x, points.control10.y, points.point10.x, points.point10.y,
               points.control11.x, points.control11.y, points.point11.x, points.point11.y,
               points.control12.x, points.control12.y, points.point12.x, points.point12.y);
    }
    function reset() {
        var inputs = app.inputs;
        inputs.forEach(function (input) {
            return app.updateSlider(input);
        });
    }
   function renderSliderGraph(k,c) {
        updatePoints(k);
        $svgLine.setAttribute('d', getInterpolatedLine(c));
    }
    function selectPreset(key, el) {
        var inputs = app.inputs;
        $svgLine = el;
        inputs.forEach(function (input) {
            return app.updateSlider(input, key);
        });
    }
    return {
        inputs: [].slice.call(document.querySelectorAll('.sliders input')),
        updateSlider: updateSlider,
        reset: reset,
        selectPreset: selectPreset,
        $svgLine: null,

    };
}();
function Getinteger(MaxNum, aver) {
    MaxNum = (MaxNum*1).toFixed(0);
    var gNum = Math.pow(10, MaxNum.toString().length - 2) * 2;
    var CNum = Math.pow(10, MaxNum.toString().length - 1);
    while (CNum < MaxNum)
        CNum += CNum;
    CNum -= CNum;
    while (CNum < MaxNum)
        CNum += gNum;
    var aNum = (CNum / aver).toFixed(0);
    if (CNum > 10)
        while (aNum.toString().substring(aNum.toString().length - 1) != "0") {
            aNum = (aNum * 1) + 1;
        }
    return aNum * aver;
}

(function ($, window, document) {
    'use strict';
    $.fn.Eat_Arc = function (options) {
        options = $.extend({
            'chartdata1': {
                data: [{
                    name: "吉阳区",
                    A: 35,
                    B: 65,
                    C: 45,
                    D: 50,
                    E: 50
                },
                    {
                        name: "崖州区",
                        A: 35,
                        B: 65,
                        C: 45,
                        D: 50,
                        E: 50
                    },
                    {
                        name: "天涯区",
                        A: 35,
                        B: 65,
                        C: 45,
                        D: 50,
                        E: 50
                    },
                    {
                        name: "海棠区",
                        A: 35,
                        B: 65,
                        C: 45,
                        D: 50,
                        E: 50
                    }],
                Title: "最近12个月各行政区受理数量"
            },
            'chartdata2': {
                data: [{
                    name: "投诉举报",
                    value: 33
                },
                    {
                        name: "咨询",
                        value: 30
                    },
                    {
                        name: "求助",
                        value: 10
                    },
                    {
                        name: "意见建议",
                        value: 15
                    },
                    {
                        name: "其他",
                        value: 31
                    }],
                Title: "最近30天受理数量"
            },
            'chartdata3': {
                data: [{ time: "十一月", value: 50 },
                     { time: "十二月", value: 50 },
                     { time: "2016", value: 50 },
                     { time: "二月", value: 30 },
                     { time: "三月", value: 20 },
                     { time: "四月", value: 60 },
                     { time: "五月", value: 50 },
                     { time: "六月", value: 70 },
                     { time: "七月", value: 50 },
                     { time: "八月", value: 20 },
                     { time: "十月", value: 10 },
                     { time: "十一月", value: 50 }],
                lens: { len1: 11, len2: 11 }

          , Title: "最近30天各时段日均受理量分布"
            },
            'chartdata4': {
                "data": [{ "total": 13433, "time": "12月", "num_c": 12453, "num_l": 92.7 }, { "total": 12754, "time": "2016", "num_c": 12283, "num_l": 96.31 }, { "total": 10800, "time": "2月", "num_c": 10603, "num_l": 98.18 }, { "total": 13668, "time": "3月", "num_c": 13486, "num_l": 98.67 }, { "total": 14063, "time": "4月", "num_c": 13679, "num_l": 97.27 }, { "total": 13878, "time": "5月", "num_c": 13758, "num_l": 99.14 }, { "total": 15523, "time": "6月", "num_c": 15429, "num_l": 99.39 }, { "total": 17877, "time": "7月", "num_c": 17782, "num_l": 99.47 }, { "total": 17901, "time": "8月", "num_c": 17780, "num_l": 99.32 }, { "total": 20899, "time": "9月", "num_c": 20415, "num_l": 97.68 }, { "total": 26322, "time": "10月", "num_c": 25290, "num_l": 96.08 }, { "total": 12432, "time": "11月", "num_c": 10698, "num_l": 86.05 }],
                lens: { len1: 11, len2: 11 },
                "Title": "12345政府服务热线近12个月受理数办结率"
            },

            'chartdata5': {
                data: [
                    {
                        package: 85,
                        averageTime: 4.5
                    }
                ],
                Title: ""
            },
            'chartdata6': {
                data: [{ time: "十一月", num_c: 52, num_l: 80 },
                     { time: "十二月", num_c: 32, num_l: 99 },
                     { time: "2016", num_c: 63, num_l: 70 },
                     { time: "二月", num_c: 83, num_l: 89 },
                     { time: "三月", num_c: 12, num_l: 67 },
                     { time: "四月", num_c: 89, num_l: 99 },
                     { time: "五月", num_c: 10, num_l: 79 },
                     { time: "六月", num_c: 12, num_l: 49 },
                     { time: "七月", num_c: 30, num_l: 57 },
                     { time: "八月", num_c: 23, num_l: 29 },
                     { time: "十月", num_c: 19, num_l: 57 },
                     { time: "十一月", num_c: 34, num_l: 89 }],
                Years: ["2015", "2016"],
                lens: { len1: 11, len2: 11 }
         , Title: "2015/2016受理数量同比"
            },
            'upDatatime': { time: "2016-10-10 12:35" }
        }, options);

        function Chart1(data) {
            if (data) {
                var d = data.data;
                var MaxNum = 0;
                var chartContent1 = $(".chartContent1");
                $(".chartContent1 .title").text(data.Title);
                chartContent1.find(".bar").css({
                    "height": 0
                });
                setTimeout(function () {
                    for (var i = 0; i < d.length; i++) {
                        if (MaxNum < d[i].A)
                            MaxNum = d[i].A;
                        if (MaxNum < d[i].B)
                            MaxNum = d[i].B;
                        if (MaxNum < d[i].C)
                            MaxNum = d[i].C;
                        if (MaxNum < d[i].D)
                            MaxNum = d[i].D;
                        if (MaxNum < d[i].E)
                            MaxNum = d[i].E;
                    }
                    MaxNum = Getinteger(MaxNum,5);
                    if (MaxNum > 80)
                        for (var f = 0; f < 6; f++) {
                            chartContent1.find(".footer>div").eq(f).find("span").text(((MaxNum / 5) * (5 - f)).toFixed(0));
                        }
                    else
                        MaxNum = 80;
                    chartContent1.find(".bar").css("height", 0);
                    for (var y = 0; y < d.length; y++) {
                        var _d = d[y];
                        var itme = chartContent1.find(".colpanel").eq(y);
                        itme.find(".column").eq(0).find(".bar").animate({
                            "height": (140 * (_d.A / MaxNum))
                        });
                        itme.find(".column").eq(1).find(".bar").animate({
                            "height": (140 * (_d.B / MaxNum))
                        });
                        itme.find(".column").eq(2).find(".bar").animate({
                            "height": (140 * (_d.C / MaxNum))
                        });
                        itme.find(".column").eq(3).find(".bar").animate({
                            "height": (140 * (_d.D / MaxNum))
                        });
                        itme.find(".column").eq(4).find(".bar").animate({
                            "height": (140 * (_d.E / MaxNum))
                        });
                        itme.find(".lableName").text(_d.name);
                    }
                }, 300);
            }
        }

        function Chart2(data) {
            var myChart = echarts.init(document.getElementById('chat'));
            var count;
            var countNum = 0;
            for (var i = 0; i < data.data.length; i++) {
                data.data[i].name += "：" + data.data[i].value;
                countNum += data.data[i].value;
                count = "共" + countNum + "件";

            }
            $(".chartContent2 .title").text(data.Title);
            $(".chartContent2 .labNum").hide().text(count).show(500);
            var option = {
                title: {
                    text: '',
                    subtext: '',
                    x: 'center'
                },
                tooltip: {
                    trigger: 'item',
                    formatter: "{a} <br/>{b} : {c} ({d}%)"
                },
                legend: {
                    show: false
                },
                toolbox: {
                    show: false
                },
                calculable: true,
                series: [
                    {
                        name: '面积模式',
                        type: 'pie',
                        radius: [40, 80],
                        center: ['50%', '50%'],
                        roseType: 'area',
                        color: ["#556FB5", "#A23391", "#5CADD3", "#00479D", "#1A7C31"],
                        data: data.data,
                        label: {
                            normal: {
                                textStyle: {
                                    color: "#fff",
                                    fontSize: 12
                                }
                            }
                        },
                        labelLine: {
                            normal: {
                                length: 8,
                                length2: 35,
                                lineStyle: {
                                    color: "#556FB5",
                                    type: "dashed"
                                }
                            }
                        }
                    }
                ]
            };
            myChart.setOption(option);

        }
        function Chart3(data) {
            if (data) {
                var chartContent3 = $(".chartContent3");
                chartContent3.find(".title").text(data.Title);

                var MaxNum = 0;
                var d = data.data;
                for (var i = 0; i < d.length; i++) {
                    var _d = d[i];
                    chartContent3.find(".range-slider").eq(i).find("input").val(_d.value);
                    if (MaxNum < _d.value)
                        MaxNum = _d.value;
                    chartContent3.find(".range-slider").eq(i).find(".range-slider_lab").text(_d.time);
                }
                MaxNum = Getinteger(MaxNum,7);
                chartContent3.find(".range-slider").attr("max", MaxNum);
                for (var f = 0; f < 7; f++) {
                    chartContent3.find(".Accept .tickline>div").eq(f).find("span").text(((MaxNum / 7) * (7 - f)).toFixed(0));
                }

                app.inputs = [].slice.call(document.querySelectorAll('.chartContent3 input'));
                var inputs = app.inputs;
                var index = 1;
                var p = document.querySelector('.chartContent3  svg .line');
                inputs.forEach(function (input) {
                    return input.setAttribute('data-slider-index', 'range' + index++);
                });
                inputs.forEach(function (input) {
                     return app.updateSlider(input, MaxNum, p);
                })
            }
        }

        function Chart4(data) {
            if (data) {
                var chartContent4 = $(".chartContent4");
                chartContent4.find(".title").text(data.Title);

                var MaxNum = 0;
                var d = data.data;
                for (var i = 0; i < d.length; i++) {
                    var _d = d[i];
                    chartContent4.find(".Accept .range-slider").eq(i).find("input").val(_d.num_c);
                    chartContent4.find(".End .range-slider").eq(i).find("input").val(_d.num_l);
                    if (MaxNum < _d.num_c)
                        MaxNum = _d.num_c;
                    chartContent4.find(".Accept .range-slider").eq(i).find(".range-slider_lab").text(_d.time);
                }
                MaxNum = Getinteger(MaxNum,10);
                chartContent4.find(".range-slider").attr("max", MaxNum);
                for (var f = 0; f < 10; f++) {
                    chartContent4.find(".Accept .tickline>div").eq(f).find("span").text(((MaxNum / 10) * (10 - f)).toFixed(0));
                }

                app.inputs = [].slice.call(document.querySelectorAll('.chartContent4 .Accept input'));
                var inputs = app.inputs;
                var index = 1;
                var p = document.querySelector('.chartContent4 .Accept svg .line');
                $(".chartContent4 .range-slider").css("opacity", 1);
                if (data.lens.len1)
                    $(".chartContent4 .Accept .range-slider:gt(" + (data.lens.len1 - 1) + ")").css("opacity", 0);
                if (data.lens.len2)
                    $(".chartContent4 .End .range-slider:gt(" + (data.lens.len2 - 1) + ")").css("opacity", 0);
                inputs.forEach(function (input) {
                    return input.setAttribute('data-slider-index', 'range' + index++);
                });
                inputs.forEach(function (input) {
                    return app.updateSlider(input, MaxNum, p, (data.lens.len1 ? data.lens.len1 : 12));
                });

                p = document.querySelector('.chartContent4 .End svg .line');
                app.inputs = [].slice.call(document.querySelectorAll('.chartContent4 .End input'));
                inputs = app.inputs;
                index = 1;
                inputs.forEach(function (input) {
                    return input.setAttribute('data-slider-index', 'range' + index++);
                });
                inputs.forEach(function (input) {
                    return app.updateSlider(input, 100, p, (data.lens.len2 ? data.lens.len2 : 12));
                });
            }
        }

        function Chart5(data) {
            if (data) {
                var d = data.data[0];
                var chartContent5 = $(".chartContent5");
                var performance = chartContent5.find(".performance");
                var averageTime = chartContent5.find(".average_time p:first-child");

                performance.animate({ "height": d.package + "%" }, 1000);
                performance.find("p").text(d.package + "%");
                averageTime.text(d.averageTime + "小时")
            }
        }

        function Chart6(data) {
            if (data) {
                var chartContent6 = $(".chartContent6");
                chartContent6.find(".title").text(data.Title);

                var MaxNum = 0;
                var d = data.data;
                for (var i = 0; i < d.length; i++) {
                    var _d = d[i];
                    chartContent6.find(".Accept .range-slider").eq(i).find("input").val(_d.num_c);
                    chartContent6.find(".End .range-slider").eq(i).find("input").val(_d.num_l);
                    if (MaxNum < _d.num_c)
                        MaxNum = _d.num_c;
                    if (MaxNum < _d.num_l)
                        MaxNum = _d.num_l;
                    chartContent6.find(".Accept .range-slider").eq(i).find(".range-slider_lab").text(_d.time);
                }
                MaxNum = Getinteger(MaxNum,8);
                chartContent6.find(".range-slider").attr("max", MaxNum);
                for (var f = 0; f < 8; f++) {
                    chartContent6.find(".Accept .tickline>div").eq(f).find("span").text(((MaxNum / 8) * (8 - f)).toFixed(0));
                }
                $(".chartContent6 .range-slider").css("opacity", 1);
                if (data.lens.len1)
                    $(".chartContent6 .Accept .range-slider:gt(" + (data.lens.len1 - 1) + ")").css("opacity", 0);
                if (data.lens.len2)
                    $(".chartContent6 .End .range-slider:gt(" + (data.lens.len2 - 1) + ")").css("opacity", 0);
                app.inputs = [].slice.call(document.querySelectorAll('.chartContent6 .Accept input'));
                var inputs = app.inputs;
                var index = 1;
                var p = document.querySelector('.chartContent6 .Accept svg .line');
                inputs.forEach(function (input) {
                    return input.setAttribute('data-slider-index', 'range' + index++);
                });
                inputs.forEach(function (input) {
                    return app.updateSlider(input, MaxNum, p, (data.lens.len2 ? data.lens.len2 : 12));
                });

                p = document.querySelector('.chartContent6 .End svg .line');
                app.inputs = [].slice.call(document.querySelectorAll('.chartContent6 .End input'));
                inputs = app.inputs;
                index = 1;
                inputs.forEach(function (input) {
                    return input.setAttribute('data-slider-index', 'range' + index++);
                });
                inputs.forEach(function (input) {
                    return app.updateSlider(input, MaxNum, p, (data.lens.len2 ? data.lens.len2 : 12));
                });
            }
        }

        function Updata(time) {
            $(".updateTime").stop().slideUp(function () {
                $(".updateTime").text(time).stop().slideDown();
            });
        }
        Chart1(options.chartdata1);
        Chart2(options.chartdata2);
        Chart4(options.chartdata4);
        Chart6(options.chartdata6);
        Chart3(options.chartdata3);
        Chart5(options.chartdata5);
        Updata(options.upDatatime.time);

        return {
            loadChart1: Chart1,
            loadChart2: Chart2,
            loadChart3: Chart3,
            loadChart4: Chart4,
            loadChart5: Chart5,
            loadChart6: Chart6,
            Updata: Updata
        }
    }
})(jQuery, window, document)
