'use strict';
if (!String.prototype.format) {
    String.prototype.format = function () {
        var args = arguments;
        return this.replace(/{(\d+)}/g, function (match, number) {
            return typeof args[number] != 'undefined' ? args[number] : match;
        });
    };
}
var app = function () {
    var $svgLine = document.querySelector('.chartContent6 svg .line');
    var sliderThumbSize = 0;
    var sliderHeight = 200;
    var svgViewBoxHeight = 100;
    var svgViewBoxThumbLimit = sliderThumbSize / 2 * (svgViewBoxHeight / sliderHeight);
    var svgViewBoxGraphMax = svgViewBoxHeight - svgViewBoxThumbLimit;
    var svgViewBoxGraphMin = svgViewBoxThumbLimit;
    var ranges = {
        range1: null,
        range2: null,
        range3: null,
        range4: null,
        range5: null,
        range6: null,
        range7: null,
        range8: null,
        range9: null,
        range10: null,
        range11: null,
        range12: null
    };
    var points = {
        begin: {
            x: 5,
            y: 0
        },
        point1: {
            x: 5,
            y: 0
        },
        control1: {
            x: 5,
            y: 0
        },
        control2: {
            x: 16.5,
            y: 0
        },
        point2: {
            x: 16.5,
            y: 0
        },
        control3: {
            x: 28,
            y: 0
        },
        point3: {
            x: 28,
            y: 0
        },
        control4: {
            x: 39.5,
            y: 0
        },
        point4: {
            x: 39.5,
            y: 0
        },
        control5: {
            x: 51.5,
            y: 0
        },
        point5: {
            x: 51.5,
            y: 0
        },
        control6: {
            x: 63.5,
            y: 0
        },
        point6: {
            x: 63.5,
            y: 0
        },
        control7: {
            x: 75.5,
            y: 0
        },
        point7: {
            x: 75.5,
            y: 0
        },
        control8: {
            x: 87,
            y: 0
        },
        point8: {
            x: 87,
            y: 0
        },
        control9: {
            x: 98.2,
            y: 0
        },
        point9: {
            x: 98.5,
            y: 0
        },
        control10: {
            x: 110.5,
            y: 0
        },
        point10: {
            x: 110.5,
            y: 0
        },
        control11: {
            x: 122,
            y: 0
        },
        point11: {
            x: 122,
            y: 0
        },
        control12: {
            x: 133,
            y: 0
        },
        point12: {
            x: 133,
            y: 0
        }

    };
    function mapDataRange(value) {
        return (value - 0) * (svgViewBoxGraphMax - svgViewBoxGraphMin) / (svgViewBoxHeight - 0) + svgViewBoxGraphMin;
    }
    function updateSlider($element, keyS, line, count) {
        $svgLine = line;
        if ($element) {
            var rangeIndex = $element.getAttribute('data-slider-index'), range = ranges[rangeIndex], value = $element.value;
            ranges[rangeIndex] = value;
            var parent = $element.parentElement, $thumb = parent.querySelector('.range-slider__thumb'), $bar = parent.querySelector('.range-slider__bar'),
            pct = (value / keyS) * 100;
            $thumb.style.bottom = pct + '%';
            $bar.style.height = 'calc(' + pct + '% + ' + sliderThumbSize / 2 + 'px)';
            renderSliderGraph(keyS, count);
        }
    }
    function updatePoints(key) {
        points.point1.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range1 / key | 0;
        points.point2.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range2 / key | 0;
        points.point3.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range3 / key | 0;
        points.point4.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range4 / key | 0;
        points.point5.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range5 / key | 0;
        points.point6.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range6 / key | 0;
        points.point7.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range7 / key | 0;


        points.point8.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range8 / key | 0;
        points.point9.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range9 / key | 0;
        points.point10.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range10 / key | 0;
        points.point11.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range11 / key | 0;
        points.point12.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range12 / key | 0;

        var max = svgViewBoxGraphMax;
        var min = svgViewBoxGraphMin;
        points.point1.y = mapDataRange(points.point1.y);
        points.point2.y = mapDataRange(points.point2.y);
        points.point3.y = mapDataRange(points.point3.y);
        points.point4.y = mapDataRange(points.point4.y);
        points.point5.y = mapDataRange(points.point5.y);
        points.point6.y = mapDataRange(points.point6.y);
        points.point7.y = mapDataRange(points.point7.y);

        points.point8.y = mapDataRange(points.point8.y);
        points.point9.y = mapDataRange(points.point9.y);
        points.point10.y = mapDataRange(points.point10.y);
        points.point11.y = mapDataRange(points.point11.y);
        points.point12.y = mapDataRange(points.point12.y);

        points.begin.y = points.point1.y;
        points.control1.y = points.point1.y;
        points.control2.y = points.point2.y;
        points.control3.y = points.point3.y;
        points.control4.y = points.point4.y;
        points.control5.y = points.point5.y;
        points.control6.y = points.point6.y;
        points.control7.y = points.point7.y;

        points.control8.y = points.point8.y;
        points.control9.y = points.point9.y;
        points.control10.y = points.point10.y;
        points.control11.y = points.point11.y;
        points.control12.y = points.point12.y;
    }
    function getInterpolatedLine(index) {
        if (index == undefined)
            index = 12;
        var p = "M {0},{1}"
        for (var i = 1; i <= index; i++) {
            p += `L{${(i - 1) * 4 + 2}},{${(i - 1) * 4 + 3}}`;
        }
        return p
        .format(points.begin.x,
                points.begin.y,
        points.point1.x,
                points.point1.y,
                points.control1.x,
                points.control1.y,
        points.control2.x,
                points.control2.y,
                points.point2.x,
                points.point2.y,
        points.control3.x,
                points.control3.y,
                points.point3.x,
                points.point3.y,
        points.control4.x,
                points.control4.y,
                points.point4.x,
                points.point4.y,
        points.control5.x,
                points.control5.y,
                points.point5.x,
                points.point5.y,
        points.control6.x,
                points.control6.y,
                points.point6.x,
                points.point6.y,
        points.control7.x, points.control7.y, points.point7.x, points.point7.y,
        points.control8.x, points.control8.y, points.point8.x, points.point8.y,
               points.control9.x, points.control9.y, points.point9.x, points.point9.y,
               points.control10.x, points.control10.y, points.point10.x, points.point10.y,
               points.control11.x, points.control11.y, points.point11.x, points.point11.y,
               points.control12.x, points.control12.y, points.point12.x, points.point12.y);
    }
    function reset() {
        var inputs = app.inputs;
        inputs.forEach(function (input) {
            return app.updateSlider(input);
        });
    }
   function renderSliderGraph(k,c) {
        updatePoints(k);
        $svgLine.setAttribute('d', getInterpolatedLine(c));
    }
    function selectPreset(key, el) {
        var inputs = app.inputs;
        $svgLine = el;
        inputs.forEach(function (input) {
            return app.updateSlider(input, key);
        });
    }
    return {
        inputs: [].slice.call(document.querySelectorAll('.sliders input')),
        updateSlider: updateSlider,
        reset: reset,
        selectPreset: selectPreset,
        $svgLine: null,

    };
}();
function Getinteger(MaxNum, aver) {
    MaxNum = (MaxNum * 1).toFixed(0);
    var gNum = Math.pow(10, MaxNum.toString().length - 2) * 2;
    var CNum = Math.pow(10, MaxNum.toString().length - 1);
    while (CNum < MaxNum)
        CNum += CNum;
    CNum -= CNum;
    while (CNum < MaxNum)
        CNum += gNum;
    var aNum = (CNum / aver).toFixed(0);
    if (CNum > 10)
        while (aNum.toString().substring(aNum.toString().length - 1) != "0") {
            aNum = (aNum * 1) + 1;
        }
    return aNum * aver;
}

(function ($, window, document) {
    'use strict';
    $.fn.Zhu_Arc = function (options) {
        var LA = $.fn.Zhu_Arc;
        options = $.extend({
            'chartdata1': {
                data:
                    {
                        header: ["2013", "2014", "2015", "2015春节", "2016春节"],
                        row1: ["28.3", "36.8", "42.4", "2.54", "2.85"],
                        row2: ["28.3", "36.8", "42.4", "2.54", "2.85"]
                    }
                ,
                Title: "免税店年度及春节黄金周营收和人均购物金额"
            },
            'chartdata2': {
                data: {
                    header: ["1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月"],
                    row1: ["2016", "28.3", "36.8", "42.4", "2.54", "2.85", "28.3", "36.8", "42.4", "2.54", "2.85", "6.2", "5.6"],
                    row2: ["2017", "28.3", "36.8", "42.4", "2.54", "2.85", "28.3", "36.8", "42.4", "2.54", "--", "--", "--"],
                    row3: ["同比", "28.3%", "36.8", "-42.4%", "2.54", "-2.85%", "28.3", "36.8", "42.4", "2.54", "--", "--", "--"],
                },
                Title: "各行政区旅游饭店数量"
            },
            'chartdata3': {
                data: [{ name: "进店人数", num: "13292人" },
                { name: "购物人数", num: "3292人" },
                { name: "销售总额", num: "13292人" }], Title: '免税店昨日经营情况'
            },
            'chartdata4': { data: [{ year1: 0, year2: 30 }, { year1: 30, year2: 40 }, { year1: 30, year2: 40 }, { year1: 30, year2: 40 }, { year1: 40, year2: 50 }, { year1: 20, year2: 30 }, { year1: 20, year2: 30 }, { year1: 20, year2: 30 }, { year1: 20, year2: 30 }, { year1: 20, year2: 70 }, { year1: 20, year2: 30 }, { year1: 20, year2: 30 }], YearS: { year1: "2015", year2: "2016" }, Title: '2015/2016年免税店销售趋势' },
            'chartdata5': {
                data: [{
                    year1: 1.2,
                    year2: 1
                }, {
                    year1: 2,
                    year2: 2.1
                }, {
                    year1: 2.4,
                    year2: 2.3
                }, {
                    year1: 1.3,
                    year2: 2.5
                }, {
                    year1: 4,
                    year2: 3
                }, {
                    year1: 3,
                    year2: 4
                }, {
                    year1: 4,
                    year2: 7
                }, {
                    year1: 3,
                    year2: 5
                }, {
                    year1: 2,
                    year2: 5
                }, {
                    year1: 2,
                    year2: 4
                }, {
                    year1: 1,
                    year2: 5
                }, {
                    year1: 2,
                    year2: 5
                }],
                YearS: {
                    year1: "2015",len1:10,
                    year2: "2016"
                }, Title: '2015/2016年每月全市社会商品零售总额'
            }
        }, options);
        function Chart1(data) {
            if (data) {
                var chartContent1 = $(".chartContent1").removeClass("show");
                chartContent1.find(".title").text(data.Title);
                data = data.data;
                chartContent1.find(".header").find(".col").each(function (i) {
                    if (i != 0) {
                        $(this).text(data.header[i - 1]);
                    }
                })
                chartContent1.find(".row:eq(0)").find(".col").each(function (i) {
                    if (i != 0) {
                        $(this).text(data.row1[i - 1]);
                    }
                })
                chartContent1.find(".row:eq(1)").find(".col").each(function (i) {
                    if (i != 0) {
                        $(this).text(data.row2[i - 1]);
                    }
                })

                chartContent1.addClass("show");
            }
        }
        function Chart2(data) {
            if (data) {
                var chartContent2 = $(".chartContent3").removeClass("show");
                chartContent2.find(".title").text(data.Title);
                data = data.data;
                chartContent2.find(".header").find(".col").each(function (i) {
                    if (i != 0) {
                        $(this).text(data.header[i - 1]);
                    }
                })
                chartContent2.find(".row:eq(0)").find(".col").each(function (i) {
                    if (i == 0) {
                        $(this).html(data.row1[i] + "<br/>（亿元）");
                    } else

                        $(this).text(data.row1[i]);
                })
                chartContent2.find(".row:eq(1)").find(".col").each(function (i) {
                    if (i == 0)
                        $(this).html(data.row1[i] + "<br/>（亿元）");
                    else
                        $(this).text(data.row2[i]);
                })
                chartContent2.find(".row:eq(2)").find(".col").each(function (i) {
                    $(this).text(data.row3[i]).attr("value", data.row3[i]);
                });
                chartContent2.addClass("show");

            }
        }
        function Chart4(data) {
            $("input").val(0);
            if (data) {
                var sliders = $(".checkIn1");
                $(sliders).find(".title").text(data.Title);
                $(sliders).find(".lableee").find("div").eq(0).text(data.YearS.year1);
                $(sliders).find(".lableee").find("div").eq(1).text(data.YearS.year2);
                var d = data.data;
                var MaxNum = 0;
                for (var i = 0; i < d.length; i++) {
                    var _d = d[i];
                    sliders.find(".Accept .range-slider").eq(i).find("input").val(_d.year1);
                    sliders.find(".End .range-slider").eq(i).find("input").val(_d.year2);
                    if (MaxNum < d[i].year1)
                        MaxNum = d[i].year1;
                    if (MaxNum < d[i].year2)
                        MaxNum = d[i].year2;
                }
                MaxNum += 2;
                if (MaxNum > 50)
                    MaxNum = Getinteger(MaxNum, 7);
                else
                    MaxNum = 14;
                for (var f = 0; f < 9; f++) {
                    sliders.find(".tickline>div").eq(f).find("span").text(((MaxNum / 7) * (7 - f)));
                }

                app.inputs = [].slice.call(document.querySelectorAll('.checkIn1 .Accept input'));

                $(".checkIn1 .range-slider").css("opacity", 1);
                if (data.YearS.len1)
                    $(".checkIn1 .Accept .range-slider:gt(" + (data.YearS.len1 - 1) + ")").css("opacity", 0);
                if (data.YearS.len2)
                    $(".checkIn1 .End .range-slider:gt(" + (data.YearS.len2 - 1) + ")").css("opacity", 0);
                var inputs = app.inputs;
                var index = 1;
                var p = document.querySelector('.checkIn1 .Accept svg .line');
                inputs.forEach(function (input) {
                    return input.setAttribute('data-slider-index', 'range' + index++);
                });
                inputs.forEach(function (input) {
                     return app.updateSlider(input, MaxNum, p, (data.YearS.len1 ? data.YearS.len1 : 12));
                });

                p = document.querySelector('.checkIn1 .End svg .line');
                app.inputs = [].slice.call(document.querySelectorAll('.checkIn1 .End input'));
                inputs = app.inputs;
                index = 1;
                inputs.forEach(function (input) {
                    return input.setAttribute('data-slider-index', 'range' + index++);
                });
                inputs.forEach(function (input) {
                     return app.updateSlider(input, MaxNum, p, (data.YearS.len2 ? data.YearS.len2 : 12));
                });
            }
        }

        function Chart5(data) {
            if (data) {
                var sliders = $(".checkIn");
                $(sliders).find(".title").text(data.Title);
                $(sliders).find(".lableee").find("div").eq(0).text(data.YearS.year1);
                $(sliders).find(".lableee").find("div").eq(1).text(data.YearS.year2);
                var d = data.data;
                var MaxNum = 0;
                for (var i = 0; i < d.length; i++) {
                    var _d = d[i];
                    sliders.find(".Accept .range-slider").eq(i).find("input").val(_d.year1);
                    sliders.find(".End .range-slider").eq(i).find("input").val(_d.year2);
                    if (MaxNum < d[i].year1)
                        MaxNum = d[i].year1;
                    if (MaxNum < d[i].year2)
                        MaxNum = d[i].year2;
                }
                MaxNum += 2;
                if (MaxNum > 50)
                    MaxNum = Getinteger(MaxNum, 7);
                else
                    MaxNum = 21;
                for (var f = 0; f < 9; f++) {
                    sliders.find(".tickline>div").eq(f).find("span").text(((MaxNum / 7) * (7 - f)));
                }
                app.inputs = [].slice.call(document.querySelectorAll('.checkIn .Accept input'));
                var inputs = app.inputs;
                var index = 1;
                var p = document.querySelector('.checkIn .Accept svg .line');

                $(".checkIn .range-slider").css("opacity", 1);
                if (data.YearS.len1)
                    $(".checkIn .Accept .range-slider:gt(" + (data.YearS.len1 - 1) + ")").css("opacity", 0);
                if (data.YearS.len2)
                    $(".checkIn .End .range-slider:gt(" + (data.YearS.len2 - 1) + ")").css("opacity", 0);

                inputs.forEach(function (input) {
                    return input.setAttribute('data-slider-index', 'range' + index++);
                });
                inputs.forEach(function (input) {
                     return app.updateSlider(input, MaxNum, p, (data.YearS.len1 ? data.YearS.len1 : 12));
                });

                p = document.querySelector('.checkIn .End svg .line');
                app.inputs = [].slice.call(document.querySelectorAll('.checkIn .End input'));
                inputs = app.inputs;
                index = 1;
                inputs.forEach(function (input) {
                    return input.setAttribute('data-slider-index', 'range' + index++);
                });
                inputs.forEach(function (input) {
                     return app.updateSlider(input, MaxNum, p, (data.YearS.len2 ? data.YearS.len2 : 12));
                });
            }
        }
        function Chart3(data) {
            if (data) {
                var panel_middle = $(".panel_middle");
                $(panel_middle).find(".title").text(data.Title);
                panel_middle.find(".itemNum").remove();
                for (var i = 0; i < data.data.length; i++) {
                    var d = data.data[i];
                    $('<div class="itemNum"><div class="num">' + d.num + '</div><div class="name">' + d.name + '</div></div>').appendTo(panel_middle.find(".content")).addClass("fadeInUp");
                }
            }
        }
        function Updata(time) {
            $(".updateTime").stop().slideUp(function () {
                $(".updateTime").text(tiem).stop().slideDown();
            });
        }
        Chart1(options.chartdata1);
        Chart2(options.chartdata2);
        Chart3(options.chartdata3);
        Chart4(options.chartdata4);
        Chart5(options.chartdata5);
        return {
            loadChart1: Chart1,
            loadChart2: Chart2,
            loadChart3: Chart3,
            loadChart4: Chart4,
            loadChart5: Chart5,
            Updata: Updata
        }
    }
})(jQuery, window, document)