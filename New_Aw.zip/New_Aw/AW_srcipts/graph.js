'use strict';
if (!String.prototype.format) {
    String.prototype.format = function () {
        var args = arguments;
        return this.replace(/{(\d+)}/g, function (match, number) {
            return typeof args[number] != 'undefined' ? args[number] : match;
        });
    };
}
var app = function () {
    var $svgLine = document.querySelector('svg .line');
    var $svgLineShadow = document.querySelector('svg .line-shadow');
    var sliderThumbSize = 0;
    var sliderHeight = 234;
    var svgViewBoxHeight = 100;
    var svgViewBoxThumbLimit = sliderThumbSize / 2 * (svgViewBoxHeight / sliderHeight);
    var svgViewBoxGraphMax = svgViewBoxHeight - svgViewBoxThumbLimit;
    var svgViewBoxGraphMin = svgViewBoxThumbLimit;
    var ranges = {
        range1: null,
        range2: null,
        range3: null,
        range4: null,
        range5: null,
        range6: null,
        range7: null,
        range8:null,
        range9:null,
        range10:null,
        range11:null,
        range12:null
    };
    var points = {
        begin: {
            x: 5,
            y: 0
        },
        point1: {
            x: 5,
            y: 0
        },
        control1: {
            x: 15,
            y: 10
        },
        control2: {
            x: 12,
            y: 0
        },
        point2: {
            x: 17,
            y: 0
        },
        control3: {
            x: 22,
            y: 0
        },
        point3: {
            x: 29,
            y: 0
        },
        control4: {
            x: 34,
            y: 0
        },
        point4: {
            x: 40,
            y: 0
        },
        control5: {
            x: 44,
            y: 0
        },
        point5: {
            x: 51,
            y: 0
        },
        control6: {
            x: 56,
            y: 0
        },
        point6: {
            x: 64,
            y: 0
        },
        control7: {
            x: 68,
            y: 0
        },
        point7: {
            x: 76,
            y: 0
        },
        control8: {
            x: 79,
            y: 0
        },
        point8: {
            x: 87,
            y: 0
        },
        control9: {
            x: 91,
            y: 0
        },
        point9: {
            x: 99,
            y: 0
        },
        control10: {
            x: 101,
            y: 0
        },
        point10: {
            x: 110,
            y: 0
        },
        control11: {
            x: 113,
            y: 0
        },
        point11: {
            x: 122,
            y: 0
        },
        control12: {
            x: 125,
            y: 0
        },
        point12: {
            x: 133,
            y: 0
        }
    
    };
    function mapDataRange(value) {
        return (value - 0) * (svgViewBoxGraphMax - svgViewBoxGraphMin) / (svgViewBoxHeight - 0) + svgViewBoxGraphMin;
    }
    function updateSlider($element) {
        if ($element) {
            var rangeIndex = $element.getAttribute('data-slider-index'), range = ranges[rangeIndex], value = $element.value;
            if (range === value) {
                return;
            }
            ranges[rangeIndex] = value;
            var parent = $element.parentElement, $thumb = parent.querySelector('.range-slider__thumb'), $bar = parent.querySelector('.range-slider__bar'), pct = value * ((sliderHeight - sliderThumbSize) / sliderHeight);
            $thumb.style.bottom = pct + '%';
            $bar.style.height = 'calc(' + pct + '% + ' + sliderThumbSize / 2 + 'px)';
            renderSliderGraph();
        }
    }
    function updatePoints() {
        points.point1.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range1 / 100 | 0;
        points.point2.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range2 / 100 | 0;
        points.point3.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range3 / 100 | 0;
        points.point4.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range4 / 100 | 0;
        points.point5.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range5 / 100 | 0;
        points.point6.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range6 / 100 | 0;
        points.point7.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range7 / 100 | 0;
        
        
        points.point8.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range8 / 100 | 0;
        points.point9.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range9 / 100 | 0;
        points.point10.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range10 / 100 | 0;
        points.point11.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range11 / 100 | 0;
        points.point12.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range12/ 100 | 0;
        
        var max = svgViewBoxGraphMax;
        var min = svgViewBoxGraphMin;
        points.point1.y = mapDataRange(points.point1.y);
        points.point2.y = mapDataRange(points.point2.y);
        points.point3.y = mapDataRange(points.point3.y);
        points.point4.y = mapDataRange(points.point4.y);
        points.point5.y = mapDataRange(points.point5.y);
        points.point6.y = mapDataRange(points.point6.y);
        points.point7.y = mapDataRange(points.point7.y);
        
        points.point8.y = mapDataRange(points.point8.y);
        points.point9.y = mapDataRange(points.point9.y);
        points.point10.y = mapDataRange(points.point10.y);
        points.point11.y = mapDataRange(points.point11.y);
        points.point12.y = mapDataRange(points.point12.y);
        
        points.begin.y = points.point1.y;
        points.control1.y = points.point1.y;
        points.control2.y = points.point2.y;
        points.control3.y = points.point3.y;
        points.control4.y = points.point4.y;
        points.control5.y = points.point5.y;
        points.control6.y = points.point6.y;
        points.control7.y = points.point7.y;
        
          points.control8.y = points.point8.y;
        points.control9.y = points.point9.y;
        points.control10.y = points.point10.y;
        points.control11.y = points.point11.y;
        points.control12.y = points.point12.y;
    }
    function getInterpolatedLine(type) {
        return 'M {0},{1} L {2},{3} C {4},{5} {6},{7} {8},{9} S {10} {11}, {12} {13} S {14} {15}, {16} {17} S {18} {19}, {20} {21} S {22} {23}, {24} {25} S {26} {27}, {28} {29} S {30} {31},{32} {33} S {34} {35}, {36} {37} S {38} {39}, {40} {41} S {42} {43}, {44} {45} S {46} {47}, {48} {49}'
        .format(points.begin.x, points.begin.y,
        points.point1.x, points.point1.y, points.control1.x, points.control1.y,
        points.control2.x, points.control2.y, points.point2.x, points.point2.y,
        points.control3.x, points.control3.y, points.point3.x, points.point3.y,
        points.control4.x, points.control4.y , points.point4.x, points.point4.y ,
        points.control5.x, points.control5.y, points.point5.x, points.point5.y,
        points.control6.x, points.control6.y, points.point6.x, points.point6.y,
        points.control7.x, points.control7.y, points.point7.x, points.point7.y,
        points.control8.x, points.control8.y, points.point8.x, points.point8.y,
               points.control9.x, points.control9.y, points.point9.x, points.point9.y,
               points.control10.x, points.control10.y, points.point10.x, points.point10.y,
               points.control11.x, points.control11.y, points.point11.x, points.point11.y,
               points.control12.x, points.control12.y, points.point12.x, points.point12.y);
    }
    function reset() {
        var inputs = app.inputs;
        inputs.forEach(function (input) {
            return app.updateSlider(input);
        });
    }
    function renderSliderGraph(c) {
        updatePoints();
        $svgLine.setAttribute('d', getInterpolatedLine(c));
        //$svgLineShadow.setAttribute('d', getInterpolatedLine('shadow'));
    }
    function selectPreset(type) {
        var inputs = app.inputs;
        //inputs.forEach(function (input) {
          //  return input.value = Math.random() * 100 | 0;
        //});
        inputs.forEach(function (input) {
            return app.updateSlider(input);
        });
    }
    return {
        inputs: [].slice.call(document.querySelectorAll('.sliders input')),
        updateSlider: updateSlider,
        reset: reset,
        selectPreset: selectPreset
    };
}();