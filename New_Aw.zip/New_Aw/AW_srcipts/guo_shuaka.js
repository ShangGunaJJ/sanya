'use strict';
if (!String.prototype.format) {
    String.prototype.format = function () {
        var args = arguments;
        return this.replace(/{(\d+)}/g, function (match, number) {
            return typeof args[number] != 'undefined' ? args[number] : match;
        });
    };
}
var app = function () {
    var $svgLine = document.querySelector('svg .line');
    var $svgLineShadow = document.querySelector('svg .line-shadow');
    var sliderThumbSize = 0;
    var sliderHeight = 160;
    var svgViewBoxHeight = 100;
    var svgViewBoxThumbLimit = sliderThumbSize / 2 * (svgViewBoxHeight / sliderHeight);
    var svgViewBoxGraphMax = svgViewBoxHeight - svgViewBoxThumbLimit;
    var svgViewBoxGraphMin = svgViewBoxThumbLimit;
    var ranges = {
        range1: null,
        range2: null,
        range3: null,
        range4: null,
        range5: null,
        range6: null,
        range7: null,
        range8: null,
        range9: null,
        range10: null,
        range11: null,
        range12: null
    };
    var points = {
        begin: {
            x: 5,
            y: 0
        },
        point1: {
            x: 5,
            y: 0
        },
        control1: {
            x: 5,
            y: 0
        },
        control2: {
            x: 16.5,
            y: 0
        },
        point2: {
            x: 16.5,
            y: 0
        },
        control3: {
            x: 28,
            y: 0
        },
        point3: {
            x: 28,
            y: 0
        },
        control4: {
            x: 39.5,
            y: 0
        },
        point4: {
            x: 39.5,
            y: 0
        },
        control5: {
            x: 51.5,
            y: 0
        },
        point5: {
            x: 51.5,
            y: 0
        },
        control6: {
            x: 63.5,
            y: 0
        },
        point6: {
            x: 63.5,
            y: 0
        },
        control7: {
            x: 75.5,
            y: 0
        },
        point7: {
            x: 75.5,
            y: 0
        },
        control8: {
            x: 87,
            y: 0
        },
        point8: {
            x: 87,
            y: 0
        },
        control9: {
            x: 98.2,
            y: 0
        },
        point9: {
            x: 98.5,
            y: 0
        },
        control10: {
            x: 110.5,
            y: 0
        },
        point10: {
            x: 110.5,
            y: 0
        },
        control11: {
            x: 122,
            y: 0
        },
        point11: {
            x: 122,
            y: 0
        },
        control12: {
            x: 133,
            y: 0
        },
        point12: {
            x: 133,
            y: 0
        }

    };

    function mapDataRange(value) {
        return (value - 0) * (svgViewBoxGraphMax - svgViewBoxGraphMin) / (svgViewBoxHeight - 0) + svgViewBoxGraphMin;
    }

    function updateSlider($element, key) {
        if ($element) {
            var rangeIndex = $element.getAttribute('data-slider-index'),
                range = ranges[rangeIndex],
                value = $element.value;
            ranges[rangeIndex] = value;
            var parent = $element.parentElement,
                $thumb = parent.querySelector('.range-slider__thumb'),
                $bar = parent.querySelector('.range-slider__bar'),
                pct = (value / key)*100;
            $thumb.style.bottom = pct + '%';
            $bar.style.height = 'calc(' + pct + '% + ' + sliderThumbSize / 2 + 'px)';
            renderSliderGraph(key);
        }
    }

    function updatePoints(key) {
        points.point1.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range1 / key | 0;
        points.point2.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range2 / key | 0;
        points.point3.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range3 / key | 0;
        points.point4.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range4 / key | 0;
        points.point5.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range5 / key | 0;
        points.point6.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range6 / key | 0;
        points.point7.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range7 / key | 0;


        points.point8.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range8 / key | 0;
        points.point9.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range9 / key | 0;
        points.point10.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range10 / key | 0;
        points.point11.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range11 / key | 0;
        points.point12.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range12 / key | 0;

        var max = svgViewBoxGraphMax;
        var min = svgViewBoxGraphMin;
        points.point1.y = mapDataRange(points.point1.y);
        points.point2.y = mapDataRange(points.point2.y);
        points.point3.y = mapDataRange(points.point3.y);
        points.point4.y = mapDataRange(points.point4.y);
        points.point5.y = mapDataRange(points.point5.y);
        points.point6.y = mapDataRange(points.point6.y);
        points.point7.y = mapDataRange(points.point7.y);

        points.point8.y = mapDataRange(points.point8.y);
        points.point9.y = mapDataRange(points.point9.y);
        points.point10.y = mapDataRange(points.point10.y);
        points.point11.y = mapDataRange(points.point11.y);
        points.point12.y = mapDataRange(points.point12.y);

        points.begin.y = points.point1.y;
        points.control1.y = points.point1.y;
        points.control2.y = points.point2.y;
        points.control3.y = points.point3.y;
        points.control4.y = points.point4.y;
        points.control5.y = points.point5.y;
        points.control6.y = points.point6.y;
        points.control7.y = points.point7.y;

        points.control8.y = points.point8.y;
        points.control9.y = points.point9.y;
        points.control10.y = points.point10.y;
        points.control11.y = points.point11.y;
        points.control12.y = points.point12.y;
    }

    function getInterpolatedLine(type) {
        return 'M {0},{1} L {2},{3}L {6},{7}L {10} {11}L {14} {15}L {18} {19}L {22} {23}L {26} {27}L{30} {31}L{34} {35}L {38} {39}L {42} {43}L {46} {47}'
            .format(points.begin.x, points.begin.y,
                points.point1.x, points.point1.y, points.control1.x, points.control1.y,
                points.control2.x, points.control2.y, points.point2.x, points.point2.y,
                points.control3.x, points.control3.y, points.point3.x, points.point3.y,
                points.control4.x, points.control4.y, points.point4.x, points.point4.y,
                points.control5.x, points.control5.y, points.point5.x, points.point5.y,
                points.control6.x, points.control6.y, points.point6.x, points.point6.y,
                points.control7.x, points.control7.y, points.point7.x, points.point7.y,
                points.control8.x, points.control8.y, points.point8.x, points.point8.y,
                points.control9.x, points.control9.y, points.point9.x, points.point9.y,
                points.control10.x, points.control10.y, points.point10.x, points.point10.y,
                points.control11.x, points.control11.y, points.point11.x, points.point11.y,
                points.control12.x, points.control12.y, points.point12.x, points.point12.y);
    }

    function reset() {
        var inputs = app.inputs;
        inputs.forEach(function (input) {
            return app.updateSlider(input);
        });
    }

    function renderSliderGraph(key,c) {
        updatePoints(key);
        $svgLine.setAttribute('d', getInterpolatedLine(c));
        //$svgLineShadow.setAttribute('d', getInterpolatedLine('shadow'));
    }

    function selectPreset(type, key) {
        var inputs = app.inputs;
        //inputs.forEach(function (input) {
        //  return input.value = Math.random() * 100 | 0;
        //});
        inputs.forEach(function (input) {
            return app.updateSlider(input, key);
        });
    }
    return {
        inputs: [].slice.call(document.querySelectorAll('.sliders input')),
        updateSlider: updateSlider,
        reset: reset,
        selectPreset: selectPreset
    };
}();
function Getinteger(MaxNum, aver) {
    MaxNum = (MaxNum*1).toFixed(0);
    var gNum = Math.pow(10, MaxNum.toString().length - 2) * 2;
    var CNum = Math.pow(10, MaxNum.toString().length - 1);
    while (CNum < MaxNum)
        CNum += CNum;
    CNum -= CNum;
    while (CNum < MaxNum)
        CNum += gNum;
    var aNum = (CNum / aver).toFixed(0);
    if (CNum > 10)
        while (aNum.toString().substring(aNum.toString().length - 1) != "0") {
            aNum = (aNum * 1) + 1;
        }
    return aNum * aver;
}

(function ($, window, document) {
    'use strict';
    $.fn.Eat_Arc = function (options) {
        options = $.extend({
            'chartdata1': {
                data: [{
                    name: "天涯区",
                    value: 89
                },
                  {
                      name: "天涯区",
                      value: 45
                  },
                  {
                      name: "天涯区",
                      value: 10
                  },
                  {
                      name: "天涯区",
                      value: 56
                  }],
                Title: "上月各行政区游客消费金额"
            },
            'chartdata1_1': {
                data: {x:1200,s:1834},
                Title: "上月全市消费金额"
            },
            'chartdata2': {
                data: [{
                    name: "金额(万元）",
                    value: "12,433.19",
                },
                    {
                        name: "刷卡笔数",
                        value: "129211",
                    },
                    {
                        name: "刷卡人数（人）",
                        value: "938295",
                    },
                    {
                        name: "人均消费（元）",
                        value: "1000",
                    }],
                Title: "昨日消费指数"
            },
            'chartdata3': {
                lables: [
                    "0", "1000", "600", "3000", "4000", "5000", "6000", "7000", "8000", "9000", "10000", "1万以上"
                ],
                data: [
                    200, 500, 200, 500, 200, 660, 280, 700, 200, 900, 500, 990
                ],
                Title: "最近12个月国内游客驻留时间统计"
            },
            'chartdata4': {
                data: [{
                    name: "三亚天域事业有限公司天域度假酒店",
                    value: 9870
                },
                  {
                      name: "三亚克洛伊摄影有限公司",
                      value: 9570
                  },
                  {
                      name: "三亚田独南竹商场",
                      value: 9470
                  },
                  {
                      name: "天津",
                      value: 8100
                  },
                  {
                      name: "香港",
                      value: 9870
                  },
                  {
                      name: "俄罗斯",
                      value: 9870
                  },
                  {
                      name: "俄罗斯",
                      value: 9870
                  },
                  {
                      name: "香港",
                      value: 9870
                  },
                  {
                      name: "北京",
                      value: 9870
                  },
                  {
                      name: "北京",
                      value: 9870
                  }],
                Title: "上月游客消费金额TOP10店铺"
            },
            'chartdata5': {
                data: [{
                    name: "北京",
                    value: 9870
                },
                  {
                      name: "黑龙江",
                      value: 9570
                  },
                  {
                      name: "吉林",
                      value: 9470
                  },
                  {
                      name: "天津",
                      value: 8100
                  },
                  {
                      name: "香港",
                      value: 9870
                  },
                  {
                      name: "俄罗斯",
                      value: 9870
                  },
                  {
                      name: "俄罗斯",
                      value: 9870
                  },
                  {
                      name: "香港",
                      value: 9870
                  },
                  {
                      name: "北京",
                      value: 9870
                  },
                  {
                      name: "北京",
                      value: 9870
                  }],
                Title: "昨日游客消费金额来源地TOP10"
            },
            'chartdata6': {
                labels: ["吃", "娱", "购", "游", "住"],
                Nums: [25, 50, 60, 30, 30],
                Max: 80,//Nums值和这Max值比
                Title: "最近12个月入境游客驻留时间统计"
            },
            'upDatatime': { time: "2016-10-10 12:35" }
        }, options);

        function Chart1(data) {
            if (data) {
                var d = data.data;
                var MaxNum = d[0].value;
                for (var i = 1; i < d.length; i++) {
                    if (MaxNum < d[i].value)
                        MaxNum = d[i].value;
                }
                var column = '<div class="column"><div class="Num"></div><div class="bar"></div> <div class="labName"></div></div>';
                var chartContent1 = $(".chartContent1");
                chartContent1.find(".bar").css("height", 0);
                chartContent1.find(".title").text(data.Title);
                MaxNum = Getinteger(MaxNum,8);
                for (var f = 0; f < 8; f++) {
                    chartContent1.find(".chart_tick>div").eq(f).find("span").text(((MaxNum / 8) * (8 - f)).toFixed(0));
                }
                setTimeout(function () {
                    chartContent1.find(".column").remove();
                    for (var i = 0; i < d.length; i++) {
                        var _d = d[i];
                        var newItem = $(column);
                        newItem.css("left", (78) * i + 40);
                        if (i == 0)
                            newItem.css("left", 40);
                        newItem.find(".Num").text(_d.value).end().find(".labName").text(_d.name).end();
                        newItem.insertBefore(chartContent1.find(".lable_jia"));
                        newItem.find(".bar").animate({
                            "height": (160 * (_d.value / MaxNum))
                        });
                    }
                }, 300);
            }
        }

        function Chart1_1(data) {
            var count = data.data.x + data.data.s;
          
            var chartContent1_1 = $(".chartContent1_1");
            chartContent1_1.removeClass("show");
            chartContent1_1.find(".title").text(data.Title);
            $("#xMoney").text(data.data.x);
            $("#sMoney").text(data.data.s);
            chartContent1_1.find(".SumMoney").text(count);

            var sss = 680 * (data.data.s / count);
            console.log(sss);
            if (!Highcharts.theme) {
                Highcharts.setOptions({
                    chart: {
                        backgroundColor: 'transparent'
                    },
                    colors: ['#F39800', '#7ecef4'],
                    title: {
                        style: {
                            color: 'silver'
                        }
                    },
                    tooltip: {
                        style: {
                            color: 'silver'
                        }
                    }
                });
            }
            Highcharts.chart('container', {
                chart: {
                    type: 'solidgauge',
                    marginTop: 0
                },
                credits: {
                },
                title: {
                    text: ""
                },
                tooltip: {
                    borderWidth: 0,
                    backgroundColor: 'none',
                    shadow: true,
                },
                credits: {
                    text: '',
                    href: ''
                },
                pane: {
                    startAngle: 0,
                    endAngle: sss,
                    background: [{
                        outerRadius: '66%',
                        innerRadius: '45%',
                        backgroundColor: Highcharts.Color(Highcharts.getOptions().colors[1]).setOpacity(1).get(),
                        borderWidth: 0,
                    }]
                },
                yAxis: {
                    min: 0,
                    max: 100,
                    lineWidth: 0,
                    tickPositions: []
                },
                plotOptions: {
                    solidgauge: {
                        borderWidth: '10px',
                        dataLabels: {
                            enabled: false
                        },
                        linecap: 'round',
                        stickyTracking: false
                    }
                },
                series: [{
                    name: 'Move',
                    borderColor: Highcharts.getOptions().colors[0],
                    data: [{
                        color: Highcharts.getOptions().colors[0],
                        radius: '59%',
                        innerRadius: '51%',
                        y: 50
                    }]
                }]
            });


            chartContent1_1.addClass("show");

        }

        function Chart2(data) {
            if (data) {
                var chartContent2 = $(".chartContent2");
                chartContent2.find(".title").text(data.Title);
                chartContent2.find(".item").remove();
                var html = '<div class="item"><div class="name"></div><div class="num"></div></div>';
                for (var i = 0; i < data.data.length; i++) {
                    $(html).find(".num").text(data.data[i].value).end().find(".name").text(data.data[i].name).end().appendTo(chartContent2.find(".content"))
                    .addClass("fanda");
                }
            }
        }

        function Chart3(data) {
            if (data) {
                $("path.line").attr("class", "line");
                var inputs = app.inputs;
                var index = 1;
                var MaxNum = 0;
                if (data) {
                    var chartContent3 = $(".chartContent3");
                    $(chartContent3).find(".title").text(data.Title);
                    for (var i = 0; i < data.data.length; i++) {
                        var d = data.data[i];
                        var ranger = chartContent3.find(".range-slider").eq(i);

                        ranger.find("input").val(d);
                        if (MaxNum < d)
                            MaxNum = d;
                    }
                }
                for (var i = 0; i < data.lables.length; i++) {
                    $(".range-slider_lab").eq(i).text(data.lables[i]);
                }
                chartContent3.find(".range-slider").attr("max", MaxNum);
                MaxNum = Getinteger(MaxNum,7);
                for (var f = 0; f < 9; f++) {
                    chartContent3.find(".tickline>div").eq(f).find("span").text(((MaxNum / 7) * (7 - f)).toFixed(0));
                }
                inputs.forEach(function (input) {
                    return input.setAttribute('data-slider-index', 'range' + index++);
                });
                inputs.forEach(function (input) {
                    return app.updateSlider(input, (MaxNum));
                });
                setTimeout(function () {
                    $("path.line").attr("class", "line path ");
                }, 300);
            }
        }

        function Chart4(data) {
            var chartContent4 = $(".chartContent4");
            chartContent4.find(".item").remove();
            if (data) {
                data.data = data.data.sort(function (a, b) {
                    return a.value < b.value;
                });
                chartContent4.find(".title").text(data.Title);
                var d = data.data;
                var MaxNum = d[0].value;
                for (var i = 0; i < d.length; i++) {
                    var _d = d[i];
                    var newItem = $('<div class="item"></div>');
                    $('<div class="name">' + _d.name + '</div>').appendTo(newItem);
                    var Wi = 280;
                    Wi = Wi * (_d.value / MaxNum);
                    $('<div class="probar"><span class="hexagon"><img src="http://' + window.location.host + '/systatic/Aw_images/ico_number_0' + (i > 2 ? 4 : i + 1) + '.svg" /><span class="index">' + (i + 1) + '</span></span><span class="bar"></span></div>').appendTo(newItem);
                    $('<div>' + _d.value + '</div>').appendTo(newItem);
                    newItem.appendTo(chartContent4.find(".content"));
                    newItem.find(".bar").animate({
                        "width": Wi
                    });
                }
            }
        }

        function Chart5(data) {
            var chartContent5 = $(".chartContent5");
            chartContent5.find(".item").remove();
            if (data) {
                data.data = data.data.sort(function (a, b) {
                    return a.value < b.value;
                });
                chartContent5.find(".title").text(data.Title);
                var d = data.data;
                var MaxNum = d[0].value;
                for (var i = 0; i < d.length; i++) {
                    var _d = d[i];
                    var newItem = $('<div class="item"></div>');
                    $('<div class="name">' + _d.name + '</div>').appendTo(newItem);
                    var Wi = 360;
                    Wi = Wi * (_d.value / MaxNum);
                    $('<div class="probar"><span class="hexagon"><img src="http://' + window.location.host + '/systatic/Aw_images/ico_number_0' + (i > 2 ? 4 : i + 1) + '.svg" /><span class="index">' + (i + 1) + '</span></span><span class="bar"></span></div>').appendTo(newItem);
                    $('<div>' + _d.value + '</div>').appendTo(newItem);
                    newItem.appendTo(chartContent5.find(".content"));
                    newItem.find(".bar").animate({
                        "width": Wi
                    });
                }
            }
        }

        function Chart6(data) {
            if (data) {
                var myChart = echarts.init(document.getElementById('radar1'));
                $(".chartContent6 .title").text(data.Title);

                var indicators = [];
                for (var i = 0; i < data.labels.length; i++) {
                    indicators.push({ name: data.labels[i], max: data.Max });
                }
                var option = {
                    title: {
                        text: ''
                    },
                    tooltip: {},
                    legend: {

                    },
                    radar: {
                        name: {
                            textStyle: {
                                color: "#fff",
                                fontSize: 14
                            }
                        },
                        indicator: indicators,
                        axisLine: {
                            lineStyle: {
                                color: "#068187"
                            }
                        }
                        ,
                        splitLine: {
                            lineStyle: {
                                color: "#068187"
                            }
                        },
                        splitArea: {
                            areaStyle: {
                                color: ['rgba(250,250,250,0)', 'rgba(200,200,200,0)', 'rgba(200,200,200,0)']
                            }
                        }
                    },
                    series: [{
                        name: '',
                        type: 'radar',
                        symbolSize: 5,
                        itemStyle: {
                            normal: {
                                color: "#fff",
                                borderColor: "rgba(1, 181, 181, 0.5)",
                                borderWidth: 6,
                                areaStyle: {
                                    color: "#01B5B5",
                                    opacity: ".3"
                                }
                            }
                        },
                        lineStyle: {
                            normal: {
                                color: "#fff"
                            }
                        }, label: {
                            normal: {
                                show: true,
                                formatter: function (params) {
                                    return params.value;
                                },
                                textStyle: {
                                    color: "#01B5B5"
                                }
                            }
                        },
                        data: [
                            {
                                value: data.Nums,
                                name: ''
                            }
                        ]
                    }]
                }
                myChart.setOption(option);

            }
        }

        function Updata(time) {
            $(".updateTime").stop().slideUp(function () {
                $(".updateTime").text(time).stop().slideDown();
            });
        }
        Chart1(options.chartdata1);
        Chart1_1(options.chartdata1_1);
        Chart2(options.chartdata2);
        Chart4(options.chartdata4);
        Chart6(options.chartdata6);
        Chart3(options.chartdata3);
        Chart5(options.chartdata5);
        Updata(options.upDatatime.time);
        return {
            loadChart1: Chart1,
            loadChart2: Chart2,
            loadChart3: Chart3,
            loadChart4: Chart4,
            loadChart5: Chart5,
            loadChart6: Chart6,
            Updata: Updata
        }
    }
})(jQuery, window, document)
