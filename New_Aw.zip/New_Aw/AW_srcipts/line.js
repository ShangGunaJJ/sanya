(function($,window,document){
    'use strict';
    $.fn.Lin_Arc=function(options){
        var LA=$.fn.Lin_Arc;
        options=$.extend({
            'InOutPort':{inP:7759,OutP:3000,Title:'今日航空出港实时人数'},//进港出港人数对象，inP是进港，OutP是出港,Title 进出港图表标题
            'MWThanDate':{MNum:6888,WNum:5666,Title:'今日男女比例（航空吞吐量）'},//航空吞吐量男女数量；MNum是男性数量,WNum是女性比列,Title 进出港图表标题
            'HighSInOut':{InS:5634,OutS:7568,Title:'昨日高铁进出站人数'},//高铁进出站人数；Ins是进站人数，OutS是出战人数,Title 高铁进出图表标题
            'TouristsNum':{Data:[{lable:"十一月",Num:20},{lable:"十二月",Num:36},{lable:"2016",Num:80},{lable:"二月",Num:54},{lable:"三月",Num:32},{lable:"四月",Num:43},{lable:"五月",Num:55},{lable:"六月",Num:65},{lable:"七月",Num:69},{lable:"八月",Num:74},{lable:"九月",Num:80},{lable:"十月",Num:85}],Title:'近十二个月游客人员人数'},//data 游客数据对象，Title 游客数量标题
            'AgeLag':{minor:1893,Adults:3982,elderly:1238,Title:'今日年龄结构（航空吞吐量）'},//年龄结构；minor年轻人，Adults成年人，elderly老年人,Title 标题
            'Customers':{Data:[{name:'广东',Num:705},{name:'江西',Num:283},{name:'湖南',Num:655},{name:'上海',Num:505},{name:'北京',Num:445},{name:'福建',Num:383},{name:'浙江',Num:233},{name:'四川',Num:188},{name:'浙江',Num:233},{name:'云南',Num:120}],Title:'9月28日 航空客源地排名 TOP10'},
            'FlightData':{Data:[{year:2014,offland:100065,throughput:1493.72},{year:2015,offland:106869,throughput:1619.19}],Title:'2014/2015 凤凰机场客运起降航班及吞吐量情况比较'},
        },options);
        function TouristInit(){
            var tourists=$(".tourists");
            tourists.find(".item").remove();
            if(options.Customers&&options.Customers.Data){
                tourists.find(">p.title").text(options.Customers.Title);
                options.Customers.Data=options.Customers.Data.sort(function(a,b){return a.Num<b.Num;});
                var MaxNum=options.Customers.Data[0].Num;
                for(var i=0;i<options.Customers.Data.length;i++){
                    var d=options.Customers.Data[i];
                    var newItem=$('<div class="item"><div>');
                    $('<div class="name">'+d.name+'</div>').appendTo(newItem);
                    var Wi=430;
                    Wi=Wi*(d.Num/MaxNum);
                    $('<div class="probar"><span class="hexagon">'+(i+1)+'</span><span class="bar"></span></div>').appendTo(newItem);
                    $('<div>'+d.Num+' 人</div>').appendTo(newItem);
                    newItem.appendTo(tourists);
                    newItem.find(".bar").animate({"width":Wi});
                }
            }
        }
        function FlightInit(){
            var figthElem=$(".throughput");
            if(options.FlightData&&options.FlightData.Data){
                figthElem.find(".title").text(options.FlightData.Title);
                var offlandCon=(((options.FlightData.Data[1].offland-options.FlightData.Data[0].offland)/options.FlightData.Data[0].offland)*100).toFixed(1);
                var thCon=(((options.FlightData.Data[1].throughput-options.FlightData.Data[0].throughput)/options.FlightData.Data[0].throughput)*100).toFixed(1);  figthElem.find(".Tab_title").find(".contrast_year_1").text(options.FlightData.Data[0].year).end().find(".contrast_year_2").text(options.FlightData.Data[1].year);
  figthElem.find(".row").eq(0).find(".contrast_year_1").text(options.FlightData.Data[0].offland).end().find(".contrast_year_2").text(options.FlightData.Data[1].offland).end().find(".contrast_td").text(offlandCon+"%");
  figthElem.find(".row").eq(1).find(".contrast_year_1").text(options.FlightData.Data[0].throughput).end().eq(1).find(".contrast_year_2").text(options.FlightData.Data[1].throughput).end().find(".contrast_td").text(thCon+"%");
            }
        }
        function Initchart(){
           var today =$(".today");
            if(options.InOutPort){
                today.find(".title").text(options.InOutPort.Title);
                today.find(".Inport .Num").text(options.InOutPort.inP);
                today.find(".OutPort .Num").text(options.InOutPort.OutP);
                if(options.InOutPort.inP>options.InOutPort.OutP)
                  {  
                    today.find(".Inport .bar").css("height","100px");
                     today.find(".OutPort .bar").css("height",100*(options.InOutPort.OutP/options.InOutPort.inP));
                  }
                else{
                 today.find(".OutPort .bar").css("height","100px");
                       today.find(".Inport .bar").css("height",100*(options.InOutPort.inP/options.InOutPort.OutP));
                } 
            }
            var age_pro=$(".age_pro");
            if(options.AgeLag){
                age_pro.find(".title").text(options.AgeLag.Title);
                var MaxNum=options.AgeLag.Adults>options.AgeLag.elderly&& options.AgeLag.Adults>options.AgeLag.minor?options.AgeLag.Adults:options.AgeLag.minor>options.AgeLag.elderly?options.AgeLag.minor:options.AgeLag.elderly;
                age_pro.find(".minor").find(".Num").text(options.AgeLag.minor+" 人").end().find(".bar").css("height",180*(options.AgeLag.minor/MaxNum));
                age_pro.find(".Adults").find(".Num").text(options.AgeLag.Adults+" 人").end().find(".bar").css("height",180*(options.AgeLag.Adults/MaxNum));
                age_pro.find(".elderly").find(".Num").text(options.AgeLag.elderly+" 人").end().find(".bar").css("height",180*(options.AgeLag.elderly/MaxNum));
            }
        }
        function initAndSetupTheSliders() {
            var inputs = app.inputs;
           var index = 1;
            if(options.TouristsNum){
                var sliders=$(".graph .sliders");
                $(".graph .title").text(options.TouristsNum.Title);
                for(var i=0;i<12;i++){
                    var d=options.TouristsNum.Data[i];
                    var ranger=sliders.find(".range-slider").eq(i);
                    ranger.find("input").val(d.Num);
                    ranger.find(".range-slider_lab").text(d.lable);
                }
            }
           inputs.forEach(function (input) {
              return input.setAttribute('data-slider-index', 'range' + index++);
            });
           inputs.forEach(function (input) {
             return app.updateSlider(input);
           });  
          app.selectPreset('custom');
          $("path.line").addClass("path");
        }
        function InitChart1(){
            var mc=options.MWThanDate.MNum+options.MWThanDate.WNum;
            var mcc=((options.MWThanDate.MNum/mc)*100).toFixed(1);
            var wcc=((options.MWThanDate.WNum/mc)*100).toFixed(1);
            $(".gender .title").text(options.MWThanDate.Title);
            $(".gender .man p").text(mcc+" %");
            $(".gender .woman p").text(wcc+" %");
             $(".gender .G-man p").text(options.MWThanDate.MNum);
            $(".gender .G-woman p").text(options.MWThanDate.WNum);
            var hs=$(".speed1");
            hs.find(".title").text(options.HighSInOut.Title);
            hs.find(".S-exit p").text(options.HighSInOut.InS);
            hs.find(".S-enter p").text(options.HighSInOut.OutS);
            
            var hc=options.HighSInOut.InS+options.HighSInOut.OutS;
            var icc=((options.HighSInOut.InS/hc)*100).toFixed(1);
            var occ=((options.HighSInOut.OutS/hc)*100).toFixed(1);
            
            hs.find(".enter").text("进站 "+options.HighSInOut.InS+"%");
           
            hs.find(".speed-right .exit").text("出站 "+options.HighSInOut.OutS+"%");
            
            $("#gender").highcharts({   
      chart: {
       backgroundColor:"transparent",
       plotBackgroundColor: null,
       plotBorderWidth: null,
       plotShadow: false
   },
   title: {
      text: ''   
   },  
   tooltip: {
     enabled: false
   },
   plotOptions: {
      pie: {
         allowPointSelect: true,
         cursor: 'pointer',
         dataLabels: {
            enabled: false,
            format: '<b>{point.name}%</b>: {point.percentage:.1f} %',
            style: {
               color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
            }
         }
      }
   },
   credits: {
      enabled: false
   },
   series:[{
      type: 'pie',
      name: 'Browser share',
       innerSize:'45%',
      data: [
          {name:'女性',y:(wcc*1),color:'#9E029C'},
         {
            name: '男性',
            y:(mcc*1),
             color:'#0556AA'
         }
      ]
   }]
   })
            $("#speed").highcharts({
              chart: {
       backgroundColor:"transparent",
       plotBackgroundColor: null,
       plotBorderWidth: null,
       plotShadow: false
   },
              title: {
      text: ''   
   },  
              tooltip: {
            enabled: false
        },
              plotOptions: {
      pie: {
         allowPointSelect: true,
         cursor: 'pointer',
          innerSize:'50%',
         dataLabels: {
            enabled: false,
            format: '<b>{point.name}%</b>: {point.percentage:.1f} %',
            style: {
               color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
            }
         }
      }
   },
              credits: {
      enabled: false
   },
              labels: {
    items: [{                       // items 数组，可以设置多个标签
        html: '<div>\<img src=\"images\/ico_xing_c3_out.png\"\/\>进站45%</div>',
        style: {                    // 标签样式，会继承和重写上层全局样式
            left: '275px',
            top: '75px',
            color: '#fff',
            fontSize: '12px',
            fontWeight: 'normal',
            fontFamily: '' 
        }
    },{                       // items 数组，可以设置多个标签
        html: '<div><img src="images/ico_xing_c3_out.png"/>出站55%</div>',
        style: {                    // 标签样式，会继承和重写上层全局样式
            left: '275px',
            top: '115px',
            color: '#fff',
            fontSize: '12px',
            fontWeight: 'normal',
            fontFamily: '' 
        }
    }]
},
              series:[{
      type: 'pie',
      name: 'Browser share',
      data: [
         {name:'出站',y:(icc*1),color:'#01ADA5'},
         {
            name: '进站',
            y:(occ*1),
             color:'#0285C2',
            sliced: false,
            selected: false
         },
      ]
   }]
   });
        }
        Initchart();
        InitChart1();
        TouristInit();
        FlightInit();
        initAndSetupTheSliders();
    }
})(jQuery,window,document)