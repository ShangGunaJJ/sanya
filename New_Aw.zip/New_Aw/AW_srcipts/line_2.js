'use strict';
if (!String.prototype.format) {
    String.prototype.format = function () {
        var args = arguments;
        return this.replace(/{(\d+)}/g, function (match, number) {
            return typeof args[number] != 'undefined' ? args[number] : match;
        });
    };
}
var app = function () {
    var $svgLine = document.querySelector('.chartContent6 svg .line');
    var sliderThumbSize = 0;
    var sliderHeight = 120;
    var svgViewBoxHeight = 100;
    var svgViewBoxThumbLimit = sliderThumbSize / 2 * (svgViewBoxHeight / sliderHeight);
    var svgViewBoxGraphMax = svgViewBoxHeight - svgViewBoxThumbLimit;
    var svgViewBoxGraphMin = svgViewBoxThumbLimit;
    var ranges = {
        range1: null,
        range2: null,
        range3: null,
        range4: null,
        range5: null,
        range6: null,
        range7: null,
        range8: null,
        range9: null,
        range10: null,
        range11: null,
        range12: null
    };
    var points = {
        begin: {
            x: 11,
            y: 0
        },
        point1: {
            x: 11,
            y: 0
        },
        control1: {
            x: 11,
            y: 0
        },
        control2: {
            x: 23,
            y: 0
        },
        point2: {
            x: 24,
            y: 0
        },
        control3: {
            x: 34,
            y: 0
        },
        point3: {
            x: 34,
            y: 0
        },
        control4: {
            x: 45,
            y: 0
        },
        point4: {
            x: 45,
            y: 0
        },
        control5: {
            x: 56,
            y: 0
        },
        point5: {
            x: 56,
            y: 0
        },
        control6: {
            x: 67,
            y: 0
        },
        point6: {
            x: 67,
            y: 0
        },
        control7: {
            x: 78,
            y: 0
        },
        point7: {
            x: 78,
            y: 0
        },
        control8: {
            x: 89,
            y: 0
        },
        point8: {
            x: 89,
            y: 0
        },
        control9: {
            x: 100,
            y: 0
        },
        point9: {
            x: 100,
            y: 0
        },
        control10: {
            x: 112,
            y: 0
        },
        point10: {
            x: 112,
            y: 0
        },
        control11: {
            x: 123,
            y: 0
        },
        point11: {
            x: 123,
            y: 0
        },
        control12: {
            x: 134,
            y: 0
        },
        point12: {
            x: 133,
            y: 0
        }

    };

    function mapDataRange(value) {
        return (value - 0) * (svgViewBoxGraphMax - svgViewBoxGraphMin) / (svgViewBoxHeight - 0) + svgViewBoxGraphMin;
    }

    function updateSlider($element, keyS, line, count) {
        $svgLine = line;
        if ($element) {
            var rangeIndex = $element.getAttribute('data-slider-index'),
                range = ranges[rangeIndex],
                value = $element.value;

            ranges[rangeIndex] = value;
            var parent = $element.parentElement,
                $thumb = parent.querySelector('.range-slider__thumb'),
                $bar = parent.querySelector('.range-slider__bar'),
                pct = (value / keyS) * 100;
            $thumb.style.bottom = pct + '%';
            $bar.style.height = 'calc(' + pct + '% + ' + sliderThumbSize / 2 + 'px)';
            renderSliderGraph(keyS);
        }
    }

    function updatePoints(key) {
        points.point1.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range1 / key | 0;
        points.point2.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range2 / key | 0;
        points.point3.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range3 / key | 0;
        points.point4.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range4 / key | 0;
        points.point5.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range5 / key | 0;
        points.point6.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range6 / key | 0;
        points.point7.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range7 / key | 0;


        points.point8.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range8 / key | 0;
        points.point9.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range9 / key | 0;
        points.point10.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range10 / key | 0;
        points.point11.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range11 / key | 0;
        points.point12.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range12 / key | 0;

        var max = svgViewBoxGraphMax;
        var min = svgViewBoxGraphMin;
        points.point1.y = mapDataRange(points.point1.y);
        points.point2.y = mapDataRange(points.point2.y);
        points.point3.y = mapDataRange(points.point3.y);
        points.point4.y = mapDataRange(points.point4.y);
        points.point5.y = mapDataRange(points.point5.y);
        points.point6.y = mapDataRange(points.point6.y);
        points.point7.y = mapDataRange(points.point7.y);

        points.point8.y = mapDataRange(points.point8.y);
        points.point9.y = mapDataRange(points.point9.y);
        points.point10.y = mapDataRange(points.point10.y);
        points.point11.y = mapDataRange(points.point11.y);
        points.point12.y = mapDataRange(points.point12.y);

        points.begin.y = points.point1.y;
        points.control1.y = points.point1.y;
        points.control2.y = points.point2.y;
        points.control3.y = points.point3.y;
        points.control4.y = points.point4.y;
        points.control5.y = points.point5.y;
        points.control6.y = points.point6.y;
        points.control7.y = points.point7.y;

        points.control8.y = points.point8.y;
        points.control9.y = points.point9.y;
        points.control10.y = points.point10.y;
        points.control11.y = points.point11.y;
        points.control12.y = points.point12.y;
    }

    function getInterpolatedLine(type) {
        return 'M {0},{1} L {2},{3} L {6},{7} L {10} {11}L {14} {15}L {18} {19}L {22} {23}L {26} {27}L{30} {31}L {34} {35}L {38} {39}L {42} {43}L {46} {47}'
            .format(points.begin.x,
                points.begin.y,
                points.point1.x,
                points.point1.y,
                points.control1.x,
                points.control1.y,
                points.control2.x,
                points.control2.y,
                points.point2.x,
                points.point2.y,
                points.control3.x,
                points.control3.y,
                points.point3.x,
                points.point3.y,
                points.control4.x,
                points.control4.y,
                points.point4.x,
                points.point4.y,
                points.control5.x,
                points.control5.y,
                points.point5.x,
                points.point5.y,
                points.control6.x,
                points.control6.y,
                points.point6.x,
                points.point6.y,
                points.control7.x, points.control7.y, points.point7.x, points.point7.y,
                points.control8.x, points.control8.y, points.point8.x, points.point8.y,
                points.control9.x, points.control9.y, points.point9.x, points.point9.y,
                points.control10.x, points.control10.y, points.point10.x, points.point10.y,
                points.control11.x, points.control11.y, points.point11.x, points.point11.y,
                points.control12.x, points.control12.y, points.point12.x, points.point12.y);
    }

    function reset() {
        var inputs = app.inputs;
        inputs.forEach(function (input) {
            return app.updateSlider(input);
        });
    }

   function renderSliderGraph(k,c) {
        updatePoints(k);
        $svgLine.setAttribute('d', getInterpolatedLine(c));
    }

    function selectPreset(key, el) {
        var inputs = app.inputs;
        $svgLine = el;
        inputs.forEach(function (input) {
            return app.updateSlider(input, key);
        });
    }
    return {
        inputs: [].slice.call(document.querySelectorAll('.sliders input')),
        updateSlider: updateSlider,
        reset: reset,
        selectPreset: selectPreset,
        $svgLine: null,

    };
}();

function Getinteger(MaxNum, aver) {
    MaxNum = (MaxNum*1).toFixed(0);
    var gNum = Math.pow(10, MaxNum.toString().length - 2) * 2;
    var CNum = Math.pow(10, MaxNum.toString().length - 1);
    while (CNum < MaxNum)
        CNum += CNum;
    CNum -= CNum;
    while (CNum < MaxNum)
        CNum += gNum;
    var aNum = (CNum / aver).toFixed(0);
    if (CNum > 10)
        while (aNum.toString().substring(aNum.toString().length - 1) != "0") {
            aNum = (aNum * 1) + 1;
        }
    return aNum * aver;
}

(function ($, window, document) {
    'use strict';
    $.fn.Lin_Arc2 = function (options) {
        var LA = $.fn.Lin_Arc2;
        options = $.extend({
            'chartdata1': {
                data: [{
                    name: "公交车",
                    num: 490
                }, {
                    name: "出租车",
                    num: 2492
                }, {
                    name: "滴滴专车",
                    num: 1360
                }, {
                    name: "神州专车",
                    num: 500
                }, {
                    name: "神州专车",
                    num: 500
                }],
                Title: '公共交通工具实时在线统计'
            },
            'chartdata2': {
                data: [{
                        name: "公交车",
                        value: [
                        1000, 2000, 2222, 3333, 1200, 1000, 2000, 2222, 3333, 1200, 3333, 1200,
                    ]
                },
                    {
                        name: "出租车",
                        value: [4300, 3000, 4222, 3333, 1200, 1200, 2400, 2522, 2333, 1200, 3633, 1800, ]
                    }
                ],
                Title: '最近30天分时段日均运营车辆数量'
            },
            'chartdata3': {
                data: {
                    MaxTime: [
                        {
                            name: "5路",
                            value: 52
                        }, {
                            name: "4路",
                            value: 42
                        },
                        {
                            name: "3路",
                            value: 58
                        },
                        {
                            name: "2路",
                            value: 46
                        },
                        {
                            name: "1路",
                            value: 31
                        }
                    ],
                    MinTime: [
                        {
                            name: "5路",
                            value: 4
                        }, {
                            name: "4路",
                            value: 10
                        },
                        {
                            name: "3路",
                            value: 9
                        },
                        {
                            name: "2路",
                            value: 8
                        },
                        {
                            name: "1路",
                            value: 2
                        }
                    ]
                },
                Title: '昨日运行速度最快/慢公交线路TOP5'
            },
            'chartdata4': {
                data: [{
                    name: "海棠区",
                    nums: [30, 138]
                }, {
                    name: "天涯区",
                    nums: [251, 1138]
                }, {
                    name: "涯洲区",
                    nums: [39, 41]
                }, {
                    name: "吉阳区",
                    nums: [167, 1008]
                }],
                Title: '三亚各行政区公共交通工具实时在线统计'
            }, //nums数组索引第一个是公交车，第二个是出租车
            'chartdata5': {
                data: [{
                        name: "崖州区",
                        value: [
                        50, 60, 35, 38, 40, 45, 46, 40, 38, 28, 20, 15
                    ]
                },
                    {
                        name: "天涯区",
                        value: [55, 65, 40, 42, 46, 48, 50, 45, 35, 30, 30, 20]
                    }
                    , {
                        name: "海棠区",
                        value: [43, 56, 44, 40, 38, 50, 46, 30, 41, 21, 16, 20]
                    }, {
                        name: "海棠区",
                        value: [44, 55, 23, 35, 20, 35, 28, 39, 42, 40, 30, 35]
                    }
                ],
                Title: '各行政区最近30天公交车分时段日均运营速度'
            },
            'chartdata6': {
                data: [{
                    name: "5路",
                    wtime: 4.1
                }, {
                    name: "24路",
                    wtime: 4.9
                }, {
                    name: "41路",
                    wtime: 6.0
                }, {
                    name: "1路",
                    wtime: 12.2
                }, {
                    name: "10路",
                    wtime: 13.2
                }, {
                    name: "25路",
                    wtime: 40.21
                }],
                Title: '近5日内公交车站平均候车时间'
            },
        }, options);

        function Init1(data) {
            var chartContent1 = $(".chartContent1");
            chartContent1.find(".item").remove();
            if (data) {
                chartContent1.find(">p.title").text(data.Title);
                var d = data.data;
                var MaxNum = d[0].num;
                for (var i = 1; i < d.length; i++) {
                    if (MaxNum < d[i].num)
                        MaxNum = d[i].num;
                }
                for (var i = 0; i < d.length; i++) {
                    var _d = d[i];
                    var newItem = $('<div class="item bar"></div>');
                    $('<div class="name">' + _d.name + '</div>').appendTo(newItem);
                    var Wi = 200;
                    Wi = Wi * (_d.num / MaxNum);
                    $('<div class="probar"><span class="hexagon"></span><span class="barline"></span></div>').appendTo(newItem);
                    $('<div>' + _d.num + ' 辆</div>').appendTo(newItem);
                    newItem.appendTo(chartContent1);
                    newItem.find(".barline").animate({
                        "width": Wi
                    });
                }
            }
        }

        function Init2(data) {
            $("input").val(0);
            if (data) {
                var sliders = $(".chart_middle .panel_top");
                $(sliders).find(".title").text(data.Title);
                $(sliders).find(".lableee").find("div").eq(0).text(data.data[0].name);
                $(sliders).find(".lableee").find("div").eq(1).text(data.data[1].name);
                var _d = data.data[0];
                var _c = data.data[1];
                var MaxNum = 100;
                for (var i = 0; i < 12; i++) {
                    sliders.find(".Accept .range-slider").eq(i).find("input").val(_d.value[i]);
                    sliders.find(".End .range-slider").eq(i).find("input").val(_c.value[i]);
                    if (_d.value[i] > MaxNum)
                        MaxNum = _d.value[i];
                    if (_c.value[i] > MaxNum)
                        MaxNum = _c.value[i];
                }
                sliders.find(".tickline .Ctock").remove();
                MaxNum = Getinteger(MaxNum,6);
                $("<div class='Ctock'><span>" + ((MaxNum / 6) * (6)).toFixed(0) + "</span></div>").insertBefore(sliders.find(".tickline .Period"));
                $("<div class='Ctock'><span>" + ((MaxNum / 6) * (5)).toFixed(0) + "</span></div>").insertBefore(sliders.find(".tickline .Period"));
                $("<div class='Ctock'><span>" + ((MaxNum / 6) * (4)).toFixed(0) + "</span></div>").insertBefore(sliders.find(".tickline .Period"));
                $("<div class='Ctock'><span>" + ((MaxNum / 6) * (3)).toFixed(0) + "</span></div>").insertBefore(sliders.find(".tickline .Period"));
                $("<div class='Ctock'><span>" + ((MaxNum / 6) * (2)).toFixed(0) + "</span></div>").insertBefore(sliders.find(".tickline .Period"));
                $(".chartContent2 .Period>span").text(((MaxNum / 6) * (1)).toFixed(0));

                app.inputs = [].slice.call(document.querySelectorAll('.chart_middle .panel_top .Accept input'));
                var inputs = app.inputs;
                var index = 1;
                var p = document.querySelector('.chart_middle .panel_top .Accept svg .line');
                inputs.forEach(function (input) {
                    return input.setAttribute('data-slider-index', 'range' + index++);
                });
                inputs.forEach(function (input) {
                     return app.updateSlider(input, MaxNum, p);
                });

                var p1 = document.querySelector('.chart_middle .panel_top .End svg .line');
                app.inputs = [].slice.call(document.querySelectorAll('.chart_middle .panel_top .End input'));
                inputs = app.inputs;
                index = 1;
                inputs.forEach(function (input) {
                    return input.setAttribute('data-slider-index', 'range' + index++);
                });
                inputs.forEach(function (input) {
                    return app.updateSlider(input, MaxNum, p1);
                });
            }
        }

        function Init3(data) {                var chartContent3 = $(".chartContent3");
                chartContent3.parent().find(".title").text(data.Title);
                var MaxData = data.data.MaxTime.sort(function (a, b) {
                    return a.value < b.value
                });
                var MinData = data.data.MinTime.sort(function (a, b) {
                    return a.value < b.value
                });
                var MaxHtml = '<div class="item bar"><div class="name"></div><div class="probar"><span class="hexagon"></span><span class="barline"><span></span> </span> </div></div>';
                var MaxMan = chartContent3.find(".MaxMan");
                MaxMan.find(".item").hide().remove();
                for (var i = 0; i < MaxData.length; i++) {
                    var _d = MaxData[i];
                    var newItem = $(MaxHtml).appendTo(MaxMan);
                    newItem.find(".name").text(_d.name);
                    newItem.find(".hexagon").text(i + 1);
                    newItem.find(".barline span").text(_d.value);
                    var Wi = 0;
                    Wi = 220 * (_d.value / MaxData[1].value);
                    newItem.find(".barline").animate({
                        "width": Wi
                    });
                }
            if (data) {

                var MinHtml = '<div class="item bar"><div class="probar"><span class="hexagon"></span> <span class="barline"><span></span> </span> </div><div class="name"></div></div>';
                var MinMan = chartContent3.find(".MinMan");
                MinMan.find(".item").hide().remove();
                for (var i = 0; i < MinData.length; i++) {
                    var _d = MinData[i];
                    var newItem = $(MinHtml).appendTo(MinMan);
                    newItem.find(".name").text(_d.name);
                    newItem.find(".hexagon").text(MinData.length - i);
                    newItem.find(".barline span").text(_d.value);
                    var Wi = 0;
                    Wi = 120 * (_d.value / MinData[1].value);
                    newItem.find(".barline").animate({
                        "width": Wi
                    });
                }
            }
        }

        function Init4(data) {
            var chartContent4 = $(".chartContent4");
            chartContent4.find(".colpanel").remove();
            chartContent4.find(".footer>span").remove();
            if (data) {
                chartContent4.find(">p.title").text(data.Title);
                var d = data.data;
                var MaxNum = d[0].nums[0] > d[0].nums[1] ? d[0].nums[0] : d[0].nums[1];
                for (var i = 1; i < d.length; i++) {
                    var m = d[i].nums[0] > d[i].nums[1] ? d[i].nums[0] : d[i].nums[1];
                    if (MaxNum < m)
                        MaxNum = m;
                }
                var column = '<div class="column"><div class="Num"></div><div class="bar"></div></div>';
                for (var i = 0; i < d.length; i++) {
                    var _d = d[i];
                    var newItem = $('<div class="colpanel"></div>');
                    newItem.insertBefore(chartContent4.find(".chart_forbar .footer"));
                    var creatFnC = function (num) {
                        var co = $(column).find(".Num").text(num).end();
                        return co;
                    }
                    var Wi = 0;
                    var cc = creatFnC(_d.nums[0]).appendTo(newItem);
                    Wi = 160 * (_d.nums[0] / MaxNum);
                    cc.find(".bar").animate({
                        "height": Wi
                    });
                    var cc1 = creatFnC(_d.nums[1]).appendTo(newItem);
                    Wi = 160 * (_d.nums[1] / MaxNum);
                    cc1.find(".bar").animate({
                        "height": Wi
                    });

                    $("<span>" + _d.name + "</span>").appendTo(chartContent4.find(".footer"));
                }
            }

        }


        function Init5(data) {
            $("input").val(0);
            if (data) {
                var sliders = $(".chart_middle .panel_bottom");
                $(sliders).find(".title").text(data.Title);
                $(sliders).find(".lableee").find("div").eq(0).text(data.data[0].name);
                $(sliders).find(".lableee").find("div").eq(1).text(data.data[1].name);
                $(sliders).find(".lableee").find("div").eq(2).text(data.data[2].name);
                $(sliders).find(".lableee").find("div").eq(3).text(data.data[3].name);
                var _d = data.data[0];
                var _c = data.data[1];
                var _b = data.data[2];
                var _a = data.data[3];
                var MaxNum = 50;
                for (var i = 0; i < 12; i++) {
                    sliders.find(".Accept .range-slider").eq(i).find("input").val(_d.value[i]);
                    sliders.find(".End.cont2 .range-slider").eq(i).find("input").val(_c.value[i]);
                    sliders.find(".End.cont3 .range-slider").eq(i).find("input").val(_b.value[i]);
                    sliders.find(".End.cont4 .range-slider").eq(i).find("input").val(_a.value[i]);
                    if (_d.value[i] > MaxNum)
                        MaxNum = _d.value[i];
                    if (_c.value[i] > MaxNum)
                        MaxNum = _c.value[i];
                    if (_b.value[i] > MaxNum)
                        MaxNum = _d.value[i];
                    if (_a.value[i] > MaxNum)
                        MaxNum = _c.value[i];
                }
                sliders.find(".tickline .Ctock").remove();
                MaxNum = Getinteger(MaxNum,5);
                $("<div class='Ctock'><span>" + ((MaxNum / 5) * (5)).toFixed(0) + "</span></div>").insertBefore(sliders.find(".tickline .Period"));
                $("<div class='Ctock'><span>" + ((MaxNum / 5) * (4)).toFixed(0) + "</span></div>").insertBefore(sliders.find(".tickline .Period"));
                $("<div class='Ctock'><span>" + ((MaxNum / 5) * (3)).toFixed(0) + "</span></div>").insertBefore(sliders.find(".tickline .Period"));
                $("<div class='Ctock'><span>" + ((MaxNum / 5) * (2)).toFixed(0) + "</span></div>").insertBefore(sliders.find(".tickline .Period"));
                $(".chartContent5 .Period>span").text(((MaxNum / 5) * (1)).toFixed(0));


                app.inputs = [].slice.call(document.querySelectorAll('.chart_middle .panel_bottom .Accept input'));
                var inputs = app.inputs;
                var index = 1;
                var p = document.querySelector('.chart_middle .panel_bottom .Accept svg .line');
                inputs.forEach(function (input) {
                    return input.setAttribute('data-slider-index', 'range' + index++);
                });
                inputs.forEach(function (input) {
                     return app.updateSlider(input, MaxNum, p);
                });

                var p1 = document.querySelector('.chart_middle .panel_bottom .End.cont2 svg .line');
                app.inputs = [].slice.call(document.querySelectorAll('.chart_middle .panel_bottom .End.cont2 input'));
                inputs = app.inputs;
                index = 1;
                inputs.forEach(function (input) {
                    return input.setAttribute('data-slider-index', 'range' + index++);
                });
                inputs.forEach(function (input) {
                    return app.updateSlider(input, MaxNum, p1);
                });

                var p2 = document.querySelector('.chart_middle .panel_bottom .End.cont3 svg .line');
                app.inputs = [].slice.call(document.querySelectorAll('.chart_middle .panel_bottom .End.cont3 input'));
                inputs = app.inputs;
                index = 1;
                inputs.forEach(function (input) {
                    return input.setAttribute('data-slider-index', 'range' + index++);
                });
                inputs.forEach(function (input) {
                    return app.updateSlider(input, MaxNum, p2);
                });

                var p3 = document.querySelector('.End.cont4 svg .line');
                app.inputs = [].slice.call(document.querySelectorAll('.End.cont4 input'));
                inputs = app.inputs;
                index = 1;
                inputs.forEach(function (input) {
                    return input.setAttribute('data-slider-index', 'range' + index++);
                });
                inputs.forEach(function (input) {
                    return app.updateSlider(input, MaxNum, p3);
                });
            }
        }

        function Init6(data) {
            var chartContent6 = $(".chartContent6");
            chartContent6.find(".colpanel").remove();
            if (data) {
                chartContent6.find(">p.title").text(data.Title);
                var d = data.data;
                var MaxNum = d[0].wtime;
                for (var i = 1; i < d.length; i++) {
                    if (MaxNum < d[i].wtime)
                        MaxNum = d[i].wtime;
                }
                MaxNum = Getinteger(MaxNum,4);
                if (MaxNum > 15) {
                    MaxNum = (MaxNum*1).toFixed(0);
                    $(".chart_tick").find(">div").eq(0).find("span").text(MaxNum);
                    $(".chart_tick").find(">div").eq(1).find("span").text(((MaxNum / 5) * 4));
                    $(".chart_tick").find(">div").eq(2).find("span").text(((MaxNum / 5) * 3));
                    $(".chart_tick").find(">div").eq(3).find("span").text(((MaxNum / 5) * 2));
                    $(".chart_tick").find(">div").eq(4).find("span").text(((MaxNum / 5) * 1));
                     $(".chart_tick").find(">div").eq(5).find("span").text(((MaxNum / 5) * 0));
                } else
                    MaxNum = 15;
                var column = '<div class="column"><div class="Num"></div><div class="bar"></div> <div class="lable"></div></div>';
                for (var i = 0; i < d.length; i++) {
                    var _d = d[i];
                    var newItem = $('<div class="colpanel"></div>');
                    $(column).find(".Num").text(_d.wtime).end().find(".lable").text(_d.name).end().appendTo(newItem);
                    newItem.insertBefore(chartContent6.find(".chart_forbar .footer"));
                    newItem.find(".bar").animate({
                        "height": (150 * (_d.wtime / MaxNum))
                    });
                }
            }
        }

        Init1(options.chartdata1);
        Init2(options.chartdata2);
        Init3(options.chartdata3);
        Init4(options.chartdata4);
        Init5(options.chartdata5);
        Init6(options.chartdata6);
    }
})(jQuery, window, document)
