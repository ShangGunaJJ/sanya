(function ($, window, document) {

    $.fn.Lin_Rec = function (options) {
        options = $.extend({
            'WholeCity': { data: [{ name: "俱乐部", y: 401 }, { name: 'KTV', y: 96 }, { name: '下水运动', y: 8 }, { name: "休闲场所", y: 400 }], Title: "三亚市全市娱乐场所统计" },
            'AreaCal': {
                data: {
                    Arealist: ['海棠区', '天涯区', '崖州区', '吉阳区'], Caldata: [
                        { data: [6, 1, 1, 0] },//水下运动
                        { data: [1, 0, 1, 0] },//户外运动
                        { data: [28, 45, 12, 11] },//KTV
                        { data: [183, 174, 23, 21] },//俱乐部
                        { data: [198, 173, 32, 10] }//休闲场所
                    ]
                }, Title: "三亚市各区域娱乐场所统计"
            },
            'Arend': {
                x: [100, 120, 130, 150, 160, 180],//休闲
                k: [120, 160, 150, 200, 180, 200],//ktv
                j: [130, 180, 160, 220, 200, 230],//俱乐部
                h: [140, 200, 170, 240, 220, 270],//户外运动
                s: [150, 240, 290, 260, 250, 320],//水下运动
                labs: [2011, 2012, 2013, 2014, 2015, 2016]
                , Title: "全市娱乐场所发展趋势"
            }
        }, options);

        function svgMark(x, y, pieX, pieY, tipContent) {
            var circleX, circleY, gX, gY;
            var x1, x2;
            var y1, y2;
            //在圆心的右边
            if (x > pieX) {
                //在圆心的下面
                if (y > pieY) {
                    x1 = x + 13;
                    x2 = x1 + 90;
                    y1 = y + 20;
                    circleY = y2 = y1;
                    circleX = x2;
                    gX = x2 - 65;
                    gY = y2 - 5;
                } else {
                    x1 = x + 13;
                    x2 = x1 + 90;
                    y1 = y - 20;
                    circleY = y2 = y1;
                    circleX = x2;
                    gX = x2 - 75;
                    gY = y2 - 5;
                }

            } else {
                //在圆心的下面
                if (y > pieY) {
                    x1 = x - 24;
                    x2 = x1 - 70;
                    y1 = y + 20;
                    circleY = y2 = y1;
                    circleX = x2;
                    gX = x2 - 15;
                    gY = y2 - 5;
                } else {
                    x1 = x - 20;
                    x2 = x1 - 70;
                    y1 = y - 20;
                    circleY = y2 = y1;
                    circleX = x2;
                    gX = x2 - 15;
                    gY = y2 - 5;
                }
            }
            return '<svg class="tip">'
                        + '<polyline points="' + x + ',' + y + ' ' + x1 + ',' + y1 + ' ' + x2 + ',' + y2 + '" style="fill:transparent;stroke:#5a6bd7";stroke-width:1"></polyline>'//右上
                        + '<circle cx="' + circleX + '" cy="' + circleY + '" r="2" stroke="#70aefb" stroke-width="2" fill="#70aefb"/>'
                        + '<g transform="translate(' + gX + ',' + gY + ')">'
                          + '<text>'
                             + '<tspan x="30">' + (tipContent.name) + '</tspan>'
                             + '<tspan y="25" x="28">' + (tipContent.y) + '家</tspan>'
                          + '</text>'
                        + '</g>'
                   + '</svg>';

        };
        function chart() {
            $('#container').highcharts({
                chart: {
                    backgroundColor: "transparent",
                    plotBackgroundColor: null,
                    plotBorderWidth: null,
                    plotShadow: false,
                    marginTop: 130,
                    marginBottom: 170,
                    margin: 10
                },
                title: {
                    text: options.WholeCity.Title,
                    style: { color: "#029ea0", fontSize: "22px" },
                    y: 100
                },
                colors: ['#009e96', '#5fb29d', '#833488', '#21578b', '#9fa028'],
                tooltip: {
                    enabled: true,
                    useHTML: true,
                },
                legend: {
                    enabled: false,
                },
                credits: {
                    enabled: false
                },
                tooltip: {
                    pointFormat: '',
                    shared: true
                },
                plotOptions: {
                    pie: {
                        allowPointSelect: true,
                        cursor: 'pointer',
                        size: 240,
                        dataLabels: {
                            enabled: true,
                            connectorWidth: 1,
                            connectorColor: "transparent",
                            borderWidth: 5,
                            format: '<div><p></p><br><p></p></div>',
                            itemStyle: {
                                color: "#fff"
                            }
                        },
                        showInLegend: true
                    }
                },
                series: [{
                    type: 'pie',
                    data: options.WholeCity.data
                }]
            });

            $(".highcharts-axis-labels tspan").css({ "fill": "#fff", "font-size": "16" })
            $(".highcharts-axis-labels:last").css("display", "none");

            var pieS = $(".highcharts-series-group .highcharts-series:eq(0) path").attr("d");
            var pieXY = pieS.split(" ");
            var TipAll = $(".rec_main_left .highcharts-data-labels");
            var pieX = pieXY[pieXY.length - 3];
            var pieY = pieXY[pieXY.length - 2];
            var mTip = $(".rec_main_left .highcharts-data-labels path").length;
            if (mTip && mTip > 0) {
                for (var i = 0 ; i < mTip; i++) {
                    var TipStart = $(".rec_main_left .highcharts-data-labels path:eq(" + i + ")").attr("d")
                    var XY = TipStart.substring(TipStart.indexOf("L") + 2, TipStart.length).split(" ");
                    var x = XY[0];
                    var y = XY[1];
                    TipAll.prepend(svgMark(parseInt(x), parseInt(y), parseInt(pieX), parseInt(pieY), options.WholeCity.data[i]));
                }
            }
           
        }
        function chart2(){
            var colors=['#9fa028', '#833488', '#21578b', '#009e96', '#5fb29d'];
            
            var data=[];
            var dd=options.AreaCal.data.Caldata;
     var aa=options.AreaCal.data.Arealist;
            var  option = {
    tooltip : {
       show:false
    },
    legend: {
       show:false
    },
    grid: {
        left: '10.8%',
        right: '4%',
        bottom: '3%',
        containLabel: true
    },
    xAxis:  {
        type: 'value',
        show:false
    },
    yAxis: {
        type: 'category',
        axisLabel:{
           textStyle:{ color:"#fff",
                 fontSize:16,    
                     }
        },
        axisLine:{
          show:false
        },
        axisTick: {show:false},
        data: [aa[3],aa[2],aa[1],aa[0]]
    },
    series:[{ type: 'bar',
                       barMinHeight:35,
                       barWidth:38,
                       stack: '总量',
                       label: {
                         normal: {
                         show: true,
                               formatter: '{c}家',
                         position: "",
                       },
                     },
                    itemStyle:{
                           normal:{
                               color:colors[4],
                             
                           }
                       },
                   data:[dd[4].data[3],dd[4].data[2],dd[4].data[1],dd[4].data[0]]
                 },
           {
                       type: 'bar',
                       barMinHeight:35,
                       stack: '总量',
                       label: {
                         normal: {
                         show: true,
                         position: "", formatter: '{c}家',
                       },
                     },
                    itemStyle:{
                           normal:{
                               color:colors[3]
                           }
                       },
                   data:[dd[3].data[3],dd[3].data[2],dd[3].data[1],dd[3].data[0]]
                 },{
                       type: 'bar',
                       barMinHeight:30,
                       stack: '总量',
                       label: {
                         normal: {
                         show: true,
                         position: "", formatter: '{c}家',
                       },
                     },
                    itemStyle:{
                           normal:{
                               color:colors[2]
                           }
                       },
                   data:[dd[2].data[3],dd[2].data[2],dd[2].data[1],dd[2].data[0]]
                 },{
                       type: 'bar',
                       barMinHeight:30,
                       stack: '总量',
                       label: {
                         normal: {
                         show: true,
                         position: "", formatter: '{c}家',
                       },
                     },
                    itemStyle:{
                           normal:{
                               color:colors[1]
                           }
                       },
                   data:[dd[1].data[3],dd[1].data[2],dd[1].data[1],dd[1].data[0]]
                 },{
                       type: 'bar',
                       barMinHeight:30,
                       stack: '总量',
                       label: {
                         normal: {
                         show: true,
                         position: "", formatter: '{c}家',
                       },
                     },
                    itemStyle:{
                           normal:{
                               color:colors[0]
                           }
                       },
                   data:[dd[0].data[3],dd[0].data[2],dd[0].data[1],dd[0].data[0]]
                 }]
};
             var myChart = echarts.init(document.getElementById('container1'));
                myChart.setOption(option);
        }
        function chart1(data) {
            if (data) {
                var chartcontent = $(".chartcontent");
                chartcontent.find(".title").text(data.Title);
                var xdata = [];
                var ydata = [];
                var MaxNum = 0;
                var Maxx = 0, Maxk = 0, Maxj = 0; Maxh = 0; Maxs = 0;
                var lineColors = ['#9fa028', '#833488', '#21578b', '#009e96', '#5fb29d']
                for (var i = 0; i < data.labs.length; i++) {
                    xdata.push({
                        value: data.labs[i],
                        textStyle: {
                            color: "#fff"
                        }
                    });
                    if (Maxx < data.x[i]) {
                        Maxx = data.x[i]
                    }
                    if (Maxx < data.k[i]) {
                        Maxk = data.k[i]
                    }
                    if (Maxx < data.j[i]) {
                        Maxj = data.j[i]
                    }
                    if (Maxx < data.h[i]) {
                        Maxh = data.h[i]
                    }
                    if (Maxx < data.s[i]) {
                        Maxs = data.s[i]
                    }
                }

                ydata.push({
                    type: 'line',
                    data: data.x,
                    symbol: "circle",
                    max: 80,
                    symbolSize: 10,
                    lineStyle: {
                        normal: {
                            color: lineColors[0]
                        }
                    },
                    itemStyle: {
                        normal: {
                            color: lineColors[0]
                        }
                    }
                });
                ydata.push({
                    type: 'line',
                    data: data.k,
                    symbol: "circle",
                    max: 80,
                    symbolSize: 10,
                    lineStyle: {
                        normal: {
                            color: lineColors[1]
                        }
                    },
                    itemStyle: {
                        normal: {
                            color: lineColors[1]
                        }
                    }
                });
                ydata.push({
                    type: 'line',
                    data: data.j,
                    symbol: "circle",
                    max: 80,
                    symbolSize: 10,
                    lineStyle: {
                        normal: {
                            color: lineColors[2]
                        }
                    },
                    itemStyle: {
                        normal: {
                            color: lineColors[2]
                        }
                    }
                });
                ydata.push({
                    type: 'line',
                    data: data.h,
                    symbol: "circle",
                    max: 80,
                    symbolSize: 10,
                    lineStyle: {
                        normal: {
                            color: lineColors[3]
                        }
                    },
                    itemStyle: {
                        normal: {
                            color: lineColors[3]
                        }
                    }
                });
                ydata.push({
                    type: 'line',
                    data: data.s,
                    symbol: "circle",
                    max: 80,
                    symbolSize: 10,
                    lineStyle: {
                        normal: {
                            color: lineColors[4]
                        }
                    },
                    itemStyle: {
                        normal: {
                            color: lineColors[4]
                        }
                    }
                });
                if (MaxNum < Maxx) {
                    MaxNum = Maxx
                }
                if (MaxNum < Maxk) {
                    MaxNum = Maxk
                }
                if (MaxNum < Maxj) {
                    MaxNum = Maxj
                }
                if (MaxNum < Maxh) {
                    MaxNum = Maxh
                }
                if (MaxNum < Maxs) {
                    MaxNum = Maxs
                }
                MaxNum += 100;
                for (var f = 0; f < 8; f++) {
                    chartcontent.find(".chart_tick>div").eq(f).find("span").text(((MaxNum / 8) * (8 - f)).toFixed(0));
                }
                var option = {
                    title: {
                        show: false
                    },
                    tooltip: {
                        show: false,
                    },
                    legend: {
                        show: false
                    },
                    xAxis: {
                        type: 'category',
                        name: '',
                        boundaryGap: false,
                        offset: 6,
                        splitLine: {
                            show: true,
                            lineStyle: {
                                type: "dashed",
                                color: "rgba(0, 160, 233, 0.3)"
                            }
                        },
                        axisTick: {
                            show: false,
                            alignWithLabel: false
                        },
                        axisLine: {
                            show: false
                        },
                        data: xdata
                    },
                    grid: {
                        show: false,
                        top: 15,
                        width: 430,
                        left: "8.4%",
                        height: 310,
                        containLabel: true
                    },
                    yAxis: {
                        type: 'value',
                        splitNumber: 5,
                        max: MaxNum,
                        splitLine: {
                            lineStyle: {
                                type: "dashed",
                                color: "rgba(0, 160, 233, 0)"
                            }
                        },
                        axisLine: {
                            show: false
                        },
                        axisTick: {
                            show: false,
                            alignWithLabel: false
                        },
                        axisLabel: {
                            textStyle: {
                                color: "rgba(0, 160, 233, 0)"
                            }
                        }
                    },
                    series: ydata
                };
                var myChart = echarts.init(document.getElementById('Echart2'));
                myChart.setOption(option);
            }
        }
        chart1(options.Arend);
        chart2();
        chart();
    }
})(jQuery, window, document)