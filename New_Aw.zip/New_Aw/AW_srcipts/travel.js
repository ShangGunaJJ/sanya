function Getinteger(MaxNum, aver) {
    MaxNum = (MaxNum*1).toFixed(0);
    var gNum = Math.pow(10, MaxNum.toString().length - 2) * 2;
    var CNum = Math.pow(10, MaxNum.toString().length - 1);
    while (CNum < MaxNum)
        CNum += CNum;
    CNum -= CNum;
    while (CNum < MaxNum)
        CNum += gNum;
    var aNum = (CNum / aver).toFixed(0);
    if (CNum > 10) {
        if (CNum<999||aNum<100)
            while (aNum.toString().substring(aNum.toString().length - 1) != "0") {
                aNum = (aNum * 1) + 1;
            }
        else
            while (aNum.toString().substring(aNum.toString().length - 2) != "00") {
                aNum = (aNum * 1) + 1;
            }
    }
    return aNum * aver;
}

(function ($, window, document) {
    'use strict';
    $.fn.Travel_Arc = function (options) {
        var LA = $.fn.Travel_Arc;
        options = $.extend({
            'ssNum': { data: [{ name: "大小洞天", num: 7756 }, { name: "蜈支洲岛", num: 7216 }, { name: "千古情", num: 7216 }, { name: "热带雨林公园", num: 4322 }, { name: "西岛", num: 5765 }, { name: "爱立方", num: 3865 }], Title: '八大景区今日累计接待游客数量实时统计' },
            'bofNum': { data: [{ name: "崖州区", num: 6165 }, { name: "天涯区", num: 5216 }, { name: "吉阳区", num: 3756 }, { name: "海棠区", num: 7216 }], Title: '各行政区当前实时游客数量' },

            'ecNum': {
                data: [{ name: "大小洞天", num: 6000 },
                    { name: "蜈支洲岛", num: 7216 }, { name: "千古情", num: 7216 }, { name: "热带雨林公园", num: 4322 },
                    { name: "西岛", num: 5765 }, { name: "爱立方", num: 3865 }], Title: '八大景区当前国内游客实时数量'
            },
            'inland': { data: [ { name: "大小洞天", num: 6000 }, { name: "蜈支洲岛", num: 9000 }, { name: "千古情", num: 7216 }, { name: "热带雨林公园", num: 4322 }, { name: "西岛", num: 5765 }, { name: "爱立方", num: 3865 }], Title: '八大景区当前入境游客实时数量' },

            'allUserNum': { data: [{ name: "国内游客", A: 10000 }, { name: "入境游客", A: 500 }], Title: "全市当前游客实时数量" },
            'cyNum': { data: [{ name: "散客", A: 29997 }, { name: "团客", A: 22276 }], Title: "全市游客实时团散比" },
            'upDataTime': { time: "2016-10-12 10:25" }
        }, options);
        function Chart3(data) {
            if (data) {
                $(".allUserNum .title").text(data.Title)
                $(".allUserNum .tip .tip1").text(data.data[0].name)
                $(".allUserNum .tip .tip2").text(data.data[1].name)
                $(".allUserNum .round span:eq(1)").text(data.data[0].A + data.data[1].A);
                Chart7($("#chart7"), data.data);
            };
            $(".highcharts-data-labels g:eq(0) text").text(data.data[0].A);
            $(".highcharts-data-labels g:eq(1) text").text(data.data[1].A);

            $(".highcharts-label.highcharts-data-label").eq(0).attr("transform", "translate(74,132)")

        }
        function Chart4(data) {
            if (data) {
                $(".cyNum .title").text(data.Title)
                $(".cyNum .tip .tip1").text(data.data[0].name)
                $(".cyNum .tip .tip2").text(data.data[1].name)
                Chart8($("#chart8"), data.data);
            };

        }
        function Chart5(data) {
            if (data) {
                var SsNumD = data.data
                var ssNum_pro = $(".ssNum_pro");
                ssNum_pro.find(".title").text(data.Title);
                ssNum_pro.find(".minor").remove()
                var MaxNum = SsNumD.concat().sort(function (a, b) { return a.num < b.num; })[0].num;
                if (SsNumD.length > 0) {
                    ssNum_pro.find(".columns").html("");
                    for (var i = 0; i < SsNumD.length; i++) {
                        var column = '<div class="minor" style="left:' + (i * (580/SsNumD.length) + 30) + 'px;opacity:1">'
                                    + '<div class="Num">' + SsNumD[i].num + ' 人</div>'
                                   + '<div class="bar" ></div>'
                                   + '<span>' + SsNumD[i].name + '</span>'
                                + '</div>';

                        var newDo = $(column);
                        newDo.find(".bar").animate({ "height": 150 * (SsNumD[i].num / MaxNum) });
                        ssNum_pro.find(".columns").append($(newDo));
                    }
                }
            }
        }
        function Chart6(data) {
            if (data) {
                var bofNumD = data.data;
                var bofNum_pro = $(".bofNum_pro");
                bofNum_pro.find(".title").text(data.Title);
                bofNum_pro.find(".minor").remove()
                var MaxNum = bofNumD.concat().sort(function (a, b) { return a.num < b.num; })[0].num;
                if (bofNumD.length > 0) {
                    bofNum_pro.find(".columns").html("");
                    for (var i = 0; i < bofNumD.length; i++) {
                        var column = '<div class="minor" style="left:' + (i * 100 + 120) + 'px;opacity:1">'
                                    + '<div class="Num">' + bofNumD[i].num + ' 人</div>'
                                   + '<div class="bar"></div>'
                                   + '<span>' + bofNumD[i].name + '</span>'
                                + '</div>';
                        var newDo = $(column);
                        newDo.find(".bar").animate({ "height": 150 * (bofNumD[i].num / MaxNum) });
                        bofNum_pro.find(".columns").append(newDo);

                    }
                }
            }

        }
        function Chart2(data) {
            if (data) {
                var ecNumD = data.data
                var ecNum_pro = $(".ecNum_pro");
                ecNum_pro.find(".title").text(data.Title);
                var MaxNu = 0;
                for (var i = 0; i < ecNumD.length; i++) {
                    if (MaxNu < (ecNumD[i].num * 1))
                        MaxNu = (ecNumD[i].num * 1);
                }
                MaxNu = Getinteger(MaxNu,9);
                for (var f = 0; f < 10; f++) {
                    $(".tickline").eq(1).find(">div").eq(f).find("span").text(((MaxNu / 9) * (9 - f)).toFixed(0));
                }

                if (ecNumD.length > 0) {
                    ecNum_pro.find(".columns").html("");
                    for (var i = 0; i < ecNumD.length; i++) {
                        var column = '<div class="minor" style="left:' + (i * (610 / ecNumD.length) + 30) + 'px">'
                                    + '<div class="Num">' + ecNumD[i].num + ' 人</div>'
                                   + '<div class="bar" style="background:#3769bc"></div>'
                                   + '<span>' + ecNumD[i].name + '</span>'
                                + '</div>';
                        column = $(column);
                        ecNum_pro.find(".columns").append(column);
                        column.find(".bar").animate({ "height": 170 * (ecNumD[i].num / MaxNu) });

                    }
                   
                }
            }

        }
        function Chart1(data) {
            if (data) {
                var inlandD = data.data
                var inland_pro = $(".inland_pro");
                inland_pro.find(".title").text(data.Title);
                var MaxNu = 0;
                for (var i = 0; i < inlandD.length; i++) {
                    if (MaxNu < (inlandD[i].num * 1))
                        MaxNu = (inlandD[i].num * 1);
                }
                MaxNu = Getinteger(MaxNu,9);
                for (var f = 0; f < 10; f++) {
                    $(".proportion .tickline>div").eq(f).find("span").text(((MaxNu / 9) * (9 - f)).toFixed(0));
                }

                if (inlandD.length > 0) {
                    inland_pro.find(".columns").html("");
                    for (var i = 0; i < inlandD.length; i++) {
                        var column = '<div class="minor" style="left:' + (i * (600 / inlandD.length) + 35) + 'px">'
                                    + '<div class="Num">' + inlandD[i].num + ' 人</div>'
                                   + '<div class="bar"></div>'
                                   + '<span>' + inlandD[i].name + '</span>'
                                + '</div>';
                        column=$(column)
                        inland_pro.find(".columns").append(column);
                        column.find(".bar").animate({ "height": 170 * (inlandD[i].num / MaxNu) });
                    }
                  
                }

            }

        }

        function updataTime(tiem) {
            $(".updateTime .time").stop().slideUp(function () {
                $(".updateTime .time").text(tiem.time).stop().slideDown();
            });

        };
        Chart5(options.ssNum);
        Chart6(options.bofNum);
        Chart1(options.inland);
        Chart2(options.ecNum);
        Chart3(options.allUserNum);
        Chart4(options.cyNum);
        updataTime(options.upDataTime);
        return {
            loadChart5: Chart5,
            loadChart6: Chart6,
            loadChart1: Chart1,
            loadChart2: Chart2,
            loadChart3: Chart3,
            loadChart4: Chart4,
            updataTime: updataTime,
        }


    }
})(jQuery, window, document)

function Chart7(elem, d) {
    $(elem).highcharts({
        chart: {
            backgroundColor: "transparent",
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            borderColor: "#ccc"
        },
        title: {
            text: ''
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                borderColor: 'transparent',
                dataLabels: {
                    distance:-30,
                    padding: 0,
                    connectorPadding: 60,
                    x:-20,
                    format: '',
                    style: {
                        fontSize: '12px',
                        color: '#d2d2d2',
                        fill: '#d2d2d2'
                    }
                },
                minSize: 800,
                point: {
                  
                    events: {
                        legendItemClick: function () {
                            return false;
                        }
                    }
                },
            }
        },
        credits: {
            enabled: false
        },
        series: [{
            type: 'pie',
            name: 'Browser share',
            innerSize: '45%',
          
            data: [
               {
                   name: '', y: d[0].A, color: '#22ac38', sliced: false,
                   selected: false
               },
               {
                   name: '', y: d[1].A, color: '#0772a2', sliced: false,
                   selected: false
               }
            ]
        }]
    });
}
function Chart8(elem, d) {
    $(elem).highcharts({
        chart: {
            backgroundColor: "transparent",
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            borderColor: "#ccc"
        },
        title: {
            text: ''
        },
        tooltip: {
            enabled: false
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    distance: -24,

                    style: {
                        fontSize: '12px',
                    }
                },
            }
        },
        credits: {
            enabled: false
        },
        series: [{
            type: 'pie',
            name: 'Browser share',
            innerSize: '45%',
            data: [
                {
                    name: parseInt((d[0].A / (d[0].A + d[1].A)) * 100) + "%", y: d[0].A, color: '#22ac38', sliced: false,
                    selected: false
                },
               {
                   name: parseInt((d[1].A / (d[0].A + d[1].A)) * 100) + "%", y: d[1].A, color: '#564b94', sliced: false,
                   selected: false
               }
            ]
        }]
    })
};