'use strict';
if (!String.prototype.format) {
    String.prototype.format = function () {
        var args = arguments;
        return this.replace(/{(\d+)}/g, function (match, number) {
            return typeof args[number] != 'undefined' ? args[number] : match;
        });
    };
}
var app = function () {
    var $svgLine = document.querySelector('.chartContent6 svg .line');
    var sliderThumbSize = 0;
    var sliderHeight = 200;
    var svgViewBoxHeight = 100;
    var svgViewBoxThumbLimit = sliderThumbSize / 2 * (svgViewBoxHeight / sliderHeight);
    var svgViewBoxGraphMax = svgViewBoxHeight - svgViewBoxThumbLimit;
    var svgViewBoxGraphMin = svgViewBoxThumbLimit;
    var ranges = {
        range1: null,
        range2: null,
        range3: null,
        range4: null,
        range5: null,
        range6: null,
        range7: null,
        range8: null,
        range9: null,
        range10: null,
        range11: null,
        range12: null
    };
    var points = {
        begin: {
            x: 5,
            y: 0
        },
        point1: {
            x: 5,
            y: 0
        },
        control1: {
            x: 5,
            y: 0
        },
        control2: {
            x: 16.5,
            y: 0
        },
        point2: {
            x: 16.5,
            y: 0
        },
        control3: {
            x: 28,
            y: 0
        },
        point3: {
            x: 28,
            y: 0
        },
        control4: {
            x: 39.5,
            y: 0
        },
        point4: {
            x: 39.5,
            y: 0
        },
        control5: {
            x: 51.5,
            y: 0
        },
        point5: {
            x: 51.5,
            y: 0
        },
        control6: {
            x: 63.5,
            y: 0
        },
        point6: {
            x: 63.5,
            y: 0
        },
        control7: {
            x: 75.5,
            y: 0
        },
        point7: {
            x: 75.5,
            y: 0
        },
        control8: {
            x: 87.5,
            y: 0
        },
        point8: {
            x: 87.5,
            y: 0
        },
        control9: {
            x: 99.1,
            y: 0
        },
        point9: {
            x: 99.1,
            y: 0
        },
        control10: {
            x: 111.1,
            y: 0
        },
        point10: {
            x: 111.1,
            y: 0
        },
        control11: {
            x: 122.5,
            y: 0
        },
        point11: {
            x: 122.5,
            y: 0
        },
        control12: {
            x: 133,
            y: 0
        },
        point12: {
            x: 133,
            y: 0
        }

    };
    function mapDataRange(value) {
        return (value - 0) * (svgViewBoxGraphMax - svgViewBoxGraphMin) / (svgViewBoxHeight - 0) + svgViewBoxGraphMin;
    }
    function updateSlider($element, keyS, line, count) {
        $svgLine = line;
        if ($element) {
            var rangeIndex = $element.getAttribute('data-slider-index'), range = ranges[rangeIndex], value = $element.value;
            ranges[rangeIndex] = value;
            var parent = $element.parentElement, $thumb = parent.querySelector('.range-slider__thumb'), $bar = parent.querySelector('.range-slider__bar'),
            pct = (value / keyS) * 100;
            $thumb.style.bottom = pct + '%';
            $bar.style.height = 'calc(' + pct + '% + ' + sliderThumbSize / 2 + 'px)';
            renderSliderGraph(keyS, count);
        }
    }
    function updatePoints(key) {
        points.point1.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range1 / key | 0;
        points.point2.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range2 / key | 0;
        points.point3.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range3 / key | 0;
        points.point4.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range4 / key | 0;
        points.point5.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range5 / key | 0;
        points.point6.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range6 / key | 0;
        points.point7.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range7 / key | 0;


        points.point8.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range8 / key | 0;
        points.point9.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range9 / key | 0;
        points.point10.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range10 / key | 0;
        points.point11.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range11 / key | 0;
        points.point12.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range12 / key | 0;

        var max = svgViewBoxGraphMax;
        var min = svgViewBoxGraphMin;
        points.point1.y = mapDataRange(points.point1.y);
        points.point2.y = mapDataRange(points.point2.y);
        points.point3.y = mapDataRange(points.point3.y);
        points.point4.y = mapDataRange(points.point4.y);
        points.point5.y = mapDataRange(points.point5.y);
        points.point6.y = mapDataRange(points.point6.y);
        points.point7.y = mapDataRange(points.point7.y);

        points.point8.y = mapDataRange(points.point8.y);
        points.point9.y = mapDataRange(points.point9.y);
        points.point10.y = mapDataRange(points.point10.y);
        points.point11.y = mapDataRange(points.point11.y);
        points.point12.y = mapDataRange(points.point12.y);

        points.begin.y = points.point1.y;
        points.control1.y = points.point1.y;
        points.control2.y = points.point2.y;
        points.control3.y = points.point3.y;
        points.control4.y = points.point4.y;
        points.control5.y = points.point5.y;
        points.control6.y = points.point6.y;
        points.control7.y = points.point7.y;

        points.control8.y = points.point8.y;
        points.control9.y = points.point9.y;
        points.control10.y = points.point10.y;
        points.control11.y = points.point11.y;
        points.control12.y = points.point12.y;
    }
    function getInterpolatedLine(index) {
        if (index == undefined)
            index = 12;
        var p = "M {0},{1}"
        for (var i = 1; i <= index; i++) {
            p += `L{${(i - 1) * 4 + 2}},{${(i - 1) * 4 + 3}}`;
        }
        return p
        .format(points.begin.x,
                points.begin.y,
        points.point1.x,
                points.point1.y,
                points.control1.x,
                points.control1.y,
        points.control2.x,
                points.control2.y,
                points.point2.x,
                points.point2.y,
        points.control3.x,
                points.control3.y,
                points.point3.x,
                points.point3.y,
        points.control4.x,
                points.control4.y,
                points.point4.x,
                points.point4.y,
        points.control5.x,
                points.control5.y,
                points.point5.x,
                points.point5.y,
        points.control6.x,
                points.control6.y,
                points.point6.x,
                points.point6.y,
        points.control7.x, points.control7.y, points.point7.x, points.point7.y,
        points.control8.x, points.control8.y, points.point8.x, points.point8.y,
               points.control9.x, points.control9.y, points.point9.x, points.point9.y,
               points.control10.x, points.control10.y, points.point10.x, points.point10.y,
               points.control11.x, points.control11.y, points.point11.x, points.point11.y,
               points.control12.x, points.control12.y, points.point12.x, points.point12.y);
    }
    function reset() {
        var inputs = app.inputs;
        inputs.forEach(function (input) {
            return app.updateSlider(input);
        });
    }
    function renderSliderGraph(k,c) {
        updatePoints(k);
        $svgLine.setAttribute('d', getInterpolatedLine(c));
    }
    function selectPreset(key, el) {
        var inputs = app.inputs;
        $svgLine = el;
        inputs.forEach(function (input) {
            return app.updateSlider(input, key);
        });
    }
    return {
        inputs: [].slice.call(document.querySelectorAll('.sliders input')),
        updateSlider: updateSlider,
        reset: reset,
        selectPreset: selectPreset,
        $svgLine: null,

    };
}();

function Getinteger(MaxNum, aver) {
    MaxNum = (MaxNum * 1).toFixed(0);
    var gNum = Math.pow(10, MaxNum.toString().length - 2) * 2;
    var CNum = Math.pow(10, MaxNum.toString().length - 1);
    while (CNum < MaxNum)
        CNum += CNum;
    CNum -= CNum;
    while (CNum < MaxNum)
        CNum += gNum;
    var aNum = (CNum / aver).toFixed(0);
    if (CNum > 10)
        while (aNum.toString().substring(aNum.toString().length - 1) != "0") {
            aNum = (aNum * 1) + 1;
        }
    return aNum * aver;
}

(function ($, window, document) {
    'use strict';
    $.fn.You_Arc = function (options) {
        var LA = $.fn.You_Arc;
        options = $.extend({
            // 左上左内容
            'TouristsNum1': { data: [{ year1: 37.28, year2: 39.55 }, { year1: 38.00, year2: 40.22 }, { year1: 38, year2: 50 }, { year1: 41, year2: 172.1 }, { year1: 112, year2: 180 }, { year1: 120, year2: 200 }, { year1: 179, year2: 250 }, { year1: 184, year2: 243 }, { year1: 118, year2: 229 }, { year1: 60, year2: 200 }, { year1: 50, year2: 175 }, { year1: 47, year2: 150 }], YearS: { year1: "2015", len1: 11, year2: "2016", len2: 11 }, Title: '2015/2016年国内游客月度数量对比' },
            // 左下左内容
            'TouristsNum2': { data: [{ year1: 37.28, year2: 39.55 }, { year1: 38.00, year2: 40.22 }, { year1: 38, year2: 50 }, { year1: 41, year2: 172.1 }, { year1: 112, year2: 180 }, { year1: 120, year2: 200 }, { year1: 179, year2: 250 }, { year1: 184, year2: 243 }, { year1: 118, year2: 229 }, { year1: 60, year2: 200 }, { year1: 50, year2: 175 }, { year1: 47, year2: 150 }], YearS: { year1: "2015", year2: "2016" }, Title: '2015/2016年入境游客月度数量对比' },
            // 左下右内容
            'foreign': { data: [{ year1: 10, year2: 20, month: "10月" }, { year1: 12, year2: 21, month: "11月" }, { year1: 15, year2: 29, month: "12月" }, { year1: 16, year2: 21, month: "2016年" }, { year1: 22, year2: 40, month: "2月" }, { year1: 30, year2: 43, month: "3月" }, { year1: 35, year2: 51, month: "4月" }, { year1: 47, year2: 68, month: "5月" }, { year1: 49, year2: 62, month: "6月" }, { year1: 32, year2: 58, month: "7月" }, { year1: 27, year2: 51, month: "8月" }, { year1: 21, year2: 42, month: "9月" }], YearS: { year1: "2015", year2: "2016" }, Title: '最近12个月客流量变换趋势' },
            //左上右内容
            'AreaTranSTA': { data: [{ name: "2014年", nums: ["2190", "4.16"] }, { name: "2015年", nums: ["2121", "4.35"] }, { name: "2016年", nums: ["2290", "4.58"] }], Title: '最近三年春节黄金周人均停留及消费情况' },
            // 右一内容
            'FlightData': { Data: [{ year: "接待人数", offland: 241.05, SPLY: 221.87, throughput: 7.12 }, { year: "去年同期", offland: 241.05, SPLY: 21.87, throughput: 7.12 }, { year: "去年同期", offland: 241.05, SPLY: 221.87, throughput: 7.12 }, { year: "去年同期", offland: 241.05, SPLY: 221.87, throughput: 7.12 }, { year: "去年同期", offland: 241.05, SPLY: 221.87, throughput: 7.12 }, { year: "去年同期", offland: 241.05, SPLY: 221.87, throughput: 7.12 }, { year: "去年同期", offland: 241.05, SPLY: 221.87, throughput: 7.12 }, { year: "去年同期", offland: 241.05, SPLY: 221.87, throughput: 7.12 }, ], Title: '2015/2016 8大景区接待游客数量（1-9月累计）' },
            // 右中内容
            'FlightData2': { Data: [{ year: 2014, offland: 241.05, SPLY: 221.87, throughput: 7.12 }, { year: 2015, offland: 241.05, SPLY: 221.87, throughput: 7.12 }], Title: '2014/2015 三亚旅游收入情况' },
            // 右下内容
            'FlightData3': { Data: [{ year: 2015, offland: 241.05, SPLY: 221.87, throughput: 8.12 }, { year: 2016, offland: 241.05, SPLY: 221.87, throughput: 7.12 }, { year: 2015, offland: 106869, throughput: 8.19 }], Title: '2015/2016 春节黄金周旅游收入情况' }
            , 'upDataTime': { time: "2016-10-12 10:25" }
        }, options);

        function initAndSetupTheSliders() {
            $("input").val(0);
            // --------------------// 左上左内容------------------------
            if (options.TouristsNum1) {
                var sliders = $(".checkIn1");
                $(sliders).find(".title").text(options.TouristsNum1.Title);
                $(sliders).find(".lableee").find("div").eq(0).text(options.TouristsNum1.YearS.year1);
                $(sliders).find(".lableee").find("div").eq(1).text(options.TouristsNum1.YearS.year2);
                var d = options.TouristsNum1.data;
                var data = options.TouristsNum1;
                var MaxNum = 0;
                for (var i = 0; i < d.length; i++) {
                    var _d = d[i];
                    sliders.find(".Accept .range-slider").eq(i).find("input").val(_d.year1);
                    sliders.find(".End .range-slider").eq(i).find("input").val(_d.year2);
                    if (MaxNum < _d.year1)
                        MaxNum = _d.year1;
                    if (MaxNum < _d.year2)
                        MaxNum = _d.year2;

                }
                MaxNum = Getinteger(MaxNum, 7);
                for (var f = 0; f < 9; f++) {
                    sliders.find(".tickline>div").eq(f).find("span").text(((MaxNum / 7) * (7 - f)).toFixed(0));
                }


                app.inputs = [].slice.call(document.querySelectorAll('.checkIn1 .Accept input'));
                var inputs = app.inputs;
                var index = 1;
                var p = document.querySelector('.checkIn1 .Accept svg .line');
                $(".checkIn1 .range-slider").css("opacity", 1);
                if (data.YearS.len1)
                    $(".checkIn1 .Accept .range-slider:gt(" + (data.YearS.len1 - 1) + ")").css("opacity", 0);
                if (data.YearS.len2)
                    $(".checkIn1 .End .range-slider:gt(" + (data.YearS.len2 - 1) + ")").css("opacity", 0);

                inputs.forEach(function (input) {
                    return input.setAttribute('data-slider-index', 'range' + index++);
                });
                inputs.forEach(function (input) {
                    return app.updateSlider(input, MaxNum, p, (data.YearS.len1 ? data.YearS.len1 : 12));
                });

                p = document.querySelector('.checkIn1 .End svg .line');
                app.inputs = [].slice.call(document.querySelectorAll('.checkIn1 .End input'));
                inputs = app.inputs;
                index = 1;
                inputs.forEach(function (input) {
                    return input.setAttribute('data-slider-index', 'range' + index++);
                });
                inputs.forEach(function (input) {
                    return app.updateSlider(input, MaxNum, p, (data.YearS.len2 ? data.YearS.len2 : 12));
                });
            }
            //------------------------------- 左下右内容-----------------------------------
            if (options.foreign) {
                var sliders = $(".checkIn");
                $(sliders).find(".title").text(options.foreign.Title);
                $(sliders).find(".lableee").find("div").eq(0).text(options.foreign.YearS.year1);
                $(sliders).find(".lableee").find("div").eq(1).text(options.foreign.YearS.year2);
                var MaxNum = 0;
                var d = options.foreign.data;
                var data = options.foreign;
                for (var i = 0; i < d.length; i++) {
                    var _d = d[i];
                    sliders.find(".Accept .range-slider").eq(i).find("input").val(_d.year1);
                    sliders.find(".End .range-slider").eq(i).find("input").val(_d.year2);
                    sliders.find(".range-slider_lab").eq(i).text(_d.month);
                    if (MaxNum < d[i].year1)
                        MaxNum = d[i].year1;
                    if (MaxNum < d[i].year2)
                        MaxNum = d[i].year2;
                }
                MaxNum = Getinteger(MaxNum, 7);
                for (var f = 0; f < 9; f++) {
                    sliders.find(".tickline>div").eq(f).find("span").text(((MaxNum / 7) * (7 - f)).toFixed(0));
                }
                app.inputs = [].slice.call(document.querySelectorAll('.checkIn .Accept input'));

                $(".checkIn .range-slider").css("opacity", 1);
                if (data.YearS.len1)
                    $(".checkIn .Accept .range-slider:gt(" + (data.YearS.len1 - 1) + ")").css("opacity", 0);
                if (data.YearS.len2)
                    $(".checkIn .End .range-slider:gt(" + (data.YearS.len2 - 1) + ")").css("opacity", 0);

                var inputs = app.inputs;
                var index = 1;
                var p = document.querySelector('.checkIn .Accept svg .line');
                inputs.forEach(function (input) {
                    return input.setAttribute('data-slider-index', 'range' + index++);
                });
                inputs.forEach(function (input) {
                     return app.updateSlider(input, MaxNum, p, (data.YearS.len1 ? data.YearS.len1 : 12));
                });

                p = document.querySelector('.checkIn .End svg .line');
                app.inputs = [].slice.call(document.querySelectorAll('.checkIn .End input'));
                inputs = app.inputs;
                index = 1;
                inputs.forEach(function (input) {
                    return input.setAttribute('data-slider-index', 'range' + index++);
                });
                inputs.forEach(function (input) {
                     return app.updateSlider(input, MaxNum, p, (data.YearS.len2 ? data.YearS.len2 : 12));
                });
            }

            // --------------------// 左下左内容------------------------
            if (options.TouristsNum2) {
                var sliders = $(".checkIn2");
                var sliders = $(".checkIn2");
                $(sliders).find(".title").text(options.TouristsNum2.Title);
                $(sliders).find(".lableee").find("div").eq(0).text(options.TouristsNum2.YearS.year1);
                $(sliders).find(".lableee").find("div").eq(1).text(options.TouristsNum2.YearS.year2);
                var d = options.TouristsNum2.data;
                var data = options.TouristsNum2;
                var MaxNum = 0;
                for (var i = 0; i < d.length; i++) {
                    var _d = d[i];
                    sliders.find(".Accept .range-slider").eq(i).find("input").val(_d.year1);
                    sliders.find(".End .range-slider").eq(i).find("input").val(_d.year2);
                    if (MaxNum < d[i].year1)
                        MaxNum = d[i].year1;
                    if (MaxNum < d[i].year2)
                        MaxNum = d[i].year2;
                }
                MaxNum = Getinteger(MaxNum, 7);
                for (var f = 0; f < 9; f++) {
                    sliders.find(".tickline>div").eq(f).find("span").text(((MaxNum / 7) * (7 - f)).toFixed(0));
                }

                app.inputs = [].slice.call(document.querySelectorAll('.checkIn2 .Accept input'));
                app.inputs = [].slice.call(document.querySelectorAll('.checkIn2 .Accept input'));
                var inputs = app.inputs;
                var index = 1;

                $(".checkIn2 .range-slider").css("opacity", 1);
                if (data.YearS.len1)
                    $(".checkIn2 .Accept .range-slider:gt(" + (data.YearS.len1 - 1) + ")").css("opacity", 0);
                if (data.YearS.len2)
                    $(".checkIn2 .End .range-slider:gt(" + (data.YearS.len2 - 1) + ")").css("opacity", 0);
                var p = document.querySelector('.checkIn2 .Accept svg .line');
                var p = document.querySelector('.checkIn2 .Accept svg .line');
                inputs.forEach(function (input) {
                    return input.setAttribute('data-slider-index', 'range' + index++);
                });
                inputs.forEach(function (input) {
                     return app.updateSlider(input, MaxNum, p, (data.YearS.len1 ? data.YearS.len1 : 12));
                });

                p = document.querySelector('.checkIn2 .End svg .line');
                p = document.querySelector('.checkIn2 .End svg .line');
                app.inputs = [].slice.call(document.querySelectorAll('.checkIn2 .End input'));
                app.inputs = [].slice.call(document.querySelectorAll('.checkIn2 .End input'));
                inputs = app.inputs;
                index = 1;
                inputs.forEach(function (input) {
                    return input.setAttribute('data-slider-index', 'range' + index++);
                });
                inputs.forEach(function (input) {
                     return app.updateSlider(input, MaxNum, p, (data.YearS.len2 ? data.YearS.len2 : 12));
                });
            }
        }
        function initconsume() {
            //----------------------//左上右内容-----------------------
            var chartContent2 = $(".chartContent2");
            chartContent2.find(".colpanel").remove();
            chartContent2.find(".footer>span").remove();
            if (options.AreaTranSTA && options.AreaTranSTA.data) {
                chartContent2.find(">p.title").text(options.AreaTranSTA.Title);
                var d = options.AreaTranSTA.data;
                var MaxNum1 = d[0].nums[0];
                var MaxNum2 = d[0].nums[1];
                for (var i = 1; i < d.length; i++) {
                    if (MaxNum1 < d[i].nums[0])
                        MaxNum1 = d[i].nums[0];
                    if (MaxNum2 < d[i].nums[1])
                        MaxNum2 = d[i].nums[1];
                }
                var column = '<div class="column"><div class="Num"></div><div class="bar"></div></div>';
                for (var i = 0; i < d.length; i++) {
                    var _d = d[i];
                    var newItem = $('<div class="colpanel"></div>');
                    newItem.insertBefore(chartContent2.find(".chart_forbar .footer"));
                    var creatFnC = function (num, type) {
                        if (type == 1)
                            var co = $(column).find(".Num").text(num + '元').end();
                        else
                            var co = $(column).find(".Num").text(num + '天').end();
                        return co;
                    }
                    var Wi = 0;
                    var cc = creatFnC(_d.nums[0], 1).appendTo(newItem);
                    Wi = 90 * (_d.nums[0] / MaxNum1);
                    cc.find(".bar").animate({ "height": Wi });
                    var cc1 = creatFnC(_d.nums[1], 2).appendTo(newItem);
                    Wi = 55 * (_d.nums[1] / MaxNum2);
                    cc1.find(".bar").animate({ "height": Wi });

                    $("<span>" + _d.name + "</span>").appendTo(chartContent2.find(".footer"));
                }
            }
        }

        // ------------------- 右一内容--------------------

        function FlightInit() {
            var figthElem = $(".reception");
            if (options.FlightData && options.FlightData.Data) {
                figthElem.find(".title").text(options.FlightData.Title);

                var thCon = (((options.FlightData.Data[1].throughput - options.FlightData.Data[0].throughput) / options.FlightData.Data[0].throughput) * 100).toFixed(1);
                figthElem.find(".row").hide();
                for (var i = 0; i < options.FlightData.Data.length; i++) {
                    figthElem.find(".row").eq(i).stop().slideDown().find(".td_name").text(options.FlightData.Data[i].year).end().find(".contrast_year_1").text(options.FlightData.Data[i].offland).end().find(".contrast_year_2").text(options.FlightData.Data[i].SPLY).end().find(".contrast_td").text(options.FlightData.Data[i].throughput + "%").end();
                    if (options.FlightData.Data[i].throughput.toString().indexOf("-") > -1)
                        figthElem.find(".row").eq(i).css("color", "#01b5b5");
                    else
                        figthElem.find(".row").eq(i).css("color", "red");
                }
            }

            // ------------------- 右二内容--------------------

            var figthElem = $(".income");
            if (options.FlightData2 && options.FlightData2.Data) {
                figthElem.find(".title").text(options.FlightData2.Title);

                var thCon = (((options.FlightData2.Data[1].throughput - options.FlightData2.Data[0].throughput) / options.FlightData2.Data[0].throughput) * 100).toFixed(1); figthElem.find(".Tab_title").find(".contrast_year_1").text(options.FlightData2.Data[0].year).end().find(".contrast_year_2").text(options.FlightData2.Data[1].year);
                for (var i = 0; i < options.FlightData2.Data.length; i++) {
                    figthElem.find(".row").eq(i).find(".contrast_year_1").text(options.FlightData2.Data[i].offland).end().find(".contrast_year_2").text(options.FlightData2.Data[i].SPLY).end().find(".contrast_td").text((options.FlightData2.Data[i].throughput > 0 ? "+" : "") + options.FlightData2.Data[i].throughput + "%");
                }
            }

            // ------------------- 右三内容--------------------
            var figthElem = $(".SF-income");
            if (options.FlightData3 && options.FlightData3.Data) {
                figthElem.find(".title").text(options.FlightData3.Title);

                var thCon = (((options.FlightData3.Data[1].throughput - options.FlightData3.Data[0].throughput) / options.FlightData3.Data[0].throughput) * 100).toFixed(1); figthElem.find(".Tab_title").find(".contrast_year_1").text(options.FlightData3.Data[0].year).end().find(".contrast_year_2").text(options.FlightData3.Data[1].year);
                for (var i = 0; i < options.FlightData3.Data.length; i++) {
                    figthElem.find(".row").eq(i).find(".contrast_year_1").text(options.FlightData3.Data[i].offland).end().find(".contrast_year_2").text(options.FlightData3.Data[i].SPLY).end().find(".contrast_td").text((options.FlightData3.Data[i].throughput > 0 ? "+" : "") + options.FlightData3.Data[i].throughput + "%");
                }
            }
        }
        initAndSetupTheSliders();
        initconsume();
        FlightInit();

        function Updata(time) {
            $(".updateTime").stop().slideUp(function () {
                $(".updateTime").text(time).stop().slideDown();
            });
        }
        Updata(options.upDataTime.time);
    }
})(jQuery, window, document)