'use strict';
if (!String.prototype.format) {
    String.prototype.format = function () {
        var args = arguments;
        return this.replace(/{(\d+)}/g, function (match, number) {
            return typeof args[number] != 'undefined' ? args[number] : match;
        });
    };
}
var app = function () {
    var $svgLine = document.querySelector('svg .line');
    var $svgLineShadow = document.querySelector('svg .line-shadow');
    var sliderThumbSize = 0;
    var sliderHeight = 180;
    var svgViewBoxHeight = 100;
    var svgViewBoxThumbLimit = sliderThumbSize / 2 * (svgViewBoxHeight / sliderHeight);
    var svgViewBoxGraphMax = svgViewBoxHeight - svgViewBoxThumbLimit;
    var svgViewBoxGraphMin = svgViewBoxThumbLimit;
    var ranges = {
        range1: null,
        range2: null,
        range3: null
    };
    var points = {
        begin: {
            x: 5,
            y: 0
        },
        point1: {
            x: 5,
            y: 0
        },
        control1: {
            x: 10,
            y: 10
        },
        control2: {
            x: 10,
            y: 0
        },
        point2: {
            x: 16,
            y: 0
        },
        control3: {
            x: 22,
            y: 0
        },
        point3: {
            x: 28,
            y: 0
        },
    };

    function mapDataRange(value) {
        return (value - 0) * (svgViewBoxGraphMax - svgViewBoxGraphMin) / (svgViewBoxHeight - 0) + svgViewBoxGraphMin;
    }

    function updateSlider($element) {
        if ($element) {
            var rangeIndex = $element.getAttribute('data-slider-index'),
                range = ranges[rangeIndex],
                value = $element.value;
            if (range === value) {
                return;
            }
            ranges[rangeIndex] = value;
            var parent = $element.parentElement,
                $thumb = parent.querySelector('.range-slider__thumb'),
                $bar = parent.querySelector('.range-slider__bar'),
                pct = (value / 15.4);
            $thumb.style.bottom = pct + '%';
            $bar.style.height = 'calc(' + pct + '% + ' + sliderThumbSize / 2 + 'px)';
            renderSliderGraph();
        }
    }

    function updatePoints() {
        points.point1.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range1 / 1540 | 0;
        points.point2.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range2 / 1540 | 0;
        points.point3.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range3 / 1540 | 0;

        var max = svgViewBoxGraphMax;
        var min = svgViewBoxGraphMin;
        points.point1.y = mapDataRange(points.point1.y);
        points.point2.y = mapDataRange(points.point2.y);
        points.point3.y = mapDataRange(points.point3.y);
    }

    function getInterpolatedLine(type) {
        return 'M {0},{1} L {2},{3} C {4},{5} {6},{7} {8},{9} S {10} {11}'
            .format(points.begin.x, points.begin.y,
                points.point1.x, points.point1.y, points.control1.x, points.control1.y,
                points.control2.x, points.control2.y, points.point2.x, points.point2.y,
                points.control3.x, points.control3.y);
    }

    function reset() {
        var inputs = app.inputs;
        inputs.forEach(function (input) {
            return app.updateSlider(input);
        });
    }

    function renderSliderGraph(c) {
        updatePoints();
        $svgLine.setAttribute('d', getInterpolatedLine(c));
        //$svgLineShadow.setAttribute('d', getInterpolatedLine('shadow'));
    }

    function selectPreset(type) {
        var inputs = app.inputs;
        inputs.forEach(function (input) {
            return app.updateSlider(input);
        });
    }
    return {
        inputs: [].slice.call(document.querySelectorAll('.sliders input')),
        updateSlider: updateSlider,
        reset: reset,
        selectPreset: selectPreset
    };
}();

function Getinteger(MaxNum, aver) {
    MaxNum = (MaxNum * 1).toFixed(0);
    var gNum = Math.pow(10, MaxNum.toString().length - 2) * 2;
    var CNum = Math.pow(10, MaxNum.toString().length - 1);
    while (CNum < MaxNum)
        CNum += CNum;
    CNum -= CNum;
    while (CNum < MaxNum)
        CNum += gNum;
    var aNum = (CNum / aver).toFixed(0);
    if (CNum > 10) {
        if (CNum < 999 || aNum < 100)
            while (aNum.toString().substring(aNum.toString().length - 1) != "0") {
                aNum = (aNum * 1) + 1;
            }
        else
            while (aNum.toString().substring(aNum.toString().length - 2) != "00") {
                aNum = (aNum * 1) + 1;
            }
    }
    return aNum * aver;
}


(function ($, window, document) {
    'use strict';
    $.fn.Eat_Arc = function (options) {
        options = $.extend({
            'chartdata1': {
                data: [{
                    name: "北京",
                    value: 9870
                },
                  {
                      name: "黑龙江",
                      value: 9570
                  },
                  {
                      name: "吉林",
                      value: 9470
                  },
                  {
                      name: "天津",
                      value: 8100
                  },
                  {
                      name: "北京",
                      value: 9870
                  },
                  {
                      name: "北京",
                      value: 9870
                  },
                  {
                      name: "北京",
                      value: 9870
                  },
                  {
                      name: "北京",
                      value: 9870
                  },
                  {
                      name: "北京",
                      value: 9870
                  },
                  {
                      name: "北京",
                      value: 9870
                  }],
                Title: "当前国内游客来源地TOP10"
            },
            "chartdata2": { "data": [{ "name": "平均驻留时间(不含旅居)", "value": "1.88" }, { "name": "平均驻留天数(含旅居)", "value": "4.5" }] },
            'chartdata3': {
                data: [
                    {
                        name: "1天",
                        num: 23
                    },
                    {
                        name: "2天",
                        num: 180
                    },
                    {
                        name: "3天",
                        num: 213
                    },
                    {
                        name: "4天",
                        num: 23
                    },
                    {
                        name: "5天",
                        num: 23
                    },
                    {
                        name: "6-30天",
                        num: 23
                    },
                    {
                        name: "31天以上",
                        num: 23
                    },
                ],
                Title: "最近12个月国内游客驻留时间统计"
            },
            'chartdata4': {
                data: [{
                    name: "俄罗斯",
                    value: 9870
                },
                  {
                      name: "黑龙江",
                      value: 9570
                  },
                  {
                      name: "吉林",
                      value: 9470
                  },
                  {
                      name: "天津",
                      value: 8100
                  },
                  {
                      name: "香港",
                      value: 9870
                  },
                  {
                      name: "俄罗斯",
                      value: 9870
                  },
                  {
                      name: "俄罗斯",
                      value: 9870
                  },
                  {
                      name: "香港",
                      value: 9870
                  },
                  {
                      name: "北京",
                      value: 9870
                  },
                  {
                      name: "北京",
                      value: 9870
                  }],
                Title: "当前国内游客来源地TOP10"
            },
            'chartdata5': {
                data: [
                    {
                        name: "飞机",
                        n: 41,
                        w: 25
                    },
                    {
                        name: "游轮",
                        n: 41,
                        w: 25
                    },
                    {
                        name: "火车",
                        n: 41,
                        w: 25
                    }
                ],
                Title: "最近12个月游客乘坐交通工具"
            },
            'chartdata6': {
                data: [
                    {
                        name: "1天",
                        num: 23
                    },
                    {
                        name: "2天",
                        num: 180
                    },
                    {
                        name: "3天",
                        num: 213
                    },
                    {
                        name: "4天",
                        num: 23
                    },
                    {
                        name: "5天",
                        num: 23
                    },
                    {
                        name: "6-30天",
                        num: 23
                    },
                    {
                        name: "31天以上",
                        num: 23
                    },
                ],
                Title: "最近12个月入境游客驻留时间统计"
            }
        }, options);

        function Chart1(data) {
            var chartContent1 = $(".chartContent1");
            chartContent1.find(".item").remove();
            if (data) {
                data.data = data.data.sort(function (a, b) {
                    return a.value < b.value;
                });
                chartContent1.find(".title").text(data.Title);
                var d = data.data;
                var MaxNum = d[0].value;
                for (var i = 0; i < d.length; i++) {
                    var _d = d[i];
                    var newItem = $('<div class="item"></div>');
                    $('<div class="name">' + _d.name + '</div>').appendTo(newItem);
                    var Wi = 360;
                    Wi = Wi * (_d.value / MaxNum);
                    $('<div class="probar"><span class="hexagon">' + (i + 1) + '</span><span class="bar"></span></div>').appendTo(newItem);
                    $('<div>' + _d.value + '</div>').appendTo(newItem);
                    newItem.appendTo(chartContent1.find(".content"));
                    newItem.find(".bar").animate({
                        "width": Wi
                    });
                }
            }
        }

        function Chart2(data) {
            if (data) {
                var chartContent2 = $(".chartContent2");
                chartContent2.find(".round").remove();
                var html = '<div class="round"><span class="num"></span><span class="Name"></span></div>';
                for (var i = 0; i < data.data.length; i++) {
                    $(html).find(".num").text(data.data[i].value + " 人").end().find(".Name").text(data.data[i].name).end().appendTo(chartContent2.find(".content"))
                    .addClass("fanda");
                }
            }
        }

        function Chart3(data) {
            if (data) {
                var d = data.data;
                var MaxNum = d[0].num;
                for (var i = 1; i < d.length; i++) {
                    if (MaxNum < parseInt(d[i].num))
                        MaxNum = parseInt(d[i].num);
                }
                var column = '<div class="column"><div class="Num"></div><div class="bar"></div> <div class="labName"></div></div>';
                var chartContent3 = $(".chartContent3");
                chartContent3.find(".bar").css("height", 0);
                chartContent3.find(".title").text(data.Title);
                MaxNum = Getinteger(MaxNum,10);
                if (MaxNum > 100)
                    for (var f = 0; f < 10; f++) {
                        chartContent3.find(".chart_tick>div").eq(f).find("span").text(((MaxNum / 10) * (10 - f)).toFixed(0));
                    }
                else
                    MaxNum = 100;
                setTimeout(function () {
                    chartContent3.find(".column").remove();
                    for (var i = 0; i < d.length; i++) {
                        var _d = d[i];
                        var newItem = $(column);
                        newItem.css("left", (50 + 10) * i + 30);
                        if (i == 0)
                            newItem.css("left", 30);
                        newItem.find(".Num").text(_d.num).end().find(".labName").text(_d.name).end();
                        newItem.insertBefore(chartContent3.find(".lable_jia"));
                        newItem.find(".bar").animate({
                            "height": (200 * (_d.num / MaxNum))
                        });
                    }
                }, 300);
            }
        }

        function Chart4(data) {
            var chartContent4 = $(".chartContent4");
            chartContent4.find(".item").remove();
            if (data) {
                data.data = data.data.sort(function (a, b) {
                    return a.value < b.value;
                });
                chartContent4.find(".title").text(data.Title);
                var d = data.data;
                var MaxNum = d[0].value;
                for (var i = 0; i < d.length; i++) {
                    var _d = d[i];
                    var newItem = $('<div class="item"></div>');
                    $('<div class="name">' + _d.name + '</div>').appendTo(newItem);
                    var Wi = 360;
                    Wi = Wi * (_d.value / MaxNum);
                    $('<div class="probar"><span class="hexagon">' + (i + 1) + '</span><span class="bar"></span></div>').appendTo(newItem);
                    $('<div>' + _d.value + '</div>').appendTo(newItem);
                    newItem.appendTo(chartContent4.find(".content"));
                    newItem.find(".bar").animate({
                        "width": Wi
                    });
                }
            }
        }

        function Chart5(data) {
            if (data) {
                var d = data.data;
                var chartContent5 = $(".chartContent5");
                var MaxNum = 0;
                for (var i = 1; i < d.length; i++) {
                    if (MaxNum < d[i].n)
                        MaxNum = d[i].n;
                    if (MaxNum < d[i].w)
                        MaxNum = d[i].w;
                }
                var maker = '<div class="colpanel"></div>';
                var column = '<div class="column"><div class="Num"></div><div class="bar"></div></div>';
                chartContent5.find(".bar").css("height", 0);
                chartContent5.find(".title").text(data.Title);
                setTimeout(function () {
                    chartContent5.find(".colpanel").remove();
                    for (var i = 0; i < d.length; i++) {
                        var _d = d[i];
                        var mm = $(maker).appendTo(chartContent5.find(".chart_forbar"));
                        var newItem = $(column);
                        newItem.find(".Num").text(_d.n);
                        newItem.appendTo(mm);

                        var newItem1 = $(column);
                        newItem1.find(".Num").text(_d.w);
                        newItem1.appendTo(mm);
                        var h = 150 * (_d.n / MaxNum);
                        newItem.find(".bar").animate({
                            "height": (h < 25 ? 25 : h)
                        });
                        var h1 = 150 * (_d.w / MaxNum);
                        newItem1.find(".bar").animate({
                            "height": (h1 < 25 ? 25 : h1)
                        });
                        $('<div class="lableName">' + _d.name + '</div>').appendTo(mm);
                    }
                }, 300);
            }
        }

        function Chart6(data) {
            if (data) {
                var d = data.data;
                var MaxNum = d[0].num;
                for (var i = 1; i < d.length; i++) {
                    if (MaxNum < parseInt(d[i].num))
                        MaxNum = parseInt(d[i].num);
                }
                var column = '<div class="column"><div class="Num"></div><div class="bar"></div> <div class="labName"></div></div>';
                var chartContent6 = $(".chartContent6");
                chartContent6.find(".column").css("height", 0);
                chartContent6.find(".title").text(data.Title);
                MaxNum = Getinteger(MaxNum,10);
                if (MaxNum > 100)
                    for (var f = 0; f < 10; f++) {
                        chartContent6.find(".chart_tick>div").eq(f).find("span").text(((MaxNum / 10) * (10 - f)).toFixed(0));
                    }
                else
                    MaxNum = 100;
                setTimeout(function () {
                    chartContent6.find(".column").remove();
                    for (var i = 0; i < d.length; i++) {
                        var _d = d[i];
                        var newItem = $(column);
                        newItem.css("left", (50 + 10) * i + 30);
                        if (i == 0)
                            newItem.css("left", 30);
                        newItem.find(".Num").text(_d.num).end().find(".labName").text(_d.name).end();
                        newItem.insertBefore(chartContent6.find(".lable_jia"));
                        newItem.find(".bar").animate({
                            "height": (200 * (_d.num / MaxNum))
                        });
                    }
                }, 300);
            }
        }

        function Updata(time) {
            $(".updateTime").stop().slideUp(function () {
                $(".updateTime").text(tiem).stop().slideDown();
            });
        }
        Chart1(options.chartdata1);
        Chart2(options.chartdata2);
        Chart4(options.chartdata4);
        Chart6(options.chartdata6);
        Chart3(options.chartdata3);
        Chart5(options.chartdata5);
        return {
            loadChart1: Chart1,
            loadChart2: Chart2,
            loadChart3: Chart3,
            loadChart4: Chart4,
            loadChart5: Chart5,
            loadChart6: Chart6,
            Updata: Updata
        }
    }
})(jQuery, window, document)
