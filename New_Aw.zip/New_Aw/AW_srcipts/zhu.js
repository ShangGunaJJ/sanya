'use strict';
if (!String.prototype.format) {
    String.prototype.format = function () {
        var args = arguments;
        return this.replace(/{(\d+)}/g, function (match, number) {
            return typeof args[number] != 'undefined' ? args[number] : match;
        });
    };
}
var app = function () {
    var $svgLine = document.querySelector('.chartContent6 svg .line');
    var sliderThumbSize = 0;
    var sliderHeight = 200;
    var svgViewBoxHeight = 100;
    var svgViewBoxThumbLimit = sliderThumbSize / 2 * (svgViewBoxHeight / sliderHeight);
    var svgViewBoxGraphMax = svgViewBoxHeight - svgViewBoxThumbLimit;
    var svgViewBoxGraphMin = svgViewBoxThumbLimit;
    var ranges = {
        range1: null,
        range2: null,
        range3: null,
        range4: null,
        range5: null,
        range6: null,
        range7: null,
        range8: null,
        range9: null,
        range10: null,
        range11: null,
        range12: null
    };
    var points = {
        begin: {
            x: 5,
            y: 0
        },
        point1: {
            x: 5,
            y: 0
        },
        control1: {
            x: 5,
            y: 10
        },
        control2: {
            x: 16,
            y: 0
        },
        point2: {
            x: 22,
            y: 0
        },
        control3: {
            x: 28,
            y: 0
        },
        point3: {
            x: 28,
            y: 0
        },
        control4: {
            x: 40,
            y: 0
        },
        point4: {
            x: 40,
            y: 0
        },
        control5: {
            x: 52,
            y: 0
        },
        point5: {
            x: 52,
            y: 0
        },
        control6: {
            x: 64,
            y: 0
        },
        point6: {
            x: 64,
            y: 0
        },
        control7: {
            x: 75,
            y: 0
        },
        point7: {
            x: 75,
            y: 0
        },
        control8: {
            x: 86,
            y: 0
        },
        point8: {
            x: 86,
            y: 0
        },
        control9: {
            x: 98,
            y: 0
        },
        point9: {
            x: 98,
            y: 0
        },
        control10: {
            x: 110,
            y: 0
        },
        point10: {
            x: 110,
            y: 0
        },
        control11: {
            x: 121,
            y: 0
        },
        point11: {
            x: 121,
            y: 0
        },
        control12: {
            x: 132,
            y: 0
        },
        point12: {
            x: 132,
            y: 0
        }

    };
    function mapDataRange(value) {
        return (value - 0) * (svgViewBoxGraphMax - svgViewBoxGraphMin) / (svgViewBoxHeight - 0) + svgViewBoxGraphMin;
    }
    function updateSlider($element, keyS, line, count) {
        $svgLine = line;
        if ($element) {
            var rangeIndex = $element.getAttribute('data-slider-index'), range = ranges[rangeIndex], value = $element.value;
            ranges[rangeIndex] = value;
            var parent = $element.parentElement, $thumb = parent.querySelector('.range-slider__thumb'), $bar = parent.querySelector('.range-slider__bar'),
            pct = (value / keyS) * 100;
            $thumb.style.bottom = pct + '%';
            $bar.style.height = 'calc(' + pct + '% + ' + sliderThumbSize / 2 + 'px)';
            renderSliderGraph(keyS, count);
        }
    }
    function updatePoints(key) {
        points.point1.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range1 / key | 0;
        points.point2.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range2 / key | 0;
        points.point3.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range3 / key | 0;
        points.point4.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range4 / key | 0;
        points.point5.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range5 / key | 0;
        points.point6.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range6 / key | 0;
        points.point7.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range7 / key | 0;


        points.point8.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range8 / key | 0;
        points.point9.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range9 / key | 0;
        points.point10.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range10 / key | 0;
        points.point11.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range11 / key | 0;
        points.point12.y = svgViewBoxHeight - svgViewBoxHeight * ranges.range12 / key | 0;

        var max = svgViewBoxGraphMax;
        var min = svgViewBoxGraphMin;
        points.point1.y = mapDataRange(points.point1.y);
        points.point2.y = mapDataRange(points.point2.y);
        points.point3.y = mapDataRange(points.point3.y);
        points.point4.y = mapDataRange(points.point4.y);
        points.point5.y = mapDataRange(points.point5.y);
        points.point6.y = mapDataRange(points.point6.y);
        points.point7.y = mapDataRange(points.point7.y);

        points.point8.y = mapDataRange(points.point8.y);
        points.point9.y = mapDataRange(points.point9.y);
        points.point10.y = mapDataRange(points.point10.y);
        points.point11.y = mapDataRange(points.point11.y);
        points.point12.y = mapDataRange(points.point12.y);

        points.begin.y = points.point1.y;
        points.control1.y = points.point1.y;
        points.control2.y = points.point2.y;
        points.control3.y = points.point3.y;
        points.control4.y = points.point4.y;
        points.control5.y = points.point5.y;
        points.control6.y = points.point6.y;
        points.control7.y = points.point7.y;

        points.control8.y = points.point8.y;
        points.control9.y = points.point9.y;
        points.control10.y = points.point10.y;
        points.control11.y = points.point11.y;
        points.control12.y = points.point12.y;
    }
    function getInterpolatedLine(index) {
        var p = "M {0},{1}"
        for (var i = 1; i <= index; i++) {
            p += `L{${(i - 1) * 4 + 2}},{${(i - 1) * 4 + 3}}`;
        }

        return p
        .format(points.begin.x,
                points.begin.y,
        points.point1.x,
                points.point1.y,
                points.control1.x,
                points.control1.y,
        points.control2.x,
                points.control2.y,
                points.point2.x,
                points.point2.y,
        points.control3.x,
                points.control3.y,
                points.point3.x,
                points.point3.y,
        points.control4.x,
                points.control4.y,
                points.point4.x,
                points.point4.y,
        points.control5.x,
                points.control5.y,
                points.point5.x,
                points.point5.y,
        points.control6.x,
                points.control6.y,
                points.point6.x,
                points.point6.y,
        points.control7.x, points.control7.y, points.point7.x, points.point7.y,
        points.control8.x, points.control8.y, points.point8.x, points.point8.y,
               points.control9.x, points.control9.y, points.point9.x, points.point9.y,
               points.control10.x, points.control10.y, points.point10.x, points.point10.y,
               points.control11.x, points.control11.y, points.point11.x, points.point11.y,
               points.control12.x, points.control12.y, points.point12.x, points.point12.y);
    }
    function reset() {
        var inputs = app.inputs;
        inputs.forEach(function (input) {
            return app.updateSlider(input);
        });
    }
    function renderSliderGraph(k, count) {
        updatePoints(k);
        $svgLine.setAttribute('d', getInterpolatedLine(count));
    }
    function selectPreset(key, el, c) {
        var inputs = app.inputs;
        $svgLine = el;
        inputs.forEach(function (input) {
            return app.updateSlider(input, key, c);
        });
    }
    return {
        inputs: [].slice.call(document.querySelectorAll('.sliders input')),
        updateSlider: updateSlider,
        reset: reset,
        selectPreset: selectPreset,
        $svgLine: null,

    };
}();

function Getinteger(MaxNum, aver) {
    MaxNum = (MaxNum * 1).toFixed(0);
    var gNum = Math.pow(10, MaxNum.toString().length - 2) * 2;
    var CNum = Math.pow(10, MaxNum.toString().length - 1);
    while (CNum < MaxNum)
        CNum += CNum;
    CNum -= CNum;
    while (CNum < MaxNum)
        CNum += gNum;
    var aNum = (CNum / aver).toFixed(0);
    if (CNum > 10)
        while (aNum.toString().substring(aNum.toString().length - 1) != "0") {
            aNum = (aNum * 1) + 1;
        }
    return aNum * aver;
}
(function ($, window, document) {
    'use strict';
    $.fn.Zhu_Arc = function (options) {
        var LA = $.fn.Zhu_Arc;
        options = $.extend({
            'chartdata1': {
                data: [
                    {
                        name: "豪华",
                        num: 41
                    },
                    {
                        name: "五星级",
                        num: 150
                    },
                    {
                        name: "四星级",
                        num: 130
                    },
                    {
                        name: "三星级",
                        num: 23
                    },
                    {
                        name: "二星级",
                        num: 180
                    },
                    {
                        name: "高档",
                        num: 213
                    },
                    {
                        name: "其他旅馆",
                        num: 23
                    }
                ],
                Title: "全市旅游饭店房间数量"
            },
            'chartdata2': {
                data: [{
                    name: "豪华",
                    value: 165,
                },
                    {
                        name: "五星级",
                        value: 265,
                    },
                    {
                        name: "四星级",
                        value: 465,
                    },
                    {
                        name: "三星级",
                        value: 365,
                    }, {
                        name: "二星级",
                        value: 165,
                    }, {
                        name: "高档",
                        value: 165,
                    }, {
                        name: "其他旅馆",
                        value: 165,
                    }],
                Title: "全市餐饮企业数量"
            },
            'chartdata3': {
                data: [{ year1: 30, year2: 30 },
                    { year1: 30, year2: 40 }, { year1: 30, year2: 40 },
                    { year1: 30, year2: 40 }, { year1: 40, year2: 50 }, { year1: 20, year2: 30 }, { year1: 20, year2: 30 },
                    { year1: 20, year2: 30 }], YearS: { year1: "2015", len1: 12, year2: "2016", len2: 11 }, Title: '2015/2016年每月酒店境内游客入住人数'
            },
            'chartdata4': {
                data: [{
                    name: "豪华",
                    a: 56,
                    b: 87,
                    c: 100,
                    d: 20
                },
                    {
                        name: "五星级",
                        a: 56,
                        b: 87,
                        c: 100,
                        d: 20
                    },
                    {
                        name: "四星级",
                        a: 56,
                        b: 87,
                        c: 100,
                        d: 20
                    },
                    {
                        name: "三星级",
                        a: 56,
                        b: 87,
                        c: 100,
                        d: 20
                    },
                    {
                        name: "二星级",
                        a: 56,
                        b: 87,
                        c: 100,
                        d: 20
                    },
                    {
                        name: "高档",
                        a: 56,
                        b: 87,
                        c: 100,
                        d: 20
                    },
                    {
                        name: "其他旅馆",
                        a: 56,
                        b: 87,
                        c: 100,
                        d: 20
                    }
                ],
                Title: "全市行政区域食品安全量化评估等级企业统计"
            },
            'chartdata5': {
                data: { n: 14382, w: 828 },
                Title: "全市昨日酒店入住人数"
            },
            'chartdata6': {
                data: [{
                    year1: 1.2,
                    year2: 1
                }, {
                    year1: 2,
                    year2: 2.1
                }, {
                    year1: 2.4,
                    year2: 2.3
                }, {
                    year1: 1.3,
                    year2: 2.5
                }, {
                    year1: 4,
                    year2: 3
                }, {
                    year1: 3,
                    year2: 4
                }, {
                    year1: 4,
                    year2: 7
                }, {
                    year1: 3,
                    year2: 5
                }, {
                    year1: 2,
                    year2: 5
                }, {
                    year1: 2,
                    year2: 4
                }, {
                    year1: 1,
                    year2: 5
                }, {
                    year1: 2,
                    year2: 5
                }],
                YearS: {
                    year1: "2015", len1: 12, year2: "2016", len2: 11
                }, Title: '2015/2016年每月酒店境内游客入住人数'
            }
        }, options);

        function Chart3(data) {
            $("input").val(0);
            if (data) {
                var sliders = $(".checkIn1");
                $(sliders).find(".title").text(data.Title);
                $(sliders).find(".lableee").find("div").eq(0).text(data.YearS.year1);
                $(sliders).find(".lableee").find("div").eq(1).text(data.YearS.year2);
                var d = data.data;
                var MaxNum = 0;
                for (var i = 0; i < d.length; i++) {
                    var _d = d[i];
                    sliders.find(".Accept .range-slider").eq(i).find("input").val(_d.year1);
                    sliders.find(".End .range-slider").eq(i).find("input").val(_d.year2);
                    if (MaxNum < d[i].year1)
                        MaxNum = d[i].year1;
                    if (MaxNum < d[i].year2)
                        MaxNum = d[i].year2;
                }
                MaxNum = Getinteger(MaxNum, 7);
                for (var f = 0; f < 9; f++) {
                    sliders.find(".tickline>div").eq(f).find("span").text(((MaxNum / 7) * (7 - f)).toFixed(0));
                }
                $(".checkIn1 .range-slider").css("opacity", 1);
                if (data.YearS.len1)
                    $(".checkIn1 .Accept .range-slider:gt(" + (data.YearS.len1 - 1) + ")").css("opacity", 0);
                if (data.YearS.len2)
                    $(".checkIn1 .End .range-slider:gt(" + (data.YearS.len2 - 1) + ")").css("opacity", 0);
                app.inputs = [].slice.call(document.querySelectorAll('.checkIn1 .Accept input'));
                var inputs = app.inputs;
                var index = 1;
                var p = document.querySelector('.checkIn1 .Accept svg .line');
                inputs.forEach(function (input) {
                    return input.setAttribute('data-slider-index', 'range' + index++);
                });
                inputs.forEach(function (input) {
                    return app.updateSlider(input, MaxNum, p, (data.YearS.len1 ? data.YearS.len1 : 12));
                });

                p = document.querySelector('.checkIn1 .End svg .line');
                app.inputs = [].slice.call(document.querySelectorAll('.checkIn1 .End input'));
                inputs = app.inputs;
                index = 1;
                inputs.forEach(function (input) {
                    return input.setAttribute('data-slider-index', 'range' + index++);
                });
                inputs.forEach(function (input) {
                    return app.updateSlider(input, MaxNum, p, (data.YearS.len2 ? data.YearS.len2 : 12));
                });
            }
        }

        function Chart6(data) {
            if (data) {
                var sliders = $(".checkIn");
                $(sliders).find(".title").text(data.Title);
                $(sliders).find(".lableee").find("div").eq(0).text(data.YearS.year1);
                $(sliders).find(".lableee").find("div").eq(1).text(data.YearS.year2);
                var d = data.data;
                var MaxNum = 0;
                for (var i = 0; i < d.length; i++) {
                    var _d = d[i];
                    sliders.find(".Accept .range-slider").eq(i).find("input").val(_d.year1);
                    sliders.find(".End .range-slider").eq(i).find("input").val(_d.year2);
                    if (MaxNum < d[i].year1)
                        MaxNum = d[i].year1;
                    if (MaxNum < d[i].year2)
                        MaxNum = d[i].year2;
                }
                MaxNum = Getinteger(MaxNum, 7);
                for (var f = 0; f < 9; f++) {
                    sliders.find(".tickline>div").eq(f).find("span").text(((MaxNum / 7) * (7 - f)).toFixed(0));
                }
                $(".checkIn .range-slider").css("opacity", 1);
                if (data.YearS.len1)
                    $(".checkIn .Accept .range-slider:gt(" + (data.YearS.len1 - 1) + ")").css("opacity", 0);
                if (data.YearS.len2)
                    $(".checkIn .End .range-slider:gt(" + (data.YearS.len2 - 1) + ")").css("opacity", 0);
                app.inputs = [].slice.call(document.querySelectorAll('.checkIn .Accept input'));
                var inputs = app.inputs;
                var index = 1;
                var p = document.querySelector('.checkIn .Accept svg .line');
                inputs.forEach(function (input) {
                    return input.setAttribute('data-slider-index', 'range' + index++);
                });
                inputs.forEach(function (input) {
                    return app.updateSlider(input, MaxNum, p, (data.YearS.len1 ? data.YearS.len1 : 12));
                });

                p = document.querySelector('.checkIn .End svg .line');
                app.inputs = [].slice.call(document.querySelectorAll('.checkIn .End input'));
                inputs = app.inputs;
                index = 1;
                inputs.forEach(function (input) {
                    return input.setAttribute('data-slider-index', 'range' + index++);
                });
                inputs.forEach(function (input) {
                    return app.updateSlider(input, MaxNum, p, (data.YearS.len2 ? data.YearS.len2 : 12));
                });
            }
        }
        function Updata(time) {
            $(".updateTime").stop().slideUp(function () {
                $(".updateTime").text(tiem).stop().slideDown();
            });
        }

        function Chart1(data) {
            if (data) {
                var d = data.data;
                var MaxNum = d[0].num;
                for (var i = 1; i < d.length; i++) {
                    if (MaxNum < d[i].num)
                        MaxNum = d[i].num;
                }
                var column = '<div class="column"><div class="Num"></div><div class="bar"></div> <div class="labName"></div></div>';
                var chartContent1 = $(".chartContent1");
                chartContent1.find(".title").text(data.Title);
                chartContent1.find(".bar").css("height", 0);
                setTimeout(function () {
                    chartContent1.find(".column").remove();
                    for (var i = 0; i < d.length; i++) {
                        var _d = d[i];
                        var newItem = $(column);
                        newItem.css("left", (56 + 20) * i);
                        newItem.find(".bar").css("width", "22");
                        newItem.find(".Num").text(_d.num).end().find(".labName").text(_d.name).end();
                        newItem.insertBefore(chartContent1.find(".footer"));
                        newItem.find(".bar").animate({
                            "height": (140 * (_d.num / MaxNum))
                        });
                    }
                }, 300)
            }
        }
        function Chart4(data) {
            if (data) {
                var d = data.data;
                var MaxNum = 0;
                var chartContent3 = $(".chartContent3");
                $(".chartContent3 .title").text(data.Title);
                chartContent3.find(".colpanel").remove();
                setTimeout(function () {
                    var html = '<div class="colpanel"></div>';
                    var item = '<div class="column"> <div class="Num"></div><div class="bar"></div> </div>';
                    for (var i = 0; i < d.length; i++) {
                        if (MaxNum < d[i].a)
                            MaxNum = d[i].a;
                        if (MaxNum < d[i].b)
                            MaxNum = d[i].b;
                        if (MaxNum < d[i].c)
                            MaxNum = d[i].c;
                        if (MaxNum < d[i].d)
                            MaxNum = d[i].d;
                    }
                    MaxNum = Getinteger(MaxNum, 5);
                    if (MaxNum > 80)
                        for (var f = 0; f < 6; f++) {
                            chartContent3.find(".footer>div").eq(f).find("span").text(((MaxNum / 5) * (5 - f)).toFixed(0));
                        }
                    else
                        MaxNum = 80;
                    chartContent3.find(".bar").css("height", 0);
                    for (var y = 0; y < d.length; y++) {
                        var _d = d[y];
                        var Maker = $(html).insertBefore(chartContent3.find(".footer"));
                        $(item).appendTo(Maker).find(".bar").animate({
                            "height": (150 * (_d.a / MaxNum))
                        });
                        $(item).appendTo(Maker).find(".bar").animate({
                            "height": (150 * (_d.b / MaxNum))
                        });
                        $(item).appendTo(Maker).find(".bar").animate({
                            "height": (150 * (_d.c / MaxNum))
                        });
                        $(item).appendTo(Maker).find(".bar").animate({
                            "height": (150 * (_d.d / MaxNum))
                        });
                        $('<div class="lableName">' + _d.name + '</div>').appendTo(Maker)
                    }
                }, 300);
            }
        }
        function Chart2(data) {
            var option = {
                title: {
                    text: '',
                    subtext: '',
                    x: 'center'
                },
                tooltip: {
                    trigger: 'item',
                    formatter: "{a} <br/>{b} : {c} ({d}%)"
                },
                legend: {
                    show: false
                },
                toolbox: {
                    show: false
                },
                calculable: true,
                series: [
                    {
                        name: '面积模式',
                        type: 'pie',
                        radius: [40, 80],
                        center: ['50%', '50%'],
                        roseType: 'area',
                        color: ["#1a7c31", "#1ea29f", "#601986", "#00479d"],
                        data: data.data,
                        label: {
                            normal: {
                                textStyle: {
                                    color: "#fff",
                                    fontSize: 12
                                }
                            }
                        },
                        labelLine: {
                            normal: {
                                length: 10,
                                length2: 40,
                                lineStyle: {
                                    color: "#556FB5",
                                    type: "dashed"
                                }
                            }
                        }
                    }
                ]
            };

            var myChart = echarts.init(document.getElementById('chat'));
            var count = 0;
            for (var i = 0; i < data.data.length; i++) {
                data.data[i].name += "：" + data.data[i].value + "家";
                count += data.data[i].value;
            }
            $(".chartContent2 .labelcount").text(count);
            option = {
                tooltip: {
                    trigger: 'item',
                    formatter: "{a} <br/>{b}: {c} ({d}%)"
                },
                legend: {
                    orient: 'vertical',
                    x: 'left',
                },
                series: [

                    {
                        name: '访问来源',
                        type: 'pie',
                        color: ["#5e1c7b", "#8f82bc", "#a23391", "#1ea29f", "#5cadd3", "#7cb306", "#c28013"],
                        radius: ['40%', '55%'],
                        label: {
                            normal: {
                                textStyle: {
                                    color: "#fff",
                                    fontSize: 12
                                }
                            }
                        },
                        data: data.data
                    }
                ]
            };

            $(".chartContent2 .title").text(data.Title);
            myChart.setOption(option);

        }
        function Chart5(data) {
            var count = data.data.n + data.data.w;
            var chartContent4 = $(".chartContent4");
            chartContent4.find(".title").text(data.Title);
            chartContent4.find(".labeleft .num").text(data.data.n);
            chartContent4.find(".laberight .num").text(data.data.w);
            chartContent4.find(".count").text(count + " 人");

            var sss = 680 * (data.data.w / count);
            if (sss < 75)
                $("#container").css("transform", "rotate(78deg)");
            if (!Highcharts.theme) {
                Highcharts.setOptions({
                    chart: {
                        backgroundColor: 'transparent'
                    },
                    colors: ['#556FB5', '#1a7c31'],
                    title: {
                        style: {
                            color: 'silver'
                        }
                    },
                    tooltip: {
                        style: {
                            color: 'silver'
                        }
                    }
                });
            }
            Highcharts.chart('container', {
                chart: {
                    type: 'solidgauge',
                    marginTop: 0
                },
                credits: {
                },
                title: {
                    text: ""
                },
                tooltip: {
                    borderWidth: 0,
                    backgroundColor: 'none',
                    shadow: true,
                },
                credits: {
                    text: '',
                    href: ''
                },
                pane: {
                    startAngle: 0,
                    endAngle: sss,
                    background: [{
                        outerRadius: '100%',
                        innerRadius: '70%',
                        backgroundColor: Highcharts.Color(Highcharts.getOptions().colors[1]).setOpacity(1).get(),
                        borderWidth: 0,
                    }]
                },
                yAxis: {
                    min: 0,
                    max: 100,
                    lineWidth: 0,
                    tickPositions: []
                },
                plotOptions: {
                    solidgauge: {
                        borderWidth: '20px',
                        dataLabels: {
                            enabled: false
                        },
                        linecap: 'round',
                        stickyTracking: false
                    }
                },
                series: [{
                    name: 'Move',
                    borderColor: Highcharts.getOptions().colors[0],
                    data: [{
                        color: Highcharts.getOptions().colors[0],
                        radius: '84%',
                        innerRadius: '88%',
                        y: 50
                    }]
                }]
            });
        }
        Chart1(options.chartdata1);
        Chart4(options.chartdata4);
        Chart2(options.chartdata2);
        Chart5(options.chartdata5);
        Chart3(options.chartdata3);

        Chart6(options.chartdata6);
        return {
            loadChart1: Chart1,
            loadChart2: Chart2,
            loadChart3: Chart3,
            loadChart4: Chart4,
            loadChart5: Chart5,
            loadChart6: Chart6,
            Updata: Updata
        }
    }
})(jQuery, window, document)