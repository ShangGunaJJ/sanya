﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Xml;
using System.IO;

namespace inv_tax_common
{
    public static class Webservice
    {
        //远光测试服务器
        //static string url = "http://fapiao2.ygsoft.com/invtax/WebService.asmx";
        //远光正式服务器
        //static string url = "http://fapiaoyun.ygsoft.com/ygsisoft/webservice.asmx";
        //内部正式服务器
        static string url = "http://39.108.14.66/Invtax/WebService.asmx";
        //内部测试服务器
        //static string url = "http://39.108.14.66/invtaxTese/WebService.asmx";
        //本地开发服务器
        //static string url = "http://localhost:6001/WebService.asmx";
        
        static Webservice()
        {
            if (url == "")
            {
                inv_tax_common.IniFileRW iniFile = new inv_tax_common.IniFileRW();
                url = iniFile.ReadValue("SystemConfig", "WebServiceAddress");
                url = inv_tax_common.EncrptStr.Decode(url);
            }
        }

        public static UserInfo Login(string username, string password)
        {
            UserInfo ui = new UserInfo();
            string[] args = new string[2];
            args[0] = username;
            args[1] = password;
            object result = null;
            try
            {
                result = ConnectionWebService.InvokeWebService(url, "Login", args);
            }
            catch (Exception ex)
            {
                ui.Logined = false;
                ui.Message = "无法连接到远程服务器，请先进行服务器设置，测试是否正常访问。";
                return ui;
            }
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(result.ToString());
            //string ss = xmlDoc.GetElementById("\\userinfo\\login").InnerText;
            XmlElement node = xmlDoc.DocumentElement;
            ui.Logined = bool.Parse(node["login"].InnerText);
            ui.UserID = node["userid"].InnerText;
            ui.UserName = node["username"].InnerText;
            ui.Password = node["password"].InnerText;
            ui.CompanyName = node["companyname"].InnerText;
            ui.CompanyGuid = node["companyguid"].InnerText;
            ui.SessionId = node["sessionid"].InnerText;
            ui.TotlePages = int.Parse(node["totlePages"].InnerText);
            ui.UsedPages = int.Parse(node["usedPages"].InnerText);
            ui.ExpireDate = node["expireDate"].InnerText;
            if (node["Privilege"].InnerText!="")
                ui.Privilege = int.Parse(node["Privilege"].InnerText);
            ui.Priority = node["priority"].InnerText;
            if (node["ExpireAlertPages"].InnerText.Trim()!="")
                ui.ExpireAlertPages = int.Parse(node["ExpireAlertPages"].InnerText);
            ui.SH = node["SH"].InnerText;
            ui.Mode = node["Mode"].InnerText;
            try
            {
                ui.KeyWord = node["keyword"].InnerText;
            }
            catch { }
            ui.Message = node["errormessage"].InnerText;
            if (ui.ExpireAlertPages == 0)
                ui.ExpireAlertPages = 50;
            return ui;

        }
        public static int UserUpdatePassword(string guid, string username, string oldpassword, string newpassword)
        {
            int n = 0;
            string[] args = new string[4];
            args[0] = guid;
            args[1] = username;
            args[2] = oldpassword;
            args[3] = newpassword;
            try
            {
                object result = ConnectionWebService.InvokeWebService(url, "UserUpdatePassword", args);
                if (result != null)
                    n = int.Parse(result.ToString());
            }
            catch { }
            return n;
        }
        public static DataTable GetRecords(string guid, string stauts, int page, int pagesize)
        {
            string[] args = new string[4];
            args[0] = guid;
            args[1] = stauts;
            args[2] = page.ToString();
            args[3] = pagesize.ToString();
            DataTable dt=null;
            object result = ConnectionWebService.InvokeWebService(url, "GetRecords", args);
            if (result != null)
                dt = (DataTable)result;
            return dt;

        }
        public static string GetRecordById(string sessionId, string id)
        {
            string fp="";
            string[] args = new string[2];
            args[0] = sessionId;
            args[1] = id;
            try
            {
                object result = ConnectionWebService.InvokeWebService(url, "GetRecordById", args);
                if (result != null)
                    fp = result.ToString();
            }
            catch { }
            return fp;
        }
        public static int GetRecordsCountByStauts(string guid, string stauts)
        {
            int count = 0;
            string[] args = new string[2];
            args[0] = guid;
            args[1] = stauts;
            object result = ConnectionWebService.InvokeWebService(url, "GetRecordsCountByStauts", args);
            if (result != null)
                count = int.Parse(result.ToString());
            return count;
        }
        public static DataTable GetRecordDetailsByMainIDs(string guid, string id)
        {
            string[] args = new string[2];
            args[0] = guid;
            args[1] = id;
            DataTable dt = null;
            try
            {
                object result = ConnectionWebService.InvokeWebService(url, "GetRecordDetailsByMainIDs", args);
                if (result != null)
                    dt = (DataTable)result;
            }
            catch
            { }
            return dt;
        }

        public static DataTable GetRecordDetailsForDisplayByMainIDs(string guid, string id)
        {
            string[] args = new string[2];
            args[0] = guid;
            args[1] = id;
            DataTable dt = null;
            try
            {
                object result = ConnectionWebService.InvokeWebService(url, "GetRecordDetailsForDisplayByMainIDs", args);
                if (result != null)
                    dt = (DataTable)result;
            }
            catch
            { }
            return dt;
        }
        public static int GetSearchRecordsCountBySql(string guid, string sql)
        {
            int count = 0;
            string[] args = new string[2];
            args[0] = guid;
            args[1] = sql;
            object result = ConnectionWebService.InvokeWebService(url, "GetSearchRecordsCountBySql", args);
            if (result != null)
                count = int.Parse(result.ToString());
            return count;
        }
        public static DataTable GetSearchRecords(string guid, string sql, int page, int pagesize)
        {
            string[] args = new string[4];
            args[0] = guid;
            args[1] = sql;
            args[2] = page.ToString();
            args[3] = pagesize.ToString();
            DataTable dt = null;
            object result = ConnectionWebService.InvokeWebService(url, "GetSearchRecords", args);
            if (result != null)
                dt = (DataTable)result;
            return dt;
        }
        public static string DeleteRecordById(string id, string sessionId)
        {
            string s = ""; ;
            string[] args = new string[2];
            args[0] = id;
            args[1] = sessionId;
            object result = ConnectionWebService.InvokeWebService(url, "DeleteRecordById", args);
            if (result != null)
                s = result.ToString();
            return s;
        }
        public static string UpdateRecord(string id, string fplx, string fpdm, string fphm, string kprq, string je)
        {
            string msg = "";
            string[] args = new string[6];
            args[0] = id;
            args[1] = fplx;
            args[2] = fpdm;
            args[3] = fphm;
            args[4] = kprq;
            args[5] = je;
            try
            {
                object result = ConnectionWebService.InvokeWebService(url, "UpdateRecord", args);
                if (result != null)
                    msg = result.ToString();
            }
            catch
            { }

            return msg;
        }
        public static string ReCheckFP(string idList,string sessionId)
        {
            string s = ""; ;
            string[] args = new string[1];
            args[0] = idList;
            object result = ConnectionWebService.InvokeWebService(url, "ReCheckFP", args);
            if (result != null)
                s = result.ToString();
            return s;
        }
        public static DataTable GetRepeatLog(string sessionId, string username, string Privilege)
        {
            string[] args = new string[3];
            args[0] = sessionId;
            args[1] = username;
            args[2] = Privilege;
            DataTable dt = null;
            try
            {
                object result = ConnectionWebService.InvokeWebService(url, "GetRepeatLog", args);
                if (result != null)
                    dt = (DataTable)result;
            }
            catch
            { }
            return dt;
        }
        public static DataTable CheckRepeatLRecords(string fpdm, string fphm, string sessionid, string loginusername)
        {
            return CheckRepeatLRecords(fpdm, fphm, sessionid, loginusername, "1");
        }
        public static DataTable CheckRepeatLRecords(string fpdm, string fphm, string sessionid, string loginusername, string writeLog)
        {
            string[] args = new string[5];
            args[0] = fpdm;
            args[1] = fphm;
            args[2] = sessionid;
            args[3] = loginusername;
            args[4] = writeLog;
            DataTable dt = null;
            try
            {
                object result = ConnectionWebService.InvokeWebService(url, "CheckRepeatLRecords", args);
                if (result != null)
                    dt = (DataTable)result;
            }
            catch
            { }
            return dt;
        }
        public static string AddRecord(string fplx, string fpdm, string fphm, string kprq, string je, string sessionId,string createuser)
        {
            string msg = "";
            string[] args = new string[7];
            args[0] = fplx;
            args[1] = fpdm;
            args[2] = fphm;
            args[3] = kprq;
            args[4] = je;
            args[5] = sessionId;
            args[6] = createuser;
            try
            {
                object result = ConnectionWebService.InvokeWebService(url, "AddRecord", args);
                if (result != null)
                    msg = result.ToString();
            }
            catch
            { }

            return msg;

        }

        public static string Test(string WebServiceAddress ,string sessionId)
        {
            string msg = "";
            string[] args = new string[1];
            args[0] = sessionId;
            try
            {
                object result = ConnectionWebService.InvokeWebService(WebServiceAddress, "Test", args);
                if (result != null)
                    msg = result.ToString();
            }
            catch
            { }
            return msg;
        }
        public static string TransferToDataCenter(string idList, string sessionId)
        {
            string s = ""; ;
            string[] args = new string[2];
            args[0] = idList;
            args[1] = sessionId;
            object result = ConnectionWebService.InvokeWebService(url, "TransferToDataCenter", args);
            if (result != null)
                s = result.ToString();
            return s;
        }
        public static string ChangFPException(string idList, string statusName, string guid)
        {
            string s = "";
            string[] args = new string[3];
            args[0] = idList;
            args[1] = statusName;
            args[2] = guid;
            object result = ConnectionWebService.InvokeWebService(url, "ChangFPException", args);
            if (result != null)
                s = result.ToString();
            return s;
        }

        public static string TryKeyword(string keywords, string sessionId)
        {
            string s = "";
            string[] args = new string[2];
            args[0] = keywords;
            args[1] = sessionId;
            object result = ConnectionWebService.InvokeWebService(url, "TryKeyword", args);
            if (result != null)
                s = result.ToString();
            return s;
        }

        public static string UpdateTryKeyword(string keywords, string sessionId)
        {
            string s = "";
            string[] args = new string[2];
            args[0] = keywords;
            args[1] = sessionId;
            object result = ConnectionWebService.InvokeWebService(url, "UpdateTryKeyword", args);
            if (result != null)
                s = result.ToString();
            return s;
        }
        public static string AddHistroyRecords(string values)
        {
            string s = "";
            string[] args = new string[1];
            args[0] = values;
            object result = ConnectionWebService.InvokeWebService(url, "AddHistroyRecords", args);
            if (result != null)
                s = result.ToString();
            return s;
        }
    }
}
