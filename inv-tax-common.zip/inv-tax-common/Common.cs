﻿using System;
using System.Drawing;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Microsoft.Win32;
namespace inv_tax_common
{
    public class Common
    {
        //public static string softName = "远光发票云";
        public static string softName = "Invtax发票云";
        public static string getFPDQ(string sfpdm)
        {
            string dq = "";
            #region 发票代码对应服务器
            string[,] citys = new string[,]{{"1100","北京"},
                                             {"1200","天津"},
                                             {"1300","河北"},
                                             {"1400","山西"},
                                             {"1500","内蒙古"},
                                             {"2100","辽宁"},
                                             {"2102","大连"},
                                             {"2200","吉林"},
                                             {"2300","黑龙江"},
                                             {"3100","上海"},
                                             {"3200","江苏"},
                                             {"3300","浙江"},
                                             {"3302","宁波"},
                                             {"3400","安徽"},
                                             {"3500","福建"},
                                             {"3502","厦门"},
                                             {"3600","江西"},
                                             {"3700","山东"},
                                             {"3702","青岛"},
                                             {"4100","河南"},
                                             {"4200","湖北"},
                                             {"4300","湖南"},
                                             {"4400","广东"},
                                             {"4403","深圳"},
                                             {"4500","广西"},
                                             {"4600","海南"},
                                             {"5000","重庆"},
                                             {"5100","四川"},
                                             {"5200","贵州"},
                                             {"5300","云南"},
                                             {"5400","西藏"},
                                             {"6100","陕西"},
                                             {"6200","甘肃"},
                                             {"6300","青海"},
                                             {"6400","宁夏"},
                                             {"6500","新疆"}};
            #endregion
            if (sfpdm.Length == 12)
            {
                sfpdm = sfpdm.Substring(1, 5);
            }
            else
            {
                sfpdm = sfpdm.Substring(0, 4);
            }
            if (sfpdm != "2102" && sfpdm != "3302" && sfpdm != "3502" && sfpdm != "3702" && sfpdm != "4403")
            {
                sfpdm = sfpdm.Substring(0, 2) + "00";
            }
            for (int i = 0; i < citys.Length; i++)
            {
                if (sfpdm == citys[i, 0])
                {
                    dq = citys[i, 1];
                    break;
                }
            }

            return dq;
        }
        public static string getFPLX(string sfpdm)
        {
            string a = sfpdm;
            string b;
            string c = "99";

            if (a.Length == 12)
            {
                b = a.Substring(7, 1);
                if (c == "99")
                {  //增加判断，判断是否为新版电子票
                    if (a.Substring(0, 1) == "0" && a.Substring(10, 2) == "11")
                    {
                        c = "10";
                    }
                    if (a.Substring(0, 1) == "0" && (a.Substring(10, 2) == "06" || a.Substring(10, 2) == "07"))
                    {  //判断是否为卷式发票  第1位为0且第11-12位为06或07
                        c = "11";
                    }
                }
                if (c == "99")
                { //如果还是99，且第8位是2，则是机动车发票
                    if (b == "2" && a.Substring(0, 1) != "0")
                    {
                        c = "03";
                    }
                    else
                    {
                        c = "10";
                    }
                }
            }
            else if (a.Length == 10)
            {
                b = a.Substring(7, 1);
                if (b == "1" || b == "5")
                {
                    c = "01";
                }
                else if (b == "6" || b == "3")
                {
                    c = "04";
                }
                else if (b == "7" || b == "2")
                {
                    c = "02";
                }
            }
            if (c == "99")
                c = "";
            return c;
        }
        public static string getFPLXName(string sfplx)
        {
            string fpmc = "";
            if (sfplx == "01")
            {
                fpmc = "增值税专用发票";
            }
            else if (sfplx == "02")
            {
                fpmc = "增值税专用发票";
            }
            else if (sfplx == "03")
            {
                fpmc = "机动车电子发票";
            }
            else if (sfplx == "04")
            {
                fpmc = "增值税普通发票";
            }
            else if (sfplx == "10")
            {
                fpmc = "增值税电子普通发票";
            }
            else if (sfplx == "11")
            {
                fpmc = "增值税普通发票(卷票)";
            }
            return fpmc;

        }
        public static void UploadImage(string filepath, string subFolder, string fileName)
        {
            string UploadFolder = System.IO.Directory.GetCurrentDirectory() + "\\UploadImage\\" + subFolder;
            try
            {
                if (!Directory.Exists(UploadFolder))
                    Directory.CreateDirectory(UploadFolder);
                int n = filepath.LastIndexOf('.');
                string exf = filepath.Substring(n, filepath.Length - n);
                string destFileName = UploadFolder + "\\" + fileName + exf;
                File.Copy(filepath, destFileName, true);
            }
            catch { }
        }
        public static string GetImagePath(string companyName, string fpdm, string fphm)
        {
            string filePath = "";
            try
            {
                string UploadFolder = System.IO.Directory.GetCurrentDirectory() + "\\UploadImage\\" + companyName;
                if (!Directory.Exists(UploadFolder))
                    return "";
                string fileName = fpdm + "_" + fphm + ".*";
                string[] tmp = Directory.GetFiles(UploadFolder, fileName);
                if (tmp.Length > 0)
                    filePath = tmp[0];
            }
            catch { }
            return filePath;
        }
        public static void DeleteFile(string filePath)
        {
            try
            {
                if (File.Exists(filePath))
                    File.Delete(filePath);
            }
            catch { }
        }
        public static bool CheckClsIDSetup()
        {
            bool flag = false;
            try
            {
                RegistryKey Key = Registry.ClassesRoot;
                RegistryKey myreg = Key.OpenSubKey(@"CLSID\{3C474273-7F8B-4690-8C34-855C4528658D}");

                if (myreg == null)
                {
                    myreg = Key.OpenSubKey(@"Wow6432Node\CLSID\{3C474273-7F8B-4690-8C34-855C4528658D}");
                    if (myreg != null)
                        flag = true;
                }
                else
                    flag = true;
                myreg.Close();
            }
            catch { }
            return flag;
        }
    }
}
