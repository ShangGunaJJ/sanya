﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.IO;

namespace inv_tax_common
{

    public class EncrptStr
    {
        private const string IV_64 = "ivInv001";
        private const string KEY_64 = "keyTax01";

        public static string Decode(string data)
        {
            return DecodeEx(data);
        }

        private static string DecodeEx(string data)
        {
            byte[] buffer3;
            string str = "";
            byte[] bytes = Encoding.ASCII.GetBytes(IV_64);
            byte[] rgbIV = Encoding.ASCII.GetBytes(KEY_64);
            try
            {
                buffer3 = Convert.FromBase64String(data);
            }
            catch
            {
                return "";
            }
            DESCryptoServiceProvider provider = new DESCryptoServiceProvider();
            MemoryStream stream = new MemoryStream(buffer3);
            CryptoStream stream2 = new CryptoStream(stream, provider.CreateDecryptor(bytes, rgbIV), CryptoStreamMode.Read);
            str = new StreamReader(stream2).ReadToEnd();
            if (str.Substring(0, 3) != "INV")
            {
                return "";
            }
            if (str.Substring(str.Length - 3, 3) != "TAX")
            {
                return "";
            }
            return str.Substring(3, str.Length - 6);
        }

        public static string Encode(string data)
        {
            return EncodeEx(data);
        }

        private static string EncodeEx(string data)
        {
            data = "INV" + data + "TAX";
            byte[] bytes = Encoding.ASCII.GetBytes(IV_64);
            byte[] rgbIV = Encoding.ASCII.GetBytes(KEY_64);
            DESCryptoServiceProvider provider = new DESCryptoServiceProvider();
            int keySize = provider.KeySize;
            MemoryStream stream = new MemoryStream();
            CryptoStream stream2 = new CryptoStream(stream, provider.CreateEncryptor(bytes, rgbIV), CryptoStreamMode.Write);
            StreamWriter writer = new StreamWriter(stream2);
            writer.Write(data);
            writer.Flush();
            stream2.FlushFinalBlock();
            writer.Flush();
            return Convert.ToBase64String(stream.GetBuffer(), 0, (int)stream.Length);
        }
    }
}