﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace inv_tax_common
{
    public class IniFileRW
    {
        private string iniFilePath = System.IO.Directory.GetCurrentDirectory()+"\\config.ini";
        public IniFileRW()
        {

        }

        public IniFileRW(string path)
        {
            this.iniFilePath = path;
        }


        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);
        public string ReadValue(string section, string key)
        {
            StringBuilder retVal = new StringBuilder(0x2710);
            GetPrivateProfileString(section, key, "", retVal, 0x2710, this.iniFilePath);
            return retVal.ToString();
        }

        public void Write(string section, string key, string value)
        {
            WritePrivateProfileString(section, key, value, this.iniFilePath);
        }

        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);
    }
}
