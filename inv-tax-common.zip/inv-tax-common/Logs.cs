﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace inv_tax_DBConn
{
    public class Logs
    {

        public static int UserAddLicencesLog(string companyid,string guid,string expiredDate,string totlePage,string loginuser)
        {
            int n = 0;
            string strdatetime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            string insertSql = "insert into inv_AddLicences_log(companyid,companyguid,expiredDate,totlePage,createTime,createuser)"
                                + " values('" + companyid + "','" + guid + "','" + expiredDate + "','" + totlePage + "','" + strdatetime + "','" + loginuser  + "')";
            try
            {
                n = MySqlHelper.ExecuteNonQuery(insertSql);
            }
            catch (Exception ex)
            {
                
            }

            return n;
            
        }
    }


}
