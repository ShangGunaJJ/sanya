﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace inv_tax_common
{
    public class UserInfo
    {
        string userid = "";
        string username = "";
        string password = "";
        string guid = "";
        string name = "";
        string expireDate = "";
        int totlePages = 0;
        int usedPages = 0;
        int ialert = 0; //设置预警数量；
        string priority = ""; //判断是否有权限查看备注栏
        bool logined=false;
        string msg = "";
        int privilege = 0;
        string sh = "";
        string mode = "";
        string sessionId = "";
        string keyword = "";
        public UserInfo()
        {
            userid = "";
             username = "";
             password = "";
             guid = "";
             name = "";
             expireDate = "";
             totlePages = 0;
             usedPages = 0;
             ialert = 0; //设置预警数量；
             priority = ""; //判断是否有权限查看备注栏
             logined = false;
             keyword = "";
             msg = "";
        }
        public string KeyWord
        {
            get { return this.keyword; }
            set { this.keyword = value; }
        }
        public string SessionId
        {
            get { return this.sessionId; }
            set { this.sessionId = value; }
        }
        public string SH
        {
            get { return this.sh; }
            set { this.sh = value; }
        }
        public string Mode
        {
            get { return this.mode; }
            set { this.mode = value; }
        }
        public string UserID
        {
            get { return this.userid; }
            set { this.userid = value; }
        }
        public string UserName
        {
            get { return this.username;}
            set { this.username = value; }
        }
        public string Password
        {
            get { return this.password; }
            set { this.password = value; }
        }
        public string CompanyGuid
        {
            get { return this.guid; }
            set { this.guid = value; }
        }
        public string CompanyName
        {
            get { return this.name; }
            set { this.name = value; }
        }
        public string ExpireDate
        {
            get { return this.expireDate; }
            set { this.expireDate = value; }
        }
        public int TotlePages
        {
            get { return this.totlePages; }
            set { this.totlePages = value; }
        }
        public int UsedPages
        {
            get { return this.usedPages; }
            set { this.usedPages = value; }
        }
        public int ExpireAlertPages
        {
            get { return this.ialert; }
            set { this.ialert = value; }
        }
        public string Priority
        {
            get { return this.priority; }
            set { this.priority = value; }
        }
        public bool Logined
        {
            get { return this.logined; }
            set { this.logined = value; }
        }
        public string Message
        {
            get { return this.msg; }
            set { this.msg = value; }
        }
        public int Privilege
        {
            get { return this.privilege; }
            set { this.privilege = value; }
        }
    }
}
