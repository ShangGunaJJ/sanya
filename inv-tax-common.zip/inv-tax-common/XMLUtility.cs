﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.IO;
using System.Reflection;

namespace inv_tax_common
{
    public class XMLUtility
    {
        public static string readSetting(string nodeName)
        {
            string xmlPath = getXMLPath();
            XmlDocument doc = null;

            if (File.Exists(xmlPath))
            {
                doc = new XmlDocument();
                doc.Load(xmlPath);
                XmlNode node = doc.SelectSingleNode("Setting/" + nodeName);
                if (node != null)
                    return node.InnerText;
                else
                    return "";
            }
            else
                return "";
        }

        public static void writeSetting(string nodeName, string value)
        {
            string xmlPath = getXMLPath();
            XmlDocument doc = null;

            if (File.Exists(xmlPath))
            {
                try
                {
                    doc = new XmlDocument();
                    doc.Load(xmlPath);
                    XmlNode node = doc.SelectSingleNode("Setting/" + nodeName);
                    if (node != null)
                    {
                        node.InnerText = value;
                        doc.Save(xmlPath);
                    }
                }
                catch { }
                finally
                {
                    doc = null;
                }
            }
        }

        private static string getXMLPath()
        {
            string appData = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
            string rootFolder = Path.Combine(appData, "BatchDrawingRecognize");
            string xmlFolder = Path.Combine(rootFolder, "Setting");
            string xmlPath = Path.Combine(xmlFolder, "Setting.XML");
            string executingPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            string oriXmlPath = Path.Combine(executingPath, "Setting.XML");
            string result = "";

            if (!Directory.Exists(rootFolder))
            {
                try
                {
                    Directory.CreateDirectory(rootFolder);
                }
                catch (Exception ex)
                {
                    result = "";
                }

            }

            if (!Directory.Exists(xmlFolder))
            {
                try
                {
                    Directory.CreateDirectory(xmlFolder);
                }
                catch (Exception ex)
                {
                    result = "";
                }
            }

            if (!File.Exists(xmlPath))
            {
                if (File.Exists(oriXmlPath))
                {
                    try
                    {
                        File.Copy(oriXmlPath, xmlPath);
                        result = xmlPath;
                    }
                    catch (Exception ex) { result = ""; }
                }
            }
            else
                result = xmlPath;

            return result;
        }
    }
}
